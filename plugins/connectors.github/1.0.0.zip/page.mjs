// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.testing-notice {\n  margin-bottom: var(--ui-space-6);\n  padding: var(--ui-space-4);\n  border: 1px solid var(--border);\n  border-radius: var(--ui-radius-md);\n  background: var(--muted);\n}\n.testing-notice h2 {\n  padding: 0;\n  border: 0;\n  font-size: var(--ui-text-sm);\n}\n.testing-notice p {\n  margin-top: var(--ui-space-2);\n  color: var(--muted-foreground);\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n  color: var(--muted-foreground);\n}\n.feature-icon {\n  margin-top: 0.125rem;\n}\n.account-row {\n  display: flex;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.account-icon {\n  width: 2.25rem;\n  height: 2.25rem;\n  border: 1px solid var(--border);\n  border-radius: var(--ui-radius-md);\n  flex: none;\n}\n.account-summary {\n  flex: 1;\n  min-width: min(100%, 14rem);\n}\n.account-name {\n  display: block;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.account-hint {\n  margin-top: var(--ui-space-1);\n  color: var(--muted-foreground);\n}\n.account-actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: var(--ui-space-2);\n}\n.account-status {\n  margin-top: var(--ui-space-4);\n  color: var(--muted-foreground);\n}\n.account-error {\n  margin-top: var(--ui-space-4);\n}\n.account-error p {\n  color: var(--destructive);\n  margin-bottom: var(--ui-space-2);\n}\n.features {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n\n.features p {\n  color: var(--muted-foreground);\n}\n\n.github-page .device-code { margin: 20px 0; }\n.github-page .device-code code { display: inline-block; font-size: 24px; letter-spacing: 0.12em; padding: 10px 14px; border: 1px solid var(--border); border-radius: 8px; user-select: all; }\n";

// src/strings.mjs
var zh = {
  accountTitle: "GitHub \u8D26\u53F7",
  featuresTitle: "GitHub \u529F\u80FD",
  features: [
    ["\u4ED3\u5E93\u548C\u4EE3\u7801", "\u67E5\u627E\u4ED3\u5E93\u3001\u8BFB\u53D6\u6587\u4EF6\u4E0E\u63D0\u4EA4\uFF0C\u521B\u5EFA\u5206\u652F\u5E76\u66F4\u65B0\u4ED3\u5E93\u5185\u5BB9\u3002"],
    ["\u8BAE\u9898\u548C\u62C9\u53D6\u8BF7\u6C42", "\u521B\u5EFA\u548C\u66F4\u65B0\u8BAE\u9898\uFF0C\u8BC4\u8BBA\u3001\u5BA1\u67E5\u53CA\u5408\u5E76\u62C9\u53D6\u8BF7\u6C42\u3002"],
    ["\u53D1\u5E03\u548C\u81EA\u52A8\u5316\u8FD0\u884C", "\u67E5\u770B\u548C\u521B\u5EFA\u53D1\u5E03\uFF0C\u89E6\u53D1\u3001\u91CD\u8DD1\u6216\u53D6\u6D88\u81EA\u52A8\u5316\u8FD0\u884C\u3002"]
  ],
  connect: "\u8FDE\u63A5 GitHub",
  continue: "\u6253\u5F00\u6388\u6743\u9875\u9762",
  cancel: "\u53D6\u6D88\u6388\u6743",
  refresh: "\u5237\u65B0\u8FDE\u63A5",
  disconnect: "\u65AD\u5F00\u8FDE\u63A5",
  retry: "\u91CD\u8BD5",
  install: "\u7BA1\u7406\u6388\u6743\u4ED3\u5E93",
  manage: "\u7BA1\u7406 GitHub \u6388\u6743",
  deviceHint: "\u8BF7\u5728\u6253\u5F00\u7684 GitHub \u9875\u9762\u8F93\u5165\u4EE5\u4E0B\u9A8C\u8BC1\u7801\uFF0C\u5E76\u786E\u8BA4\u8FDE\u63A5 LimeA Connector\u3002",
  loading: "\u6B63\u5728\u8BFB\u53D6\u8D26\u53F7\u2026",
  loadFailed: "\u65E0\u6CD5\u8BFB\u53D6\u8FDE\u63A5\u72B6\u6001\u3002",
  notConnected: "\u5C1A\u672A\u8FDE\u63A5 GitHub",
  ready: "\u5DF2\u8FDE\u63A5",
  scope: "\u8BBF\u95EE\u5B89\u88C5 LimeA Connector \u65F6\u9009\u5B9A\u7684\u4ED3\u5E93",
  reauthorization: "\u6388\u6743\u5DF2\u5931\u6548\uFF0C\u8BF7\u65AD\u5F00\u5E76\u91CD\u65B0\u8FDE\u63A5\u3002",
  authorizing: "\u7B49\u5F85 GitHub \u6388\u6743",
  authorizingHint: "\u5728\u6D4F\u89C8\u5668\u5B8C\u6210\u6388\u6743\u540E\uFF0C\u8D26\u53F7\u4F1A\u81EA\u52A8\u663E\u793A\u5728\u8FD9\u91CC\u3002",
  actionFailed: "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002",
  vaultUnavailable: "\u7CFB\u7EDF\u51ED\u636E\u5B58\u50A8\u4E0D\u53EF\u7528\u3002",
  refreshUnavailable: "\u65E0\u6CD5\u5237\u65B0\u6388\u6743\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002",
  refreshPending: "\u6B63\u5728\u5237\u65B0\u6388\u6743\u2026",
  revokePending: "\u6B63\u5728\u5904\u7406\u6388\u6743\u2026",
  savedAcknowledging: "\u8D26\u53F7\u5DF2\u4FDD\u5B58\u3002",
  recoveryHint: "\u4E0A\u6B21\u6388\u6743\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u65AD\u5F00\u5E76\u91CD\u65B0\u8FDE\u63A5\u3002",
  auth: { failed: "\u6388\u6743\u5931\u8D25\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002", expired: "\u9A8C\u8BC1\u7801\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002", unknown: "\u6388\u6743\u7ED3\u679C\u672A\u77E5\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002", cancelled: "\u5DF2\u53D6\u6D88\u6388\u6743\u3002" },
  revocation: { not_requested: "\u5DF2\u65AD\u5F00\u672C\u673A\u8FDE\u63A5\u3002", pending: "\u5DF2\u65AD\u5F00\u672C\u673A\u8FDE\u63A5\u3002", confirmed: "\u5DF2\u65AD\u5F00\u8FDE\u63A5\u3002", unknown: "\u5DF2\u79FB\u9664\u672C\u673A\u51ED\u636E\u3002\u53EF\u70B9\u51FB\u300C\u7BA1\u7406 GitHub \u6388\u6743\u300D\u64A4\u9500 GitHub \u7AEF\u7684\u6388\u6743\u3002", failed: "\u5DF2\u79FB\u9664\u672C\u673A\u51ED\u636E\uFF0C\u8BF7\u5230 GitHub \u6838\u5BF9\u6388\u6743\u3002" }
};
var en = {
  accountTitle: "GitHub account",
  featuresTitle: "GitHub tools",
  features: [["Repositories and code", "Find repositories, read files and commits, create branches and update contents."], ["Issues and pull requests", "Create and update issues, comment, review and merge pull requests."], ["Releases and workflow runs", "Read and create releases, dispatch, rerun or cancel workflows."]],
  connect: "Connect GitHub",
  continue: "Open authorization",
  cancel: "Cancel",
  refresh: "Refresh connection",
  disconnect: "Disconnect",
  retry: "Retry",
  install: "Manage repositories",
  manage: "Manage GitHub access",
  deviceHint: "Enter this code on GitHub and confirm that you are connecting LimeA Connector.",
  loading: "Loading account\u2026",
  loadFailed: "Could not load connection.",
  notConnected: "GitHub is disconnected",
  ready: "Connected",
  scope: "Repositories selected for LimeA Connector",
  reauthorization: "Authorization expired. Disconnect and reconnect.",
  authorizing: "Waiting for GitHub",
  authorizingHint: "Complete authorization in your browser. Your account will appear here automatically.",
  actionFailed: "Operation failed. Check your connection and retry.",
  vaultUnavailable: "System credential storage is unavailable.",
  refreshUnavailable: "Reconnect to renew authorization.",
  refreshPending: "Refreshing authorization\u2026",
  revokePending: "Processing authorization\u2026",
  savedAcknowledging: "Account saved.",
  recoveryHint: "Authorization did not complete. Disconnect and reconnect.",
  auth: { failed: "Authorization failed. Reconnect.", expired: "Code expired. Reconnect.", unknown: "Authorization outcome unknown. Reconnect.", cancelled: "Authorization cancelled." },
  revocation: { not_requested: "Local connection removed.", pending: "Local connection removed.", confirmed: "Disconnected.", unknown: "Local credentials removed. Use Manage GitHub access to revoke authorization on GitHub.", failed: "Local credentials removed. Review authorization on GitHub." }
};

// src/page.mjs
function mount(container, context) {
  if (!context.connections || !context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "github-page";
  root.innerHTML = `<section class="account" aria-labelledby="account-title">
    <h2 id="account-title"></h2>
    <div class="account-row"><img class="account-icon" alt=""><div class="account-summary"><strong class="account-name"></strong><p class="account-hint"></p></div>
      <div class="account-actions"><span data-action="authorize"></span><span data-action="resume"></span><span data-action="cancel"></span><span data-action="refresh"></span><span data-action="disconnect"></span><span data-action="install"></span><span data-action="manage"></span></div></div>
    <div class="device-code" hidden><p></p><code></code></div><p role="status" class="account-status"></p><div role="alert" class="account-error"><p></p><span data-action="retry"></span></div></section>
    <section class="features"><h2><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span></h2><ul></ul></section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query("#account-title").textContent = t.accountTitle;
  query(".account-icon").src = new URL("assets/icon.png", context.resourceBase).href;
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  const featureIcons = ["search", "file-text", "list-tree"];
  for (const [index, [title, detail]] of t.features.entries()) {
    const row = document.createElement("li"), icon = document.createElement("span"), section = document.createElement("div"), h = document.createElement("h3"), p = document.createElement("p");
    h.textContent = title;
    p.textContent = detail;
    icon.className = "feature-icon";
    icon.dataset.icon = featureIcons[index];
    section.append(h, p);
    row.append(icon, section);
    query(".features ul").append(row);
  }
  let view, pending = false, polling = false, timer, disposed = false, error = "";
  const handles = /* @__PURE__ */ new Map();
  const iconHandles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name)) {
      iconHandles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    } else slot.hidden = true;
  }
  const alive = () => !disposed && !context.signal.aborted;
  const labels = {
    authorize: t.connect,
    resume: t.continue,
    cancel: t.cancel,
    refresh: t.refresh,
    disconnect: t.disconnect,
    retry: t.retry,
    install: t.install,
    manage: t.manage
  };
  const actionIcons = {
    authorize: "external-link",
    resume: "external-link",
    refresh: "refresh-cw",
    disconnect: "unplug"
  };
  const buttonIcon = (action) => context.controls.icons?.includes(actionIcons[action]) ? { icon: actionIcons[action] } : {};
  for (const [action, label] of Object.entries(labels)) {
    const slot = query(`[data-action="${action}"]`);
    handles.set(
      action,
      context.controls.mount(slot, {
        type: "button",
        label,
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        onPress: () => void perform(action)
      })
    );
  }
  function render() {
    if (!alive()) return;
    const c = view?.connection, f = view?.authorization;
    const authorizing = f && ["preparing", "authorizing"].includes(f.status);
    const connected = c?.status === "connected";
    query(".account-name").textContent = !view ? t.loading : authorizing ? t.authorizing : connected ? c.workspaceName : c?.status === "reauthorization_required" ? t.reauthorization : t.notConnected;
    query(".account-hint").textContent = authorizing ? t.authorizingHint : connected ? `${t.ready} \xB7 ${t.scope}` : t.scope;
    query(".device-code").hidden = !authorizing || !f?.userCode;
    query(".device-code p").textContent = t.deviceHint;
    query(".device-code code").textContent = authorizing ? f?.userCode ?? "" : "";
    const shown = {
      install: true,
      manage: true,
      authorize: Boolean(
        view && (!c || c.status === "disconnected") && !authorizing && f?.status !== "persisted"
      ),
      resume: Boolean(authorizing),
      cancel: Boolean(authorizing),
      refresh: Boolean(c && c.status !== "disconnected"),
      disconnect: Boolean(c && c.status !== "disconnected"),
      retry: Boolean(error)
    };
    for (const [action, handle] of handles) {
      query(`[data-action="${action}"]`).hidden = !shown[action];
      handle.update({
        type: "button",
        label: labels[action],
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        disabled: pending || action === "refresh" && Boolean(view?.operation),
        onPress: () => void perform(action)
      });
    }
    let status = "";
    if (c?.status === "disconnected") status = t.revocation[c.remoteRevocation];
    else if (view?.operation)
      status = view.operation.kind === "refresh" ? t.refreshPending : t.revokePending;
    else if (f?.status === "persisted") status = t.savedAcknowledging;
    else if (f && ["failed", "expired", "unknown", "cancelled"].includes(f.status))
      status = t.auth[f.status];
    else if (c?.error || f?.error) status = t.recoveryHint;
    query(".account-status").textContent = status;
    query(".account-status").hidden = !status;
    query(".account-error").hidden = !error;
    query(".account-error p").textContent = error;
    query(".account").setAttribute("aria-busy", String(pending || !view));
  }
  function schedule() {
    clearTimeout(timer);
    if (alive() && (view?.operation || view?.authorization?.pending))
      timer = setTimeout(() => void load(), 2e3);
  }
  async function load() {
    if (!alive() || pending || polling) return;
    polling = true;
    try {
      const next = await context.connections.request({ action: "view" });
      if (alive() && (!view || next.revision >= view.revision)) {
        view = next;
        error = "";
      }
    } catch {
      if (alive()) error = t.loadFailed;
    } finally {
      polling = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  async function perform(action) {
    if (!alive() || pending) return;
    if (action === "retry") {
      await load();
      return;
    }
    pending = true;
    error = "";
    render();
    try {
      const next = await context.connections.request({ action });
      if (alive() && (!view || next.revision >= view.revision)) view = next;
    } catch (e) {
      if (alive())
        error = e?.code === "connection-vault-unavailable" ? t.vaultUnavailable : e?.code === "connection-refresh-unavailable" ? t.refreshUnavailable : t.actionFailed;
    } finally {
      pending = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  const unsubscribe = context.connections.subscribe((next) => {
    if (alive() && (!view || next.revision >= view.revision)) {
      view = next;
      render();
      schedule();
    }
  });
  const onFocus = () => void load();
  window.addEventListener("focus", onFocus);
  function cleanup() {
    disposed = true;
    clearTimeout(timer);
    unsubscribe();
    window.removeEventListener("focus", onFocus);
    for (const handle of handles.values()) handle.destroy();
    for (const handle of iconHandles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  render();
  void load();
  return cleanup;
}
export {
  mount
};
