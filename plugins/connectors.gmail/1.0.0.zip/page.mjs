// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.account-row {\n  display: flex;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.account-icon {\n  width: 2.25rem;\n  height: 2.25rem;\n  border: 1px solid var(--border);\n  border-radius: var(--ui-radius-md);\n  flex: none;\n}\n.account-summary {\n  flex: 1;\n  min-width: min(100%, 14rem);\n}\n.account-name {\n  display: block;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.account-hint {\n  margin-top: var(--ui-space-1);\n  color: var(--muted-foreground);\n}\n.account-actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: var(--ui-space-2);\n}\n.account-status {\n  margin-top: var(--ui-space-4);\n  color: var(--muted-foreground);\n}\n.account-error {\n  margin-top: var(--ui-space-4);\n}\n.account-error p {\n  color: var(--destructive);\n  margin-bottom: var(--ui-space-2);\n}\n.features {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n\n.features p {\n  color: var(--muted-foreground);\n}\n";

// src/strings.mjs
var zh = {
  accountTitle: "Google \u8D26\u53F7",
  featuresTitle: "\u90AE\u7BB1\u529F\u80FD",
  features: [
    ["\u641C\u7D22\u548C\u9605\u8BFB", "\u6309\u53D1\u4EF6\u4EBA\u3001\u4E3B\u9898\u3001\u65E5\u671F\u6216\u6807\u7B7E\u67E5\u627E\u90AE\u4EF6\uFF0C\u9605\u8BFB\u6B63\u6587\u548C\u4F1A\u8BDD\u3002"],
    ["\u8349\u7A3F\u548C\u53D1\u9001", "\u5148\u62DF\u8349\u7A3F\uFF0C\u6216\u6309\u4F60\u7684\u6307\u793A\u5411\u6307\u5B9A\u6536\u4EF6\u4EBA\u53D1\u9001\u90AE\u4EF6\u3002"],
    ["\u6574\u7406\u90AE\u7BB1", "\u6807\u8BB0\u5DF2\u8BFB\u3001\u52A0\u661F\u3001\u5F52\u6863\u3001\u79FB\u56DE\u6536\u4EF6\u7BB1\u6216\u79FB\u5165\u56DE\u6536\u7AD9\u3002"]
  ],
  connect: "\u8FDE\u63A5 Gmail",
  continue: "\u7EE7\u7EED\u6388\u6743",
  cancel: "\u53D6\u6D88\u6388\u6743",
  refresh: "\u5237\u65B0\u8FDE\u63A5",
  disconnect: "\u65AD\u5F00\u8FDE\u63A5",
  retry: "\u91CD\u8BD5",
  loading: "\u6B63\u5728\u8BFB\u53D6\u8D26\u53F7\u2026",
  loadFailed: "\u65E0\u6CD5\u8BFB\u53D6\u8FDE\u63A5\u72B6\u6001\u3002",
  notConnected: "\u5C1A\u672A\u8FDE\u63A5 Gmail",
  ready: "\u5DF2\u8FDE\u63A5",
  scope: "\u8BFB\u53D6\u3001\u53D1\u9001\u548C\u6574\u7406\u90AE\u4EF6",
  reauthorization: "\u6388\u6743\u5DF2\u5931\u6548\uFF0C\u8BF7\u65AD\u5F00\u5E76\u91CD\u65B0\u8FDE\u63A5\u3002",
  authorizing: "\u7B49\u5F85 Google \u6388\u6743",
  authorizingHint: "\u8BF7\u5728\u7CFB\u7EDF\u6D4F\u89C8\u5668\u4E2D\u9009\u62E9 Google \u8D26\u53F7\u5E76\u5141\u8BB8\u8BBF\u95EE Gmail\u3002\u5B8C\u6210\u540E\u56DE\u5230 LimeA\u3002",
  actionFailed: "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002",
  vaultUnavailable: "\u7CFB\u7EDF\u51ED\u636E\u5B58\u50A8\u4E0D\u53EF\u7528\u3002",
  refreshUnavailable: "\u65E0\u6CD5\u5237\u65B0\u6388\u6743\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002",
  refreshPending: "\u6B63\u5728\u5237\u65B0\u6388\u6743\u2026",
  revokePending: "\u6B63\u5728\u64A4\u9500\u6388\u6743\u2026",
  savedAcknowledging: "\u8D26\u53F7\u5DF2\u4FDD\u5B58\uFF0C\u6B63\u5728\u786E\u8BA4\u6388\u6743\u3002",
  recoveryHint: "\u4E0A\u6B21\u64CD\u4F5C\u4ECD\u5F85\u6838\u5BF9\u3002",
  auth: {
    failed: "\u6388\u6743\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002",
    expired: "\u6388\u6743\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002",
    unknown: "\u6388\u6743\u7ED3\u679C\u5F85\u6838\u5BF9\u3002",
    cancelled: "\u5DF2\u53D6\u6D88\u6388\u6743\u3002"
  },
  revocation: {
    not_requested: "\u5DF2\u65AD\u5F00\u3002",
    pending: "\u5DF2\u65AD\u5F00\uFF0C\u6B63\u5728\u64A4\u9500 Google \u6388\u6743\u3002",
    confirmed: "\u5DF2\u65AD\u5F00\u5E76\u64A4\u9500 Google \u6388\u6743\u3002",
    unknown: "\u5DF2\u65AD\u5F00\u3002\u8BF7\u5230 Google \u8D26\u53F7\u7684\u7B2C\u4E09\u65B9\u8FDE\u63A5\u4E2D\u6838\u5BF9\u6388\u6743\u3002",
    failed: "\u5DF2\u65AD\u5F00\u3002\u8BF7\u5230 Google \u8D26\u53F7\u7684\u7B2C\u4E09\u65B9\u8FDE\u63A5\u4E2D\u79FB\u9664\u6388\u6743\u3002"
  }
};
var en = {
  accountTitle: "Google account",
  featuresTitle: "Mail tools",
  features: [
    [
      "Search and read",
      "Find messages by sender, subject, date or label. Read messages and threads."
    ],
    ["Draft and send", "Prepare a draft or send a message to the recipients you specify."],
    ["Organize mail", "Mark read, star, archive, move to Inbox or move to Trash."]
  ],
  connect: "Connect Gmail",
  continue: "Continue authorization",
  cancel: "Cancel",
  refresh: "Refresh connection",
  disconnect: "Disconnect",
  retry: "Retry",
  loading: "Loading account\u2026",
  loadFailed: "Could not load connection.",
  notConnected: "Gmail is disconnected",
  ready: "Connected",
  scope: "Read, send and organize mail",
  reauthorization: "Authorization expired. Disconnect and reconnect.",
  authorizing: "Waiting for Google",
  authorizingHint: "Choose your account and allow Gmail access in the browser, then return to LimeA.",
  actionFailed: "Operation failed. Check your connection and retry.",
  vaultUnavailable: "System credential storage is unavailable.",
  refreshUnavailable: "Reconnect to renew authorization.",
  refreshPending: "Refreshing authorization\u2026",
  revokePending: "Revoking authorization\u2026",
  savedAcknowledging: "Account saved. Confirming authorization.",
  recoveryHint: "The previous operation is awaiting review.",
  auth: {
    failed: "Authorization failed.",
    expired: "Authorization expired. Reconnect.",
    unknown: "Authorization outcome is unknown.",
    cancelled: "Authorization cancelled."
  },
  revocation: {
    not_requested: "Disconnected.",
    pending: "Disconnected. Revoking authorization.",
    confirmed: "Disconnected and revoked.",
    unknown: "Disconnected. Check third-party connections in your Google account.",
    failed: "Disconnected. Remove the connection from your Google account."
  }
};

// src/page.mjs
function mount(container, context) {
  if (!context.connections || !context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "gmail-page";
  root.innerHTML = `<section class="account" aria-labelledby="account-title">
    <h2 id="account-title"></h2>
    <div class="account-row"><img class="account-icon" alt=""><div class="account-summary"><strong class="account-name"></strong><p class="account-hint"></p></div>
      <div class="account-actions"><span data-action="authorize"></span><span data-action="resume"></span><span data-action="cancel"></span><span data-action="refresh"></span><span data-action="disconnect"></span></div></div>
    <p role="status" class="account-status"></p><div role="alert" class="account-error"><p></p><span data-action="retry"></span></div></section>
    <section class="features"><h2></h2><ul></ul></section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query("#account-title").textContent = t.accountTitle;
  query(".account-icon").src = new URL("assets/icon.png", context.resourceBase).href;
  query(".features h2").textContent = t.featuresTitle;
  for (const [title, detail] of t.features) {
    const row = document.createElement("li"), section = document.createElement("div"), h = document.createElement("h3"), p = document.createElement("p");
    h.textContent = title;
    p.textContent = detail;
    section.append(h, p);
    row.append(section);
    query(".features ul").append(row);
  }
  let view, pending = false, polling = false, timer, disposed = false, error = "";
  const handles = /* @__PURE__ */ new Map();
  const alive = () => !disposed && !context.signal.aborted;
  const labels = {
    authorize: t.connect,
    resume: t.continue,
    cancel: t.cancel,
    refresh: t.refresh,
    disconnect: t.disconnect,
    retry: t.retry
  };
  const actionIcons = {
    authorize: "external-link",
    resume: "external-link",
    refresh: "refresh-cw",
    disconnect: "unplug"
  };
  const buttonIcon = (action) => context.controls.icons?.includes(actionIcons[action]) ? { icon: actionIcons[action] } : {};
  for (const [action, label] of Object.entries(labels)) {
    const slot = query(`[data-action="${action}"]`);
    handles.set(
      action,
      context.controls.mount(slot, {
        type: "button",
        label,
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        onPress: () => void perform(action)
      })
    );
  }
  function render() {
    if (!alive()) return;
    const c = view?.connection, f = view?.authorization;
    const authorizing = f && ["preparing", "authorizing"].includes(f.status);
    const connected = c?.status === "connected";
    query(".account-name").textContent = !view ? t.loading : authorizing ? t.authorizing : connected ? c.workspaceName : c?.status === "reauthorization_required" ? t.reauthorization : t.notConnected;
    query(".account-hint").textContent = authorizing ? t.authorizingHint : connected ? `${t.ready} \xB7 ${t.scope}` : t.scope;
    const shown = {
      authorize: Boolean(
        view && (!c || c.status === "disconnected") && !authorizing && f?.status !== "persisted"
      ),
      resume: Boolean(authorizing),
      cancel: Boolean(authorizing),
      refresh: Boolean(c && c.status !== "disconnected"),
      disconnect: Boolean(c && c.status !== "disconnected"),
      retry: Boolean(error)
    };
    for (const [action, handle] of handles) {
      query(`[data-action="${action}"]`).hidden = !shown[action];
      handle.update({
        type: "button",
        label: labels[action],
        ...buttonIcon(action),
        variant: action === "authorize" ? "default" : "outline",
        disabled: pending || action === "refresh" && Boolean(view?.operation),
        onPress: () => void perform(action)
      });
    }
    let status = "";
    if (c?.status === "disconnected") status = t.revocation[c.remoteRevocation];
    else if (view?.operation)
      status = view.operation.kind === "refresh" ? t.refreshPending : t.revokePending;
    else if (f?.status === "persisted") status = t.savedAcknowledging;
    else if (f && ["failed", "expired", "unknown", "cancelled"].includes(f.status))
      status = t.auth[f.status];
    else if (c?.error || f?.error) status = t.recoveryHint;
    query(".account-status").textContent = status;
    query(".account-status").hidden = !status;
    query(".account-error").hidden = !error;
    query(".account-error p").textContent = error;
    query(".account").setAttribute("aria-busy", String(pending || !view));
  }
  function schedule() {
    clearTimeout(timer);
    if (alive() && (view?.operation || view?.authorization?.pending))
      timer = setTimeout(() => void load(), 2e3);
  }
  async function load() {
    if (!alive() || pending || polling) return;
    polling = true;
    try {
      const next = await context.connections.request({ action: "view" });
      if (alive() && (!view || next.revision >= view.revision)) {
        view = next;
        error = "";
      }
    } catch {
      if (alive()) error = t.loadFailed;
    } finally {
      polling = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  async function perform(action) {
    if (!alive() || pending) return;
    if (action === "retry") {
      await load();
      return;
    }
    pending = true;
    error = "";
    render();
    try {
      const next = await context.connections.request({ action });
      if (alive() && (!view || next.revision >= view.revision)) view = next;
    } catch (e) {
      if (alive())
        error = e?.code === "connection-vault-unavailable" ? t.vaultUnavailable : e?.code === "connection-refresh-unavailable" ? t.refreshUnavailable : t.actionFailed;
    } finally {
      pending = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  const unsubscribe = context.connections.subscribe((next) => {
    if (alive() && (!view || next.revision >= view.revision)) {
      view = next;
      render();
      schedule();
    }
  });
  const onFocus = () => void load();
  window.addEventListener("focus", onFocus);
  function cleanup() {
    disposed = true;
    clearTimeout(timer);
    unsubscribe();
    window.removeEventListener("focus", onFocus);
    for (const handle of handles.values()) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  render();
  void load();
  return cleanup;
}
export {
  mount
};
