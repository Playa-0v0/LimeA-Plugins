// src/panel.css
var panel_default = ":host {\n  font-family: inherit;\n  color: var(--foreground, #ededed);\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\n.draw-guess {\n  display: flex;\n  flex-direction: column;\n  min-height: 100%;\n  gap: 18px;\n  padding: 22px;\n}\n.heading,\nfooter,\n.actions,\n.setup {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 10px;\n  flex-wrap: wrap;\n}\nh2 {\n  margin: 0;\n  font-size: 20px;\n  font-weight: 600;\n}\np {\n  margin: 6px 0 0;\n  line-height: 1.6;\n}\n.muted {\n  color: var(--muted-foreground, #b5b5b5);\n  font-size: 12px;\n}\n.clock {\n  font-variant-numeric: tabular-nums;\n  font-size: 22px;\n  font-weight: 500;\n}\n.sound-settings {\n  position: relative;\n  font-size: 13px;\n}\n.sound-settings summary {\n  cursor: pointer;\n  padding: 7px 10px;\n  border: 1px solid var(--border, #353535);\n  border-radius: 8px;\n}\n.sound-options {\n  position: absolute;\n  right: 0;\n  top: calc(100% + 8px);\n  z-index: 3;\n  width: 200px;\n  display: grid;\n  gap: 14px;\n  padding: 16px;\n  border: 1px solid var(--border, #353535);\n  border-radius: 10px;\n  background: var(--background, #171717);\n}\n.sound-options label {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  white-space: nowrap;\n}\n.sound-options input[type='checkbox'] {\n  accent-color: var(--primary, #adeb78);\n  margin: 0;\n}\n.sound-options input[type='range'] {\n  accent-color: var(--primary, #adeb78);\n  min-width: 0;\n  flex: 1;\n  width: 0;\n  padding: 0;\n  border: 0;\n}\n.sound-settings summary:focus-visible {\n  outline: 2px solid var(--primary, #adeb78);\n  outline-offset: 3px;\n}\nbutton,\nselect,\ninput {\n  font: inherit;\n  color: var(--foreground, #ededed);\n  border: 1px solid var(--border, #353535);\n  background: transparent;\n  border-radius: 8px;\n  padding: 8px 12px;\n}\nbutton,\nselect {\n  cursor: pointer;\n}\nbutton:hover:not(:disabled) {\n  background: var(--muted, #282828);\n}\nbutton:disabled {\n  opacity: 0.45;\n  cursor: default;\n}\nbutton:focus-visible,\ninput:focus-visible,\nselect:focus-visible {\n  outline: 2px solid var(--primary, #adeb78);\n  outline-offset: 3px;\n}\n.primary,\n.primary:hover:not(:disabled) {\n  color: var(--primary-foreground, #1c2b12);\n  background: var(--primary, #adeb78);\n  border-color: transparent;\n}\n.primary:hover:not(:disabled) {\n  filter: brightness(0.94);\n}\nselect option {\n  background: var(--background, #171717);\n}\n.setup {\n  justify-content: flex-start;\n  padding: 12px 0;\n}\n.round-status {\n  min-height: 20px;\n  font-size: 13px;\n  color: var(--muted-foreground, #b5b5b5);\n}\n.choices {\n  display: grid;\n  grid-template-columns: repeat(3, minmax(0, 1fr));\n  gap: 10px;\n}\n.word-choice {\n  font-size: 18px;\n  padding: 24px 8px;\n  overflow-wrap: anywhere;\n}\n.word-choice:hover:not(:disabled) {\n  border-color: var(--primary, #adeb78);\n}\n.private-word {\n  font-size: 13px;\n  color: var(--primary, #adeb78);\n}\n.word-hint {\n  color: var(--muted-foreground, #b5b5b5);\n  font-size: 13px;\n}\n.play-area {\n  position: relative;\n  min-width: 0;\n}\n.play-content {\n  display: flex;\n  flex-direction: column;\n  gap: 18px;\n}\n.play-area[aria-busy='true'] {\n  min-height: 320px;\n}\n.word-loading {\n  position: absolute;\n  inset: 0;\n  z-index: 1;\n  display: flex;\n  align-items: flex-start;\n  justify-content: center;\n  padding: 40px 20px;\n  border-radius: 10px;\n  background: rgb(0 0 0 / 88%);\n  color: #ededed;\n  font-size: 14px;\n}\n.round-result {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: 12px;\n  padding: 16px 0;\n  border-block: 1px solid var(--border, #353535);\n}\n.round-result strong {\n  font-size: 17px;\n  font-weight: 600;\n}\n.drawing {\n  min-width: 0;\n  width: 100%;\n}\n.guesses {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n}\n.guess {\n  font-size: 13px;\n  padding: 6px 10px;\n  border-radius: 8px;\n  background: var(--muted, #282828);\n  overflow-wrap: anywhere;\n}\n.guess-form {\n  display: flex;\n  gap: 8px;\n}\n.guess-form input {\n  min-width: 0;\n  flex: 1;\n}\ninput::placeholder {\n  color: var(--muted-foreground, #b5b5b5);\n}\nfooter {\n  margin-top: auto;\n  padding-top: 6px;\n}\n.error {\n  color: var(--destructive, #ff998a);\n  font-size: 13px;\n}\n@media (max-width: 480px) {\n  .draw-guess {\n    padding: 14px;\n    gap: 14px;\n  }\n  .word-choice {\n    font-size: 15px;\n    padding-block: 18px;\n  }\n}\n";

// src/sound.mjs
function createDrawingSound(resourceBase) {
  const key = "games.draw_guess.audio";
  let preferences = { enabled: true, pencil: true, volume: 0.35 };
  try {
    const saved = JSON.parse(localStorage.getItem(key) ?? "null");
    if (typeof saved?.enabled === "boolean") preferences.enabled = saved.enabled;
    if (typeof saved?.pencil === "boolean") preferences.pencil = saved.pencil;
    if (Number.isFinite(saved?.volume)) preferences.volume = Math.max(0, Math.min(1, saved.volume));
  } catch {
  }
  let context, master, loading, loop, stopTimer;
  let disposed = false, visible = true, generation = 0, movingUntil = 0, lastErase = 0;
  const buffers = /* @__PURE__ */ new Map(), active = /* @__PURE__ */ new Set(), pendingShots = /* @__PURE__ */ new Set();
  const requests = new AbortController();
  function stopLoop() {
    movingUntil = 0;
    clearTimeout(stopTimer);
    if (!loop || !context) return;
    const { source, gain } = loop;
    loop = null;
    gain.gain.cancelScheduledValues(context.currentTime);
    gain.gain.setValueAtTime(gain.gain.value, context.currentTime);
    gain.gain.linearRampToValueAtTime(0, context.currentTime + 0.035);
    source.stop(context.currentTime + 0.04);
  }
  function stopAll() {
    generation++;
    stopLoop();
    for (const source of active) {
      try {
        source.stop();
      } catch {
      }
    }
    active.clear();
    pendingShots.clear();
  }
  function unlock() {
    if (disposed || !visible || !preferences.enabled) return;
    try {
      if (!context) {
        context = new AudioContext();
        master = context.createGain();
        master.gain.value = preferences.volume;
        master.connect(context.destination);
      }
      if (context.state === "suspended") void context.resume().catch(() => {
      });
      if (!loading)
        loading = Promise.all(
          ["pencil", "erase", "fill", "undo", "redo"].map(async (name) => {
            try {
              const response = await fetch(new URL(`assets/audio/${name}.ogg`, resourceBase), {
                signal: requests.signal
              });
              if (!response.ok) return;
              const buffer = await context.decodeAudioData(await response.arrayBuffer());
              if (!disposed) buffers.set(name, buffer);
            } catch {
            }
          })
        );
    } catch {
    }
  }
  function start(name, repeat = false) {
    if (!context || context.state !== "running" || !buffers.has(name)) return null;
    const source = context.createBufferSource(), gain = context.createGain();
    source.buffer = buffers.get(name);
    source.loop = repeat;
    gain.gain.value = repeat ? 0 : 0.65;
    source.connect(gain).connect(master);
    active.add(source);
    source.onended = () => {
      active.delete(source);
      source.disconnect();
      gain.disconnect();
    };
    source.start();
    if (repeat) gain.gain.linearRampToValueAtTime(0.5, context.currentTime + 0.025);
    return { source, gain };
  }
  function interaction(event) {
    if (event === "stroke-end") {
      stopLoop();
      return;
    }
    if (disposed || !visible || !preferences.enabled || preferences.volume === 0) return;
    unlock();
    if (!loading) return;
    const token = generation;
    if (event === "stroke") {
      if (!preferences.pencil) return;
      movingUntil = performance.now() + 110;
      clearTimeout(stopTimer);
      stopTimer = setTimeout(stopLoop, 110);
      void loading.then(() => {
        if (disposed || token !== generation || !visible || !preferences.enabled || !preferences.pencil || performance.now() >= movingUntil || loop)
          return;
        loop = start("pencil", true);
      });
      return;
    }
    if (!["erase", "fill", "undo", "redo"].includes(event)) return;
    if (event === "erase") {
      if (performance.now() - lastErase < 100) return;
      lastErase = performance.now();
    }
    if (pendingShots.has(event)) return;
    pendingShots.add(event);
    const expires = performance.now() + 250;
    void loading.then(() => {
      pendingShots.delete(event);
      if (disposed || token !== generation || !visible || !preferences.enabled || performance.now() > expires || active.size >= 4)
        return;
      start(event);
    });
  }
  return {
    get preferences() {
      return { ...preferences };
    },
    unlock,
    interaction,
    configure(patch) {
      preferences = { ...preferences, ...patch };
      preferences.volume = Math.max(0, Math.min(1, preferences.volume));
      if (!preferences.enabled || preferences.volume === 0) stopAll();
      else {
        if (!preferences.pencil) stopLoop();
        unlock();
      }
      if (master) master.gain.value = preferences.volume;
      try {
        localStorage.setItem(key, JSON.stringify(preferences));
      } catch {
      }
    },
    setVisible(value) {
      visible = value;
      if (!value) {
        stopAll();
        void context?.suspend().catch(() => {
        });
      }
    },
    dispose() {
      disposed = true;
      requests.abort();
      stopAll();
      void context?.close().catch(() => {
      });
    }
  };
}

// src/panel.mjs
async function mount(container, context) {
  const zh = context.language.startsWith("zh"), t = (a, b) => zh ? a : b;
  const style = document.createElement("style");
  style.textContent = panel_default;
  const root = document.createElement("section");
  root.className = "draw-guess";
  const sound = createDrawingSound(context.resourceBase);
  const soundEvents = new AbortController();
  root.addEventListener("pointerdown", sound.unlock, { capture: true, signal: soundEvents.signal });
  root.addEventListener("keydown", sound.unlock, { capture: true, signal: soundEvents.signal });
  const element = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  };
  const button = (label, callback, className = "") => {
    const node = element("button", className, label);
    node.type = "button";
    node.addEventListener("click", callback);
    return node;
  };
  const heading = element("header", "heading");
  const title = element("div");
  title.append(
    element("h2", "", t("\u4F60\u753B\u6211\u731C", "Draw & Guess")),
    element("p", "muted", t("\u753B\u5F97\u50CF\u4E0D\u50CF\uFF0C\u90FD\u6709\u4E50\u8DA3\u3002", "A little abstract is part of the fun."))
  );
  const clock = element("span", "clock");
  const headingActions = element("div", "actions");
  const soundSettings = element("details", "sound-settings");
  const soundSummary = element("summary", "", t("\u97F3\u6548", "Sound"));
  const soundOptions = element("div", "sound-options");
  for (const [key, label] of [
    ["enabled", t("\u542F\u7528\u97F3\u6548", "Enable sounds")],
    ["pencil", t("\u753B\u7B14\u58F0\u97F3", "Drawing sounds")]
  ]) {
    const row = element("label");
    const checkbox = element("input");
    checkbox.type = "checkbox";
    checkbox.checked = sound.preferences[key];
    checkbox.addEventListener("change", () => sound.configure({ [key]: checkbox.checked }));
    row.append(checkbox, document.createTextNode(label));
    soundOptions.append(row);
  }
  const volumeRow = element("label", "", t("\u97F3\u91CF", "Volume"));
  const volume = element("input");
  volume.type = "range";
  volume.min = "0";
  volume.max = "100";
  volume.value = String(sound.preferences.volume * 100);
  volume.setAttribute("aria-label", t("\u97F3\u6548\u97F3\u91CF", "Sound volume"));
  volume.addEventListener("input", () => sound.configure({ volume: Number(volume.value) / 100 }));
  volumeRow.append(volume);
  soundOptions.append(volumeRow);
  soundSettings.append(soundSummary, soundOptions);
  headingActions.append(soundSettings, clock);
  heading.append(title, headingActions);
  const error = element("p", "error");
  error.setAttribute("role", "alert");
  error.hidden = true;
  const setup = element("div", "setup");
  const duration = element("select");
  duration.setAttribute("aria-label", t("\u6BCF\u8F6E\u65F6\u957F", "Round duration"));
  for (const minutes of [3, 5, 10]) {
    const option = element("option", "", `${minutes} ${t("\u5206\u949F", "min")}`);
    option.value = String(minutes * 60);
    duration.append(option);
  }
  const painter = element("select");
  painter.setAttribute("aria-label", t("\u8C01\u5148\u753B", "First painter"));
  for (const [value, label] of [
    ["human", t("\u6211\u5148\u753B", "I draw first")],
    ["model", t("\u89D2\u8272\u5148\u753B", "Character draws first")]
  ]) {
    const option = element("option", "", label);
    option.value = value;
    painter.append(option);
  }
  const start = button(t("\u5F00\u59CB\u6E38\u620F", "Start game"), () => void beginRun(), "primary");
  setup.append(element("label", "", t("\u6BCF\u8F6E", "Round")), duration, painter, start);
  const status = element("div", "round-status");
  status.setAttribute("role", "status");
  const choices = element("div", "choices");
  const word = element("div", "private-word");
  const hint = element("div", "word-hint");
  hint.setAttribute("aria-live", "polite");
  const result = element("div", "round-result");
  result.setAttribute("role", "status");
  const resultText = element("strong");
  const resultActions = element("div", "actions");
  resultActions.append(
    button(t("\u518D\u6765\u4E00\u8F6E", "Another round"), () => act("next"), "primary"),
    button(t("\u4E0B\u6B21\u518D\u73A9", "Finish playing"), () => act("quit"))
  );
  result.append(resultText, resultActions);
  const canvas = element("div", "drawing");
  const feedback = element("div", "guesses");
  feedback.setAttribute("aria-live", "polite");
  feedback.setAttribute("aria-label", t("\u731C\u6D4B\u8BB0\u5F55", "Guesses"));
  const form = element("form", "guess-form");
  const input = element("input");
  input.type = "text";
  input.maxLength = 40;
  input.placeholder = t("\u4F60\u731C\u8FD9\u662F\u4EC0\u4E48\uFF1F", "What do you think it is?");
  input.setAttribute("aria-label", t("\u4F60\u7684\u731C\u6D4B", "Your guess"));
  const submit = element("button", "primary", t("\u731C\u4E00\u4E0B", "Guess"));
  submit.type = "submit";
  let composing = false;
  input.addEventListener("compositionstart", () => {
    composing = true;
  });
  input.addEventListener("compositionend", () => {
    composing = false;
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && (composing || event.isComposing || event.keyCode === 229))
      event.preventDefault();
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (composing || !input.value.trim()) return;
    const text = input.value.trim();
    input.value = "";
    act("guess", { text });
  });
  form.append(input, submit);
  const bottom = element("footer");
  const note = element(
    "span",
    "muted",
    t("\u753B\u4F5C\u81EA\u52A8\u4FDD\u5B58 \xB7 \u4E0D\u8BA1\u5206", "Drawing saved automatically \xB7 No scores")
  );
  const controls = element("div", "actions");
  const pause = button(t("\u6682\u505C", "Pause"), () => act("pause"));
  const reveal = button(t("\u63ED\u6653\u7B54\u6848", "Reveal answer"), () => act("reveal"));
  const quit = button(t("\u7ED3\u675F\u6E38\u620F", "End game"), () => act("quit"));
  const resume = button(t("\u7EE7\u7EED\u8FD9\u4E00\u8F6E", "Resume round"), () => void beginRun(), "primary");
  controls.append(pause, reveal, quit, resume);
  bottom.append(note, controls);
  const playArea = element("div", "play-area");
  const playContent = element("div", "play-content");
  playContent.append(status, choices, word, hint, result, canvas, feedback, form);
  const preparationOverlay = element("div", "word-loading");
  preparationOverlay.setAttribute("role", "status");
  preparationOverlay.setAttribute("aria-live", "polite");
  preparationOverlay.append(
    element("span", "", t("\u8BF7\u7A0D\u7B49\uFF0C\u6B63\u5728\u51FA\u9898\u4E2D\u2026", "Please wait, preparing words\u2026"))
  );
  playArea.append(playContent, preparationOverlay);
  root.append(heading, setup, error, playArea, bottom);
  container.append(style, root);
  if (!context.canvas) {
    error.hidden = false;
    error.textContent = t(
      "\u8BF7\u66F4\u65B0 LimeA\uFF0C\u5F53\u524D\u7248\u672C\u4E0D\u652F\u6301\u5171\u4EAB\u753B\u677F\u3002",
      "Update LimeA to use the shared canvas."
    );
    return () => {
      soundEvents.abort();
      sound.dispose();
      root.remove();
      style.remove();
    };
  }
  let state = null, busy = false, visible = true, disposed = false, starting = false;
  let queue = Promise.resolve(), pendingScene = null, pendingImage = null, confirmedImage = null, saving = false, saveTimer;
  let renderedRound = null, renderedRevision = -1, snapshotKey = "", choiceKey = "", feedbackKey = "";
  let sequence = 0, appliedSequence = 0;
  const editor = await context.canvas.mount(canvas, {
    document: { version: 1, shapes: [] },
    readOnly: true,
    language: context.language,
    onInteraction: sound.interaction,
    onChange(document2) {
      if (state?.painter !== "human" || state.phase !== "drawing") return;
      pendingScene = document2;
      pendingImage = editor.snapshot();
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => enqueue(flush), 300);
    }
  });
  const scope = () => ({ mode: context.mode, sessionId: context.sessionId });
  const showError = (exception) => {
    if (disposed || context.signal.aborted) return;
    error.hidden = false;
    error.textContent = t(
      "\u64CD\u4F5C\u672A\u5B8C\u6210\uFF0C\u8BF7\u91CD\u8BD5\u3002\u5DF2\u4FDD\u5B58\u7684\u753B\u4F5C\u4F1A\u4FDD\u7559\u3002",
      "Could not complete the action. Your saved drawing is kept."
    );
    console.warn("draw-guess action failed", exception);
  };
  const enqueue = (action) => {
    queue = queue.then(async () => {
      if (!disposed) await action();
    }).catch(showError);
    return queue;
  };
  function update(value, seq) {
    if (disposed || seq < appliedSequence) return;
    appliedSequence = seq;
    state = value;
    render();
  }
  async function command(action, extra = {}) {
    if (!state) return null;
    const seq = ++sequence;
    const value = await context.command("game-action", {
      ...scope(),
      roundId: state.id,
      epoch: state.epoch,
      action,
      ...extra
    });
    if (action !== "snapshot") update(value, seq);
    return value;
  }
  async function flush() {
    if (saving || !pendingScene || state?.phase !== "drawing") return;
    saving = true;
    try {
      while (pendingScene && state?.phase === "drawing") {
        const scene = pendingScene, image = pendingImage;
        pendingScene = null;
        await command("draw", { revision: state.canvasRevision, scene });
        confirmedImage = { key: `${state.id}:${state.epoch}:${state.canvasRevision}`, image };
      }
    } catch (error2) {
      pendingScene = null;
      throw error2;
    } finally {
      saving = false;
    }
  }
  function act(action, extra = {}) {
    enqueue(async () => {
      await flush();
      await command(action, extra);
      error.hidden = true;
      await snapshot();
    });
  }
  async function snapshot() {
    if (!busy || !state || pendingScene || saving || !visible || !["ready", "drawing"].includes(state.phase))
      return;
    const key = `${state.id}:${state.epoch}:${state.canvasRevision}`;
    if (snapshotKey === key) return;
    const image = confirmedImage?.key === key ? confirmedImage.image : editor.snapshot();
    await command("snapshot", { revision: state.canvasRevision, image });
    snapshotKey = key;
  }
  async function load() {
    if (!context.sessionId) {
      render();
      return;
    }
    const seq = ++sequence;
    update(await context.command("load-game", scope()), seq);
    await snapshot();
  }
  async function beginRun() {
    if (busy || starting) return;
    starting = true;
    render();
    try {
      await context.command("save-settings", {
        duration: Number(duration.value),
        firstPainter: painter.value
      });
      const accepted = await context.startRun(
        "play",
        t("\u4E00\u8D77\u73A9\u4F60\u753B\u6211\u731C\u5427\u3002", "Let\u2019s play Draw & Guess.")
      );
      if (!accepted) throw new Error("run-busy");
      error.hidden = true;
      snapshotKey = "";
      await load();
    } catch (exception) {
      showError(exception);
    } finally {
      starting = false;
      render();
    }
  }
  function render() {
    const phase = state?.phase, active = state && !["ended", "paused"].includes(phase);
    const generating = phase === "preparing" || starting && (!state || phase === "ended");
    preparationOverlay.hidden = !generating;
    playContent.inert = generating;
    playArea.hidden = !state && !generating;
    playArea.setAttribute("aria-busy", String(generating));
    root.dataset.phase = phase ?? "idle";
    setup.hidden = Boolean(state && phase !== "ended");
    start.disabled = busy || starting;
    duration.disabled = busy;
    painter.disabled = busy;
    result.hidden = phase !== "result";
    form.hidden = phase !== "drawing" || state?.painter !== "model";
    canvas.hidden = !state;
    feedback.hidden = !state?.guesses.length;
    pause.hidden = !active || phase === "result";
    reveal.hidden = !["drawing", "ready"].includes(phase);
    quit.hidden = !state || phase === "ended" || phase === "result";
    resume.hidden = phase !== "paused";
    resume.disabled = busy || starting;
    status.textContent = !state ? t("\u9009\u597D\u987A\u5E8F\uFF0C\u8F6E\u6D41\u628A\u8111\u6D77\u91CC\u7684\u4E1C\u897F\u753B\u51FA\u6765\u3002", "Choose who draws first, then take turns.") : phase === "paused" ? t("\u672C\u8F6E\u5DF2\u6682\u505C\uFF0C\u753B\u4F5C\u5DF2\u4FDD\u7559\u3002", "Paused. Your drawing is kept.") : phase === "ended" ? t("\u4ECA\u5929\u5148\u753B\u5230\u8FD9\u91CC\u3002", "That was fun. See you next time.") : phase === "result" ? `${t("\u7B2C", "Round ")} ${state.round} ${t("\u8F6E", "")}` : `${t("\u7B2C", "Round ")} ${state.round} ${t("\u8F6E \xB7 ", " \xB7 ")}${state.painter === "human" ? t("\u4F60\u753B\uFF0C\u89D2\u8272\u731C", "You draw, character guesses") : t("\u89D2\u8272\u753B\uFF0C\u4F60\u6765\u731C", "Character draws, you guess")}${state.thinking ? t(" \xB7 \u6B63\u5728\u601D\u8003\u2026", " \xB7 Thinking\u2026") : ""}`;
    if (state?.error && state.error !== "user") {
      error.hidden = false;
      error.textContent = state.error === "interrupted" ? t("\u8FD0\u884C\u4E2D\u65AD\uFF0C\u53EF\u7EE7\u7EED\u8FD9\u4E00\u8F6E\u3002", "Interrupted. You can resume this round.") : t(
        "\u6A21\u578B\u8BF7\u6C42\u6216\u7ED8\u753B\u672A\u5B8C\u6210\uFF0C\u53EF\u7EE7\u7EED\u91CD\u8BD5\uFF1B\u753B\u4F5C\u5DF2\u4FDD\u7559\u3002",
        "The model request or drawing did not complete. Resume to retry; your drawing is kept."
      );
    }
    word.hidden = !state?.word || state.painter !== "human" || Boolean(state.result) || phase === "ended";
    word.textContent = state?.word ? `${t("\u4F60\u7684\u9898\u76EE\uFF1A", "Your word: ")}${state.word} \xB7 ${t("\u53EA\u6709\u4F60\u770B\u5F97\u5230", "Only you can see it")}` : "";
    hint.hidden = !state?.characterCount || Boolean(state.result) || phase === "ended";
    hint.textContent = state?.characterCount ? t(`\u5B57\u6570\u63D0\u793A\uFF1A${state.characterCount} \u4E2A\u5B57`, `Hint: ${state.characterCount} characters`) : "";
    if (phase === "result")
      resultText.textContent = `${state.result === "guessed" ? t("\u731C\u4E2D\u4E86\uFF01", "Got it!") : state.result === "timeout" ? t("\u65F6\u95F4\u5230\u4E86", "Time\u2019s up") : t("\u672C\u8F6E\u63ED\u6653", "Revealed")} \xB7 ${state.word}`;
    const nextChoiceKey = JSON.stringify(state?.choices ?? []);
    choices.hidden = !state?.choices.length;
    if (choiceKey !== nextChoiceKey) {
      choiceKey = nextChoiceKey;
      choices.replaceChildren();
      (state?.choices ?? []).forEach(
        (value, choice) => choices.append(button(value, () => act("choose", { choice }), "word-choice"))
      );
    }
    if (state) {
      const newRound = renderedRound !== state.id;
      if (newRound || state.painter === "model" && renderedRevision !== state.canvasRevision) {
        editor.setDocument(state.scene);
        renderedRound = state.id;
        renderedRevision = state.canvasRevision;
        if (newRound) {
          pendingScene = null;
          confirmedImage = null;
          snapshotKey = "";
        }
      }
      editor.setReadOnly(state.painter !== "human" || phase !== "drawing" || !busy);
      const nextFeedbackKey = JSON.stringify(state.guesses);
      if (feedbackKey !== nextFeedbackKey) {
        feedbackKey = nextFeedbackKey;
        feedback.replaceChildren();
        for (const guess of state.guesses.slice(-6)) {
          const name = guess.by === "human" ? t("\u4F60", "You") : context.characterName || t("\u89D2\u8272", "Character");
          feedback.append(element("span", "guess", `${name}\uFF1A${guess.text}`));
        }
      }
    } else editor.setReadOnly(true);
    clock.textContent = state ? timeLeft() : "";
  }
  function timeLeft() {
    const seconds = Math.ceil(
      Math.max(0, state.deadline ? state.deadline - Date.now() : state.remaining) / 1e3
    );
    return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
  }
  const settings = await context.command("load-settings");
  duration.value = String(settings.duration);
  painter.value = settings.firstPainter;
  const removeRunListener = context.onRunStateChange((value) => {
    busy = value;
    render();
    if (value) snapshotKey = "";
  });
  const removeVisibilityListener = context.onVisibilityChange((value) => {
    visible = value;
    sound.setVisible(value);
    if (!value && busy && state && !["paused", "ended", "result"].includes(state.phase))
      act("pause");
    if (value) enqueue(load);
  });
  let loading = false;
  const poll = setInterval(() => {
    if (disposed || !visible || loading) return;
    loading = true;
    enqueue(async () => {
      try {
        await flush();
        await load();
      } finally {
        loading = false;
      }
    });
  }, 700);
  const timer = setInterval(() => {
    if (state && visible) clock.textContent = timeLeft();
  }, 250);
  await load();
  render();
  return () => {
    disposed = true;
    soundEvents.abort();
    sound.dispose();
    clearTimeout(saveTimer);
    clearInterval(poll);
    clearInterval(timer);
    removeRunListener();
    removeVisibilityListener();
    editor.destroy();
    root.remove();
    style.remove();
  };
}
export {
  mount
};
