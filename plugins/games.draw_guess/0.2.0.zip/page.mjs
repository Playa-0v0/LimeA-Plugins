// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro {\n  margin-bottom: var(--ui-space-8);\n}\n.intro ul {\n  display: grid;\n  gap: var(--ui-space-2);\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.intro li {\n  position: relative;\n  padding-left: var(--ui-space-4);\n  color: var(--muted-foreground);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro li::before {\n  content: '';\n  position: absolute;\n  top: 0.7em;\n  left: 0;\n  width: 0.25rem;\n  height: 0.25rem;\n  border-radius: 50%;\n  background: currentColor;\n}\n.intro strong {\n  color: var(--foreground);\n  font-weight: 600;\n}\n.section-icon,\n.feature-icon,\n.section-count {\n  color: var(--muted-foreground);\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n}\n.section-count {\n  font-size: var(--ui-text-sm);\n  font-weight: 400;\n}\n.features,\n.usage {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.feature-icon {\n  width: 2.25rem;\n  min-height: 2.25rem;\n  align-items: center;\n  justify-content: center;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n.usage p {\n  margin-top: var(--ui-space-4);\n  text-wrap: pretty;\n}\n.usage blockquote {\n  margin: var(--ui-space-3) 0 0;\n  padding: var(--ui-space-2) 0 var(--ui-space-2) var(--ui-space-4);\n  border-left: 2px solid var(--border);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  text-wrap: pretty;\n}\n";

// src/page-strings.mjs
var zh = {
  introLabel: "\u4F60\u753B\u6211\u731C\u80FD\u600E\u4E48\u73A9",
  introTurnTitle: "\u8F6E\u6D41\u4F5C\u753B\uFF1A",
  introTurnDetail: "\u4F60\u548C\u89D2\u8272\u8F6E\u6D41\u5F53\u753B\u5BB6\uFF0C\u6BCF\u8F6E\u4E09\u9009\u4E00\uFF0C\u4E0D\u63D0\u4F9B\u81EA\u547D\u9898\u3002",
  introGuessTitle: "\u8FB9\u753B\u8FB9\u731C\uFF1A",
  introGuessDetail: "\u89D2\u8272\u4F1A\u89C2\u5BDF\u4F60\u5B9E\u9645\u753B\u51FA\u7684\u753B\u9762\u731C\u6D4B\uFF0C\u4F60\u4E5F\u53EF\u4EE5\u968F\u65F6\u8F93\u5165\u7B54\u6848\u3002",
  introCasualTitle: "\u8F7B\u91CF\u966A\u73A9\uFF1A",
  introCasualDetail: "\u4E0D\u8BBE\u79EF\u5206\uFF0C\u62BD\u8C61\u3001\u7B28\u62D9\u7684\u753B\u6CD5\u4E5F\u7B97\u6570\uFF0C\u91CD\u70B9\u662F\u966A\u73A9\u548C\u8868\u8FBE\u3002",
  introReplayTitle: "\u7ED3\u675F\u590D\u76D8\uFF1A",
  introReplayDetail: "\u731C\u4E2D\u6216\u63ED\u6653\u540E\u53EF\u518D\u6765\u4E00\u8F6E\uFF0C\u4E5F\u80FD\u5728\u804A\u5929\u91CC\u56DE\u987E\u6700\u8FD1\u51E0\u8F6E\u7684\u7B54\u6848\u4E0E\u7ED3\u679C\u3002",
  featuresTitle: "\u73A9\u6CD5\u4E0E\u80FD\u529B",
  boardTitle: "\u5171\u4EAB\u753B\u677F",
  boardDetail: "\u753B\u7B14\u3001\u5F62\u72B6\u3001\u6A61\u76AE\u3001\u586B\u8272\u548C\u64A4\u9500\u91CD\u505A\u968F\u804A\u5929\u6253\u5F00\uFF1B\u753B\u677F\u83B7\u5F97\u7126\u70B9\u65F6\u53EF\u7528 Ctrl+Z \u64A4\u9500\u3001Ctrl+Y \u91CD\u505A\u3002",
  secretTitle: "\u79C1\u5BC6\u51FA\u9898",
  secretDetail: "\u9898\u76EE\u53EA\u5BF9\u753B\u5BB6\u53EF\u89C1\uFF0C\u731C\u6D4B\u65B9\u53EA\u4F1A\u5F97\u5230\u5B57\u6570\u63D0\u793A\uFF0C\u770B\u4E0D\u5230\u9898\u76EE\u548C\u5019\u9009\u8BCD\u3002",
  agentTitle: "\u89D2\u8272\u4F5C\u753B",
  agentDetail: "\u89D2\u8272\u4F1A\u89C2\u5BDF\u81EA\u5DF1\u5B9E\u9645\u753B\u51FA\u7684\u753B\u9762\uFF0C\u7EE7\u7EED\u8865\u753B\u6216\u4FEE\u6539\uFF1B\u7B49\u5F85\u65F6\u4F60\u4E5F\u53EF\u4EE5\u7EE7\u7EED\u753B\u3002",
  historyTitle: "\u56DE\u5408\u8BB0\u5F55",
  historyDetail: "\u7ED3\u675F\u540E\u7684\u516C\u5F00\u7ED3\u679C\u4F1A\u4EA4\u56DE\u804A\u5929\uFF0C\u89D2\u8272\u4E5F\u80FD\u7528\u8BB0\u5F55\u5DE5\u5177\u590D\u76D8\u6700\u8FD1\u5DF2\u63ED\u6653\u7684\u8F6E\u6B21\u3002",
  usageTitle: "\u5F00\u59CB\u4F7F\u7528",
  usage: "\u4ECE\u804A\u5929\u53F3\u4FA7\u6253\u5F00\u300C\u5C0F\u6E38\u620F\u300D\uFF0C\u6216\u76F4\u63A5\u8BA9\u89D2\u8272\u966A\u4F60\u73A9\u3002\u4F60\u53EF\u4EE5\u8FD9\u6837\u8BF4\uFF1A",
  usageExample: "\u966A\u6211\u73A9\u4E00\u5C40\u4F60\u753B\u6211\u731C\u5427\uFF0C\u4F60\u5148\u753B\u3002"
};
var en = {
  introLabel: "How Draw & Guess works",
  introTurnTitle: "Take turns drawing:",
  introTurnDetail: "You and the character alternate as the artist, picking one of three words each round.",
  introGuessTitle: "Draw and guess:",
  introGuessDetail: "The character looks at the actual drawing and guesses; you can enter an answer at any time.",
  introCasualTitle: "Casual play:",
  introCasualDetail: "There is no scoring; abstract or rough drawings are fine. The point is playing together.",
  introReplayTitle: "Review the round:",
  introReplayDetail: "After a correct guess or reveal, play again, or review recent answers and results in chat.",
  featuresTitle: "How to play",
  boardTitle: "Shared canvas",
  boardDetail: "Brush, shapes, eraser, fill, undo and redo open beside the chat. Use Ctrl+Z to undo and Ctrl+Y to redo when the canvas has focus.",
  secretTitle: "Secret words",
  secretDetail: "Only the artist sees the word; the guesser receives a character count, never the word or candidates.",
  agentTitle: "The character draws",
  agentDetail: "The character watches its own drawing and keeps adding or changing it; you can keep drawing while it thinks.",
  historyTitle: "Round history",
  historyDetail: "Public results return to the chat after a round, and the character can review recent revealed rounds.",
  usageTitle: "Start playing",
  usage: "Open Mini games from the right side of the chat, or ask the character to play. Try saying:",
  usageExample: "Let's play Draw & Guess. You draw first."
};

// src/page.mjs
function mount(container, context) {
  if (!context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "draw-guess-page";
  root.innerHTML = `
    <section class="intro" aria-label="">
      <ul>
        <li><strong></strong><span></span></li>
        <li><strong></strong><span></span></li>
        <li><strong></strong><span></span></li>
        <li><strong></strong><span></span></li>
      </ul>
    </section>
    <section class="features" aria-labelledby="draw-guess-features-title">
      <h2 id="draw-guess-features-title"><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span><span class="section-count"></span></h2>
      <ul>
        <li><span class="feature-icon" data-icon="blocks"></span><div><h3></h3><p></p></div></li>
        <li><span class="feature-icon" data-icon="shield-check"></span><div><h3></h3><p></p></div></li>
        <li><span class="feature-icon" data-icon="message-square"></span><div><h3></h3><p></p></div></li>
        <li><span class="feature-icon" data-icon="list-tree"></span><div><h3></h3><p></p></div></li>
      </ul>
    </section>
    <section class="usage" aria-labelledby="draw-guess-usage-title">
      <h2 id="draw-guess-usage-title"><span class="section-icon" data-icon="message-square"></span><span class="heading-label"></span></h2>
      <p></p>
      <blockquote></blockquote>
    </section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query(".intro").setAttribute("aria-label", t.introLabel);
  [...root.querySelectorAll(".intro li")].forEach((item, i) => {
    item.querySelector("strong").textContent = [
      t.introTurnTitle,
      t.introGuessTitle,
      t.introCasualTitle,
      t.introReplayTitle
    ][i];
    item.querySelector("span").textContent = [
      t.introTurnDetail,
      t.introGuessDetail,
      t.introCasualDetail,
      t.introReplayDetail
    ][i];
  });
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  query(".features h2 .section-count").textContent = String(4);
  [...root.querySelectorAll(".features li")].forEach((item, i) => {
    item.querySelector("h3").textContent = [
      t.boardTitle,
      t.secretTitle,
      t.agentTitle,
      t.historyTitle
    ][i];
    item.querySelector("p").textContent = [
      t.boardDetail,
      t.secretDetail,
      t.agentDetail,
      t.historyDetail
    ][i];
  });
  query(".usage h2 .heading-label").textContent = t.usageTitle;
  query(".usage p").textContent = t.usage;
  query(".usage blockquote").textContent = t.usageExample;
  const handles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name))
      handles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    else slot.hidden = true;
  }
  function cleanup() {
    for (const handle of handles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  return cleanup;
}
export {
  mount
};
