// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro {\n  margin-bottom: var(--ui-space-8);\n}\n.intro ul {\n  display: grid;\n  gap: var(--ui-space-2);\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.intro li {\n  position: relative;\n  padding-left: var(--ui-space-4);\n  color: var(--muted-foreground);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro li::before {\n  content: '';\n  position: absolute;\n  top: 0.7em;\n  left: 0;\n  width: 0.25rem;\n  height: 0.25rem;\n  border-radius: 50%;\n  background: currentColor;\n}\n.intro strong {\n  color: var(--foreground);\n  font-weight: 600;\n}\n.section-icon,\n.feature-icon,\n.section-count {\n  color: var(--muted-foreground);\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n}\n.section-count {\n  font-size: var(--ui-text-sm);\n  font-weight: 400;\n}\n.features,\n.usage {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.feature-icon {\n  width: 2.25rem;\n  min-height: 2.25rem;\n  align-items: center;\n  justify-content: center;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n.usage p {\n  margin-top: var(--ui-space-4);\n  text-wrap: pretty;\n}\n.usage blockquote {\n  margin: var(--ui-space-3) 0 0;\n  padding: var(--ui-space-2) 0 var(--ui-space-2) var(--ui-space-4);\n  border-left: 2px solid var(--border);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  text-wrap: pretty;\n}\n";

// src/page-strings.mjs
var zh = {
  introLabel: "\u4F60\u753B\u6211\u731C\u80FD\u600E\u4E48\u73A9",
  introTurnTitle: "\u8F6E\u6D41\u5F53\u753B\u5BB6\uFF1A",
  introTurnDetail: "\u4F60\u548C\u89D2\u8272\u4EA4\u66FF\u51FA\u9898\uFF0C\u6BCF\u8F6E\u4ECE\u4E09\u4E2A\u8BCD\u91CC\u9009\u4E00\u4E2A\u753B\u51FA\u6765\u3002",
  introGuessTitle: "\u8FB9\u753B\u8FB9\u731C\uFF1A",
  introGuessDetail: "\u89D2\u8272\u4F1A\u89C2\u5BDF\u4F60\u5B9E\u9645\u753B\u51FA\u7684\u753B\u9762\u731C\u6D4B\uFF0C\u4F60\u4E5F\u53EF\u4EE5\u968F\u65F6\u8F93\u5165\u7B54\u6848\u3002",
  introCasualTitle: "\u5171\u4EAB\u753B\u677F\uFF1A",
  introCasualDetail: "\u753B\u7B14\u3001\u5F62\u72B6\u3001\u6A61\u76AE\u3001\u586B\u8272\u548C\u64A4\u9500\u91CD\u505A\u90FD\u5728\u804A\u5929\u53F3\u4FA7\uFF0C\u4E0D\u8BBE\u79EF\u5206\u3002",
  introReplayTitle: "\u7ED3\u675F\u80FD\u590D\u76D8\uFF1A",
  introReplayDetail: "\u731C\u4E2D\u6216\u63ED\u6653\u540E\u53EF\u518D\u6765\u4E00\u8F6E\uFF0C\u4E5F\u80FD\u56DE\u770B\u6700\u8FD1\u51E0\u8F6E\u7684\u7B54\u6848\u4E0E\u7ED3\u679C\u3002",
  featuresTitle: "\u63D2\u4EF6\u529F\u80FD",
  startTitle: "\u5F00\u5C40\u4E0E\u9009\u8BCD",
  startDetail: "\u6BCF\u8F6E\u753B\u5BB6\u4ECE\u4E09\u4E2A\u8BCD\u91CC\u9009\u4E00\u4E2A\uFF0C\u5C55\u793A\u8FC7\u7684\u8BCD\u9000\u51FA\u672C\u5C40\uFF1B\u4E0D\u63D0\u4F9B\u81EA\u547D\u9898\uFF0C\u731C\u8BCD\u65B9\u770B\u4E0D\u5230\u9898\u76EE\u548C\u5019\u9009\u3002",
  turnsTitle: "\u8F6E\u6D41\u4F5C\u753B",
  turnsDetail: "\u53CC\u65B9\u4EA4\u66FF\u5F53\u753B\u5BB6\uFF0C\u9ED8\u8BA4\u4EA4\u6362\u5148\u624B\uFF1B\u6BCF\u8F6E\u53EF\u9009 3\u30015\u300110 \u5206\u949F\uFF0C\u7B49\u5F85\u9009\u8BCD\u548C\u51C6\u5907\u9996\u6279\u7ED8\u753B\u4E0D\u8BA1\u65F6\u3002",
  boardTitle: "\u5171\u4EAB\u753B\u677F",
  boardDetail: "\u753B\u7B14\u3001\u692D\u5706\u3001\u77E9\u5F62\u3001\u6A61\u76AE\u3001\u989C\u6599\u6876\u3001\u989C\u8272\u548C 1\u201324 px \u7C97\u7EC6\uFF1B\u652F\u6301\u64A4\u9500\u91CD\u505A\u3001Ctrl+Z / Ctrl+Y\uFF0C\u4EE5\u53CA\u7ED8\u753B\u3001\u64E6\u9664\u3001\u586B\u8272\u97F3\u6548\u548C\u9759\u97F3\u3002",
  agentTitle: "\u89D2\u8272\u4F5C\u753B",
  agentDetail: "\u89D2\u8272\u79D8\u5BC6\u9009\u8BCD\u540E\u5206\u6279\u753B\u56FE\uFF0C\u5E76\u89C2\u5BDF\u81EA\u5DF1\u5B9E\u9645\u753B\u51FA\u7684\u753B\u9762\u7EE7\u7EED\u8865\u753B\u6216\u4FEE\u6539\uFF1B\u5B83\u601D\u8003\u65F6\u4F60\u53EF\u4EE5\u7EE7\u7EED\u753B\u3002",
  guessTitle: "\u79C1\u5BC6\u731C\u8BCD",
  guessDetail: "\u731C\u6D4B\u65B9\u53EA\u4F1A\u5F97\u5230\u5B57\u6570\u63D0\u793A\uFF0C\u770B\u4E0D\u5230\u7B54\u6848\u3001\u5019\u9009\u8BCD\u6216\u89D2\u8272\u8349\u7A3F\uFF1B\u7B54\u6848\u6309\u5B8C\u6574\u8BCD\u6216\u751F\u6210\u65F6\u7684\u540C\u4E49\u8BCD\u5339\u914D\u3002",
  historyTitle: "\u7ED3\u679C\u4E0E\u590D\u76D8",
  historyDetail: "\u731C\u4E2D\u3001\u5230\u65F6\u6216\u70B9\u51FB\u63ED\u6653\u540E\u7ACB\u5373\u663E\u793A\u7B54\u6848\u548C\u300C\u518D\u6765\u4E00\u8F6E / \u4E0B\u6B21\u518D\u73A9\u300D\uFF1B\u6700\u8FD1\u5DF2\u63ED\u6653\u7684\u8F6E\u6B21\u53EF\u5728\u804A\u5929\u91CC\u56DE\u770B\u3002",
  usageTitle: "\u5F00\u59CB\u4F7F\u7528",
  usage: "\u4ECE\u804A\u5929\u53F3\u4FA7\u6253\u5F00\u300C\u5C0F\u6E38\u620F\u300D\uFF0C\u6216\u76F4\u63A5\u8BA9\u89D2\u8272\u966A\u4F60\u73A9\u3002\u4F60\u53EF\u4EE5\u8FD9\u6837\u8BF4\uFF1A",
  usageExample: "\u966A\u6211\u73A9\u4E00\u5C40\u4F60\u753B\u6211\u731C\u5427\uFF0C\u4F60\u5148\u753B\u3002"
};
var en = {
  introLabel: "How Draw & Guess works",
  introTurnTitle: "Take turns drawing:",
  introTurnDetail: "You and the character alternate as the artist, picking one of three words each round.",
  introGuessTitle: "Draw and guess:",
  introGuessDetail: "The character looks at the actual drawing and guesses; you can enter an answer at any time.",
  introCasualTitle: "Shared canvas:",
  introCasualDetail: "Brush, shapes, eraser, fill, undo and redo open beside the chat; there is no scoring.",
  introReplayTitle: "Review afterwards:",
  introReplayDetail: "After a correct guess or reveal, play again, or review recent answers and results.",
  featuresTitle: "Plugin features",
  startTitle: "Rounds and words",
  startDetail: "Each round the artist picks one of three words; used words leave the pool, and the guesser never sees the word or candidates.",
  turnsTitle: "Alternating turns",
  turnsDetail: "You and the character alternate as artist, switching first player by default. Pick 3, 5 or 10 minutes per round; word selection and first-batch drawing do not count down.",
  boardTitle: "Shared canvas",
  boardDetail: "Brush, ellipse, rectangle, eraser, paint bucket, colors and 1\u201324 px width; undo/redo, Ctrl+Z / Ctrl+Y, and drawing, erasing and fill sounds with mute controls.",
  agentTitle: "The character draws",
  agentDetail: "The character secretly picks a word, draws in batches, watches its own drawing and keeps adding or changing it; you can keep drawing while it thinks.",
  guessTitle: "Private guessing",
  guessDetail: "The guesser only receives a character count, never the word, candidates or the character\u2019s draft. Answers match the exact word or its generated synonyms.",
  historyTitle: "Results and review",
  historyDetail: "After a correct guess, timeout or reveal, see the answer and choose play again or stop; recent revealed rounds can be reviewed in chat.",
  usageTitle: "Start playing",
  usage: "Open Mini games from the right side of the chat, or ask the character to play. Try saying:",
  usageExample: "Let's play Draw & Guess. You draw first."
};

// src/page.mjs
function mount(container, context) {
  if (!context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "draw-guess-page";
  root.innerHTML = `
    <section class="intro" aria-label="">
      <ul></ul>
    </section>
    <section class="features" aria-labelledby="draw-guess-features-title">
      <h2 id="draw-guess-features-title"><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span><span class="section-count"></span></h2>
      <ul></ul>
    </section>
    <section class="usage" aria-labelledby="draw-guess-usage-title">
      <h2 id="draw-guess-usage-title"><span class="section-icon" data-icon="message-square"></span><span class="heading-label"></span></h2>
      <p></p>
      <blockquote></blockquote>
    </section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query(".intro").setAttribute("aria-label", t.introLabel);
  const introItems = [
    [t.introTurnTitle, t.introTurnDetail],
    [t.introGuessTitle, t.introGuessDetail],
    [t.introCasualTitle, t.introCasualDetail],
    [t.introReplayTitle, t.introReplayDetail]
  ];
  const introList = query(".intro ul");
  for (const [title, detail] of introItems) {
    const item = document.createElement("li");
    const heading = document.createElement("strong");
    heading.textContent = title;
    const copy = document.createElement("span");
    copy.textContent = detail;
    item.append(heading, copy);
    introList.append(item);
  }
  const features = [
    { icon: "circle-dashed", title: t.startTitle, detail: t.startDetail },
    { icon: "refresh-cw", title: t.turnsTitle, detail: t.turnsDetail },
    { icon: "blocks", title: t.boardTitle, detail: t.boardDetail },
    { icon: "message-square", title: t.agentTitle, detail: t.agentDetail },
    { icon: "shield-check", title: t.guessTitle, detail: t.guessDetail },
    { icon: "list-tree", title: t.historyTitle, detail: t.historyDetail }
  ];
  const featureList = query(".features ul");
  for (const feature of features) {
    const item = document.createElement("li");
    const iconSlot = document.createElement("span");
    iconSlot.className = "feature-icon";
    iconSlot.dataset.icon = feature.icon;
    const copy = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = feature.title;
    const detail = document.createElement("p");
    detail.textContent = feature.detail;
    copy.append(heading, detail);
    item.append(iconSlot, copy);
    featureList.append(item);
  }
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  query(".features h2 .section-count").textContent = String(features.length);
  query(".usage h2 .heading-label").textContent = t.usageTitle;
  query(".usage p").textContent = t.usage;
  query(".usage blockquote").textContent = t.usageExample;
  const handles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name))
      handles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    else slot.hidden = true;
  }
  function cleanup() {
    for (const handle of handles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  return cleanup;
}
export {
  mount
};
