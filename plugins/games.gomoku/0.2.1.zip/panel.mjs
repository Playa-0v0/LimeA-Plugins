var oe=`:host {
  color: var(--foreground, #ededed);
  font-family: inherit;
}
* {
  box-sizing: border-box;
}
.gomoku {
  --ink: var(--foreground, #ededed);
  --soft: var(--muted-foreground, #b5b5b5);
  --line: var(--border, #353535);
  --green: var(--primary, #adeb78);
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  padding: 20px;
  color: var(--ink);
}
button {
  font: inherit;
  cursor: pointer;
  color: var(--ink);
  background: transparent;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 12px;
  transition: background-color 150ms ease-out;
}
button:hover:not(:disabled) {
  background: var(--muted, #282828);
}
button:focus-visible,
summary:focus-visible {
  outline: 2px solid var(--green);
  outline-offset: 3px;
}
button:disabled {
  cursor: default;
  opacity: 0.45;
}
button.primary {
  color: var(--primary-foreground, #1c2b12);
  background: var(--green);
  border-color: transparent;
}
button.primary:hover:not(:disabled) {
  background: color-mix(in srgb, var(--green) 88%, var(--ink));
}
[hidden] {
  display: none !important;
}
.heading,
.heading-actions,
.bottom,
.actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.heading h2 {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
}
.heading p,
.note {
  margin: 7px 0 0;
  color: var(--soft);
  font-size: 12px;
  line-height: 1.6;
}
.refresh,
.sound,
.settings-button {
  padding: 6px 10px;
  font-size: 12px;
}
.heading-actions {
  flex-wrap: wrap;
  justify-content: flex-end;
}
.settings-dialog {
  width: min(440px, calc(100vw - 32px));
  max-height: calc(100vh - 40px);
  overflow: auto;
  padding: 24px;
  color: var(--ink);
  background: var(--background, #141414);
  border: 1px solid var(--line);
  border-radius: 14px;
  box-shadow: 0 16px 56px #0006;
}
.settings-dialog::backdrop {
  background: #0008;
}
.dialog-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.dialog-heading h3 {
  margin: 0;
  font-size: 18px;
}
.close-settings {
  padding: 2px 10px;
  font-size: 24px;
  border: 0;
}
.settings-footer {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
.scoreboard {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 14px;
  width: min(100%, 540px);
  margin: 0 auto;
  padding: 16px 0;
  border-block: 1px solid var(--line);
}
.player {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 9px;
}
.player.model {
  justify-content: flex-end;
  text-align: right;
}
.name {
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: 14px;
}
.color-label {
  display: block;
  margin-top: 4px;
  font-size: 11px;
  color: var(--soft);
}
.player[data-turn='true'] .name {
  color: var(--green);
}
.piece {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  flex: none;
  background: #777;
}
.piece[data-color='black'] {
  background: radial-gradient(circle at 30% 25%, #535761, #191b20 75%);
  border: 1px solid #62656d;
}
.piece[data-color='white'] {
  background: radial-gradient(circle at 30% 25%, #fff, #d7d9df 85%);
  border: 1px solid #b7bbc3;
}
.scores {
  text-align: center;
}
.scores strong {
  font-size: 26px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
  letter-spacing: 0.06em;
  white-space: nowrap;
}
.round {
  display: block;
  margin-top: 4px;
  color: var(--soft);
  font-size: 11px;
}
.status {
  margin: 0;
  text-align: center;
  font-size: 14px;
  min-height: 22px;
  line-height: 1.5;
}
.status[data-result='true'] {
  color: var(--green);
}
.turn-panel[data-result='true'] {
  position: sticky;
  top: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 14px;
  background: var(--background, #141414);
  border: 1px solid var(--line);
  border-radius: 10px;
}
.result-actions {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
}
.result-actions button {
  min-width: 100px;
}
.result-hint {
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  text-align: center;
  line-height: 1.6;
}
.board-layout {
  display: grid;
  grid-template: 16px minmax(0, 1fr) / 16px minmax(0, 1fr);
  gap: 4px;
  width: min(100%, 540px);
  align-self: center;
}
.columns {
  grid-column: 2;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.rows {
  grid-column: 1;
  grid-row: 2;
  display: grid;
  grid-template-rows: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.board {
  grid-column: 2;
  grid-row: 2;
  width: 100%;
  aspect-ratio: 1;
  position: relative;
  border-radius: 8px;
  background: #d8b785;
  border: 1px solid #a88b60;
}
.board > svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}
.cells {
  position: absolute;
  inset: 0;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  grid-template-rows: repeat(15, 1fr);
}
.cell {
  position: relative;
  display: block;
  min-width: 0;
  min-height: 0;
  padding: 0;
  border: 0;
  border-radius: 0;
}
.cell:disabled {
  opacity: 1;
}
.cell:hover:not(:disabled) {
  background: transparent;
}
.cell:focus-visible {
  outline: 2px solid #473a28;
  outline-offset: -2px;
  border-radius: 4px;
}
.stone {
  position: absolute;
  inset: 9%;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 25%, #525660, #17191f 80%);
  box-shadow: 0 1px 2px #40321c66;
}
.cell[data-color='white'] .stone,
.cells[data-human-color='white'] .cell:not([data-color]):hover:not(:disabled)::before {
  background: radial-gradient(circle at 30% 25%, #fff, #d9dce2 80%);
}
.cell:not([data-color]) .stone {
  display: none;
}
.cell[data-last='true'] .stone::after {
  content: '';
  position: absolute;
  inset: 40%;
  background: #fff;
  border-radius: 50%;
}
.cell[data-last='true'][data-color='white'] .stone::after {
  background: #313640;
}
.cell[data-win='true'] .stone {
  outline: 3px solid #527a21;
  outline-offset: 1px;
}
@media (hover: hover) {
  .cell:not([data-color]):hover:not(:disabled)::before {
    content: '';
    position: absolute;
    inset: 9%;
    border-radius: 50%;
    background: #202228;
    opacity: 0.4;
  }
}
.last {
  text-align: center;
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  min-height: 18px;
}
.bottom {
  flex-wrap: wrap;
  margin-top: auto;
  padding-top: 6px;
}
.actions {
  flex-wrap: wrap;
  justify-content: flex-end;
  margin-left: auto;
}
.quit,
.resign {
  font-size: 12px;
}
.error {
  margin: 0;
  color: var(--destructive, #ff9284);
  font-size: 12px;
  line-height: 1.6;
}
.rules {
  color: var(--soft);
  font-size: 12px;
  line-height: 1.7;
}
.rules summary {
  cursor: pointer;
  width: fit-content;
}
.rules p {
  margin: 8px 0 0;
}
@media (max-width: 480px) {
  .gomoku {
    padding: 14px;
    gap: 16px;
  }
  .scoreboard {
    gap: 8px;
  }
  .player {
    gap: 6px;
  }
  .scores strong {
    font-size: 22px;
  }
  .piece {
    width: 20px;
    height: 20px;
  }
  .heading {
    flex-wrap: wrap;
  }
  .heading-actions {
    margin-left: auto;
  }
}
@media (prefers-reduced-motion: reduce) {
  button {
    transition: none;
  }
}
`;var re=`.gomoku-settings {
  --ink: var(--foreground, #ededed);
  --soft: var(--muted-foreground, #b5b5b5);
  --line: var(--border, #353535);
  --green: var(--primary, #adeb78);
  color: var(--ink);
  font: inherit;
}
.gomoku-settings * {
  box-sizing: border-box;
}
.gomoku-settings [hidden] {
  display: none !important;
}
.gomoku-settings .settings-intro {
  margin: 8px 0 24px;
  color: var(--soft);
  font-size: 13px;
}
.gomoku-settings fieldset {
  border: 0;
  margin: 0 0 20px;
  padding: 0;
  min-width: 0;
}
.gomoku-settings legend {
  margin-bottom: 12px;
  font-size: 13px;
  font-weight: 600;
}
.gomoku-settings label {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 12px 0;
  cursor: pointer;
}
.gomoku-settings label + label {
  border-top: 1px solid var(--line);
}
.gomoku-settings input {
  accent-color: var(--green);
  margin: 3px 0 0;
  flex: none;
}
.gomoku-settings input:focus-visible,
.gomoku-settings button:focus-visible {
  outline: 2px solid var(--green);
  outline-offset: 3px;
}
.gomoku-settings strong {
  font-size: 14px;
  font-weight: 500;
}
.gomoku-settings small {
  display: block;
  font-size: 12px;
  line-height: 1.6;
  margin-top: 5px;
  color: var(--soft);
}
.gomoku-settings .difficulty-options > div {
  display: flex;
  flex-wrap: wrap;
  gap: 0 24px;
}
.gomoku-settings .difficulty-options label + label {
  border: 0;
}
.gomoku-settings .settings-feedback {
  margin: 0 0 12px;
  min-height: 20px;
  color: var(--soft);
  font-size: 12px;
}
.gomoku-settings .settings-feedback[role='alert'] {
  color: var(--destructive, #ff9284);
}
.gomoku-settings .settings-note {
  margin-top: 12px;
}
.gomoku-settings button {
  font: inherit;
  cursor: pointer;
  color: var(--ink);
  background: transparent;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 12px;
}
.gomoku-settings button:hover {
  background: var(--muted, #282828);
}
`;function se(j,s){let r=(a,y)=>s.language.startsWith("en")?y:a,e=document.createElement("section");e.className="gomoku-settings";let p=document.createElement("style");p.textContent=re,e.innerHTML=`<p class="settings-intro">${r("\u9009\u62E9\u89D2\u8272\u5982\u4F55\u601D\u8003\u4E0B\u4E00\u6B65\u3002","Choose how your character considers its next move.")}</p>
    <form><fieldset class="mode-options"><legend>${r("\u843D\u5B50\u65B9\u5F0F","Move selection")}</legend>
    <label><input type="radio" name="mode" value="model"><span><strong>${r("\u6A21\u578B\u843D\u5B50","Model only")}</strong><small>${r("\u89D2\u8272\u81EA\u5DF1\u8BFB\u68CB\u76D8\u3001\u60F3\u7B56\u7565\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002","Your character reads the board and chooses its own strategy.")}</small></span></label>
    <label><input type="radio" name="mode" value="engine"><span><strong>${r("\u5F15\u64CE\u8F85\u52A9","Engine assisted")}</strong><small>${r("\u8BA1\u7B97\u4E09\u4E2A\u5019\u9009\u843D\u70B9\u53CA\u8BC4\u5206\uFF0C\u7531\u89D2\u8272\u51B3\u5B9A\u6700\u7EC8\u843D\u5B50\u3002","Calculate up to three scored candidates. Your character makes the final choice.")}</small></span></label></fieldset>
    <fieldset class="difficulty-options" hidden><legend>${r("\u5206\u6790\u96BE\u5EA6","Analysis level")}</legend><div>
    <label><input type="radio" name="difficulty" value="normal"><span><strong>${r("\u666E\u901A","Normal")}</strong><small>${r("\u8F83\u5FEB\u5206\u6790\uFF0C\u8F7B\u677E\u966A\u73A9","Quick analysis, casual play")}</small></span></label>
    <label><input type="radio" name="difficulty" value="hard"><span><strong>${r("\u56F0\u96BE","Hard")}</strong><small>${r("\u591A\u60F3\u51E0\u6B65\uFF0C\u5BFB\u627E\u653B\u9632\u673A\u4F1A","Deeper search for threats")}</small></span></label></div></fieldset>
    <p class="settings-feedback" role="status"></p><button class="retry-settings" type="button" hidden>${r("\u91CD\u65B0\u8BFB\u53D6","Reload settings")}</button>
    <small class="settings-note">${r("\u81EA\u52A8\u4FDD\u5B58\uFF0C\u4ECE\u4E0B\u4E00\u5C40\u751F\u6548\u3002\u6240\u6709\u804A\u5929\u5171\u7528\u6B64\u8BBE\u7F6E\u3002","Saved automatically. Applies next round, across chats.")}</small></form>`,e.prepend(p),j.append(e);let w=e.querySelector("form"),n=e.querySelector(".settings-feedback"),h=e.querySelector(".retry-settings"),d=new AbortController,g=!1,k=!1,m=!1,t=()=>{for(let a of w.querySelectorAll("input"))a.disabled=!k||m},c=a=>{for(let y of w.querySelectorAll("input"))y.checked=a[y.name]===y.value;e.querySelector(".difficulty-options").hidden=a.mode!=="engine"},i=a=>{k=!1,n.textContent=a,n.setAttribute("role","alert"),h.hidden=!1};async function b(){if(!(g||m)){m=!0,k=!1,h.hidden=!0,t(),n.setAttribute("role","status"),n.textContent=r("\u6B63\u5728\u8BFB\u53D6\u8BBE\u7F6E\u2026","Loading settings\u2026");try{let a=await s.command("load-settings",{});if(g)return;c(a),k=!0,n.textContent=""}catch{g||i(r("\u8BBE\u7F6E\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002","Could not load settings. Please retry."))}finally{m=!1,g||t()}}}w.addEventListener("submit",a=>a.preventDefault(),{signal:d.signal}),w.addEventListener("change",async()=>{if(g||!k||m)return;let a=Object.fromEntries(new FormData(w));c(a),m=!0,t(),n.textContent=r("\u6B63\u5728\u4FDD\u5B58\u2026","Saving\u2026");try{let y=await s.command("save-settings",a);if(g)return;c(y),n.textContent=r("\u5DF2\u4FDD\u5B58\uFF0C\u4E0B\u4E00\u5C40\u751F\u6548","Saved for the next round")}catch{g||i(r("\u4FDD\u5B58\u672A\u786E\u8BA4\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6\u8BBE\u7F6E\u540E\u6838\u5BF9\u3002","Save not confirmed. Reload and check settings."))}finally{m=!1,g||t()}},{signal:d.signal}),h.addEventListener("click",()=>void b(),{signal:d.signal});let $=()=>{g||(g=!0,d.abort(),e.remove(),s.signal.removeEventListener("abort",$))};return s.signal.addEventListener("abort",$,{once:!0}),s.signal.aborted?$():b(),$}var J="ABCDEFGHIJKLMNO";function ae(j){let s=!1;try{s=localStorage.getItem("games.gomoku.muted")==="1"}catch{}let r,e,p,w,n=0,h=!1,d=!0,g=new Set,k=new AbortController,m=()=>{n++;for(let c of g)c.stop();g.clear()},t=()=>{if(!(h||s||!d))try{if(r??=new AudioContext,r.state==="suspended"&&(w=r.resume().catch(()=>{})),!p){let c=r;p=fetch(new URL("assets/stone.mp3",j),{signal:k.signal}).then(i=>{if(!i.ok)throw new Error("sound-unavailable");return i.arrayBuffer()}).then(i=>c.decodeAudioData(i)).then(i=>{h||(e=i)}).catch(()=>{p=null})}}catch{}};return{get muted(){return s},unlock:t,play(){if(h||s||!d||!r)return;let c=n;Promise.all([p,w]).then(()=>{if(c!==n||h||s||!d||!e||r.state!=="running")return;let i=r.createBufferSource(),b=r.createGain();i.buffer=e,b.gain.value=.65,i.connect(b).connect(r.destination),g.add(i),i.onended=()=>{g.delete(i),i.disconnect(),b.disconnect()},i.start()}).catch(()=>{})},toggle(){s=!s;try{localStorage.setItem("games.gomoku.muted",s?"1":"0")}catch{}s?m():t()},setVisible(c){d=c,d?r&&t():(m(),r?.suspend().catch(()=>{}))},dispose(){h=!0,k.abort(),m(),r?.close().catch(()=>{})}}}function ke(j,s){let r=s.language.startsWith("en"),e=(o,u)=>r?u:o,p=document.createElement("section");p.className="gomoku";let w=document.createElement("style");w.textContent=oe,p.innerHTML=`<header class="heading"><div><h2>${e("\u4E94\u5B50\u68CB","Gomoku")}</h2><p>${e("\u548C\u5F53\u524D\u89D2\u8272\u4E00\u8D77\uFF0C\u843D\u5B50\u6210\u5C40\u3002","A game with your current character.")}</p></div><div class="heading-actions"><button class="sound" type="button"></button><button class="refresh" type="button">${e("\u540C\u6B65\u68CB\u5C40","Sync game")}</button></div></header>
    <div class="scoreboard"><div class="player human"><span class="piece"></span><div><strong class="name">${e("\u4F60","You")}</strong><span class="color-label"></span></div></div><div class="scores"><strong>0 : 0</strong><span class="round">${e("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors")}</span></div><div class="player model"><div><strong class="name"></strong><span class="color-label"></span></div><span class="piece"></span></div></div>
    <div class="turn-panel"><p class="status" role="status"></p><div class="result-actions" hidden></div><p class="result-hint" hidden>${e("\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\u5F00\u5C40\u3002","Play again selected. The next round starts after your character responds.")}</p></div><div class="board-layout"><div class="columns" aria-hidden="true"></div><div class="rows" aria-hidden="true"></div><div class="board"><svg viewBox="0 0 15 15" aria-hidden="true"></svg><div class="cells" role="group" aria-label="${e("\u4E94\u5B50\u68CB\u68CB\u76D8","Gomoku board")}"></div></div></div><p class="last"></p>
    <p class="error" role="alert" hidden></p><details class="rules"><summary>${e("\u73A9\u6CD5\u4E0E\u89C4\u5219","How to play")}</summary><p>${e("15\xD715 \u81EA\u7531\u4E94\u5B50\u68CB\uFF0C\u65E0\u7981\u624B\u3002\u9ED1\u68CB\u5148\u884C\uFF0C\u6A2A\u3001\u7AD6\u6216\u659C\u5411\u8FDE\u6210\u4E94\u9897\u53CA\u4EE5\u4E0A\u83B7\u80DC\u3002\u68CB\u76D8\u586B\u6EE1\u4E14\u65E0\u4EBA\u83B7\u80DC\u5219\u548C\u68CB\u3002\u70B9\u51FB\u4EA4\u70B9\u843D\u5B50\uFF1B\u6700\u540E\u4E00\u624B\u6709\u5706\u70B9\u6807\u8BB0\u3002\u952E\u76D8\u65B9\u5411\u952E\u9009\u70B9\uFF0C\u56DE\u8F66\u843D\u5B50\u3002\u89D2\u8272\u81EA\u5DF1\u601D\u8003\u843D\u5B50\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002","15\xD715 freestyle Gomoku, with no forbidden moves. Black starts. Five or more stones in a row wins; a full board is a draw. Click an intersection to play. A dot marks the last move. Use arrow keys to select and Enter to play. Your character chooses its moves using the current model.")}</p></details>
    <footer class="bottom"><small class="note">${e("\u68CB\u5C40\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4E2D\u65AD\u540E\u7EE7\u7EED","Saved automatically. Resume anytime.")}</small><div class="actions"><button class="resign" type="button" hidden>${e("\u8BA4\u8F93","Resign")}</button><button class="quit" type="button" hidden>${e("\u7ED3\u675F\u6E38\u620F","End game")}</button><button class="start primary" type="button">${e("\u5F00\u59CB\u5BF9\u5C40","Start game")}</button></div></footer>`,p.prepend(w),j.append(p);let n=o=>p.querySelector(o),h=document.createElement("button");h.type="button",h.className="settings-button",h.textContent=e("\u5BF9\u5C40\u8BBE\u7F6E","Game settings"),n(".heading-actions").append(h);let d=document.createElement("dialog");d.className="settings-dialog",d.setAttribute("aria-labelledby","gomoku-settings-title"),d.innerHTML=`<div class="dialog-heading"><h3 id="gomoku-settings-title">${e("\u5BF9\u5C40\u8BBE\u7F6E","Game settings")}</h3><button class="close-settings" type="button" aria-label="${e("\u5173\u95ED\u8BBE\u7F6E","Close settings")}">\xD7</button></div><div class="settings-body"></div><div class="settings-footer"><button class="done-settings primary" type="button">${e("\u5B8C\u6210","Done")}</button></div>`,p.append(d);let g=n(".cells"),k=n(".status"),m=n(".error"),t=null,c=!1,i=!1,b=!0,$=!0,a=!1,y=!1,O,q=0,T=0,R=112,G=!1,K=()=>{},ee=()=>{},v=new AbortController,D=()=>{};h.addEventListener("click",()=>{d.open||(D(),d.showModal(),D=se(d.querySelector(".settings-body"),s))},{signal:v.signal}),d.addEventListener("close",()=>{d.open||D()},{signal:v.signal});for(let o of d.querySelectorAll(".close-settings,.done-settings"))o.addEventListener("click",()=>d.close(),{signal:v.signal});let L=ae(s.resourceBase),W=!0;p.addEventListener("pointerdown",L.unlock,{capture:!0,signal:v.signal}),p.addEventListener("keydown",L.unlock,{capture:!0,signal:v.signal});let F={mode:s.mode,sessionId:s.sessionId},I=[];n(".columns").replaceChildren(...[...J].map(o=>{let u=document.createElement("span");return u.textContent=o,u})),n(".rows").replaceChildren(...Array.from({length:15},(o,u)=>{let l=document.createElement("span");return l.textContent=String(u+1),l}));let ie=Array.from({length:15},(o,u)=>`<path d="M.5 ${u+.5}H14.5 M${u+.5} .5V14.5"/>`).join("");n(".board > svg").innerHTML=`<g fill="none" stroke="#8b704b" stroke-width=".025">${ie}</g><g fill="#6c5232">${[[3.5,3.5],[11.5,3.5],[7.5,7.5],[3.5,11.5],[11.5,11.5]].map(([o,u])=>`<circle cx="${o}" cy="${u}" r=".09"/>`).join("")}</g>`;let le=()=>s.characterName?.trim()||e("\u89D2\u8272","Character"),A=()=>i&&!c&&b&&t?.status==="active"&&t.turn==="human",Y=o=>{m.textContent=o,m.hidden=!1},_=o=>{if(a||o&&t?.matchId===o.matchId&&o.revision<t.revision)return;let u=!W&&t&&o&&t.matchId===o.matchId&&t.roundId===o.roundId&&o.moves.length>t.moves.length&&o.status!=="paused";t=o,W=!1,u&&L.play(),i=!0,G&&(m.hidden=!0,G=!1),E()};function E(){if(a)return;p.dataset.status=t?.status??"idle",p.dataset.turn=t?.turn??"",p.dataset.roundId=t?.roundId??"",p.dataset.moves=String(t?.moves.length??0);let o=le();n(".model .name").textContent=o,n(".model .name").title=o;for(let f of["human","model"]){let x=t?t.black===f?"black":"white":"";n(`.${f} .piece`).dataset.color=x,n(`.${f} .color-label`).textContent=x?x==="black"?e("\u9ED1\u68CB \xB7 \u5148\u624B","Black \xB7 first"):e("\u767D\u68CB \xB7 \u540E\u624B","White \xB7 second"):e("\u5F85\u5206\u914D","Unassigned"),n(`.player.${f}`).dataset.turn=String(t?.status==="active"&&t.turn===f)}n(".scores strong").textContent=`${t?.scores.human??0} : ${t?.scores.model??0}`,n(".round").textContent=t?e(`\u7B2C ${t.roundNumber} \u5C40 \xB7 \u548C\u68CB ${t.scores.draw}`,`Round ${t.roundNumber} \xB7 Draws ${t.scores.draw}`):e("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors");let u=t?.status==="active",l=t&&["round-over","waiting-replay"].includes(t.status),M=!!t?.replayRequested;n(".turn-panel").dataset.result=String(!!l),n(".result-actions").hidden=!l,n(".result-hint").hidden=!l||!M&&t.status!=="round-over",n(".result-hint").textContent=M?e("\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\u5F00\u5C40\u3002","Play again selected. The next round starts after your character responds."):e("\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\uFF0C\u53EF\u9009\u62E9\u4E0B\u6B21\u518D\u73A9\u3002","You can leave after your character finishes responding.");let N=n(l?".result-actions":".actions");n(".start").parentElement!==N&&(l?N.append(n(".start"),n(".quit")):N.append(n(".quit"),n(".start"))),k.dataset.result=String(!!l),k.textContent=i?t?t.status==="ended"?e("\u5BF9\u5C40\u5DF2\u7ED3\u675F\uFF0C\u6BD4\u5206\u5DF2\u4FDD\u5B58","Game ended. Scores saved."):l?t.winner==="draw"?e("\u8FD9\u4E00\u5C40\u548C\u68CB","This round is a draw"):t.winner==="human"?e("\u8FD9\u4E00\u5C40\uFF0C\u4F60\u8D62\u4E86","You won this round"):e(`\u8FD9\u4E00\u5C40\uFF0C${o}\u8D62\u4E86`,`${o} won this round`):t.status==="paused"||!b?e("\u5BF9\u5C40\u5DF2\u6682\u505C\uFF0C\u68CB\u76D8\u5DF2\u4FDD\u7559","Game paused. Your board is saved."):t.turn==="human"?e("\u8F6E\u5230\u4F60\u843D\u5B50","Your turn"):e(`${o}\u6B63\u5728\u601D\u8003\u2026`,`${o} is thinking\u2026`):b?e("\u8BF7\u7B49\u5F53\u524D\u5BF9\u8BDD\u7ED3\u675F\u540E\u518D\u5F00\u5C40","Wait for the current conversation to finish"):e("\u51C6\u5907\u597D\u4E86\u5417\uFF1F\u5F00\u59CB\u4E00\u5C40\u4E94\u5B50\u68CB\u5427","Ready for a game of Gomoku?"):e("\u6B63\u5728\u540C\u6B65\u68CB\u5C40\u2026","Syncing game\u2026");let z=new Map((t?.moves??[]).map(f=>[`${f.column}${f.row}`,f.player])),U=new Set((t?.winningLine??[]).map(f=>`${f.column}${f.row}`)),C=t?.moves.at(-1);g.dataset.humanColor=t?.black==="human"?"black":"white";for(let[f,x]of I.entries()){let B=x.dataset.point,X=z.get(B),V=X?t.black===X?"black":"white":null;V?x.dataset.color=V:delete x.dataset.color,x.dataset.last=String(C&&B===`${C.column}${C.row}`),x.dataset.win=String(U.has(B)),x.disabled=!A()||!!X,x.tabIndex=f===R&&!x.disabled?0:-1,x.setAttribute("aria-label",V?`${B} ${V==="black"?e("\u9ED1\u68CB","black"):e("\u767D\u68CB","white")}`:e(`\u843D\u5B50\u4E8E ${B}`,`Play ${B}`))}A()&&(I[R]?.disabled||!I.some(f=>f.tabIndex===0))&&(R=I.findIndex(f=>!f.disabled),R>=0&&(I[R].tabIndex=0)),n(".last").textContent=C?e(`\u7B2C ${t.moves.length} \u624B \xB7 ${C.player==="human"?"\u4F60":o}\u843D\u5728 ${C.column}${C.row}`,`Move ${t.moves.length} \xB7 ${C.player==="human"?"You":o} played ${C.column}${C.row}`):e("\u9ED1\u68CB\u5148\u884C \xB7 \u70B9\u51FB\u4EA4\u70B9\u843D\u5B50","Black starts \xB7 Click an intersection"),n(".start").hidden=!!(t&&b&&!l&&!["ended","paused"].includes(t.status)),n(".start").disabled=c||!i||b&&!l||l&&M,n(".start").textContent=l?e("\u518D\u6765\u4E00\u5C40","Play again"):t&&!["ended"].includes(t.status)?e("\u7EE7\u7EED\u5BF9\u5C40","Resume game"):e("\u5F00\u59CB\u5BF9\u5C40","Start game"),n(".quit").hidden=!t||t.status==="ended";let te=A()||t?.status==="waiting-replay"||t?.status==="paused"&&!b,ne=e("\u8BF7\u7B49\u5230\u4F60\u7684\u56DE\u5408\u6216\u89D2\u8272\u56DE\u5E94\u7ED3\u675F\u540E\u64CD\u4F5C","Wait for your turn or for your character to finish responding");n(".quit").disabled=c||!i||!te,n(".quit").title=te?"":ne,n(".quit").textContent=l?e("\u4E0B\u6B21\u518D\u73A9","Maybe later"):e("\u7ED3\u675F\u6E38\u620F","End game"),n(".resign").hidden=!u||!b,n(".resign").disabled=!A(),n(".resign").title=A()?"":ne,n(".note").textContent=u&&t.turn==="model"?e("\u89D2\u8272\u6B63\u5728\u601D\u8003\uFF0C\u8F6E\u5230\u4F60\u65F6\u53EF\u8BA4\u8F93\u6216\u7ED3\u675F","Your character is thinking. Resign or leave on your turn."):e("\u68CB\u5C40\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4E2D\u65AD\u540E\u7EE7\u7EED","Saved automatically. Resume anytime."),n(".sound").textContent=L.muted?e("\u58F0\u97F3\u5173","Sound off"):e("\u58F0\u97F3\u5F00","Sound on"),n(".sound").setAttribute("aria-pressed",String(!L.muted)),n(".refresh").disabled=c||y}async function H(){if(a||y||c||!$)return;y=!0;let o=q;try{let u=await s.command("load-match",F);o===q&&!a&&_(u)}catch{!a&&o===q&&(i=!1,G=!0,Y(e("\u68CB\u5C40\u540C\u6B65\u5931\u8D25\uFF0C\u8BF7\u70B9\u51FB\u201C\u540C\u6B65\u68CB\u5C40\u201D\u91CD\u8BD5\u3002","Could not sync. Click \u201CSync game\u201D to retry.")))}finally{y=!1,E()}}function Q(){let o=++T;clearTimeout(O),!(a||!$)&&H().finally(()=>{!a&&$&&o===T&&(O=setTimeout(Q,600))})}async function P(o,u){if(!(a||c||!i||!t)&&!(o==="resign"&&n(".resign").disabled)&&!(o==="quit"&&n(".quit").disabled)){c=!0,q++,m.hidden=!0,E();try{_(await s.command("match-action",{...F,matchId:t.matchId,roundId:t.roundId,revision:t.revision,action:o,...u?{row:Number(u.slice(1)),column:u[0]}:{}}))}catch{if(!a){Y(e("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u5DF2\u91CD\u65B0\u8BFB\u53D6\u68CB\u5C40\uFF0C\u8BF7\u6838\u5BF9\u540E\u518D\u64CD\u4F5C\u3002","Action not confirmed. Reloading the saved board; check before trying again."));try{_(await s.command("load-match",F))}catch{i=!1,G=!0,Y(e("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u68CB\u5C40\u540C\u6B65\u4E5F\u5931\u8D25\u4E86\uFF0C\u8BF7\u6062\u590D\u8FDE\u63A5\u540E\u540C\u6B65\u6838\u5BF9\u3002","Action and sync could not be confirmed. Reconnect and sync the saved board."))}}}finally{c=!1,E()}}}async function de(){if(!(a||c||!i)){if(["round-over","waiting-replay"].includes(t?.status)&&b)return P("replay");if(!b){c=!0,q++,m.hidden=!0,E();try{if(!await s.startRun("start",e("\u966A\u6211\u4E0B\u4E94\u5B50\u68CB\u5427\uFF0C\u8BF7\u4F7F\u7528\u4E94\u5B50\u68CB\u63D2\u4EF6\u5F00\u59CB\u6216\u7EE7\u7EED\u5BF9\u5C40\u3002","Play Gomoku with me. Use the Gomoku plugin to start or resume.")))throw new Error("start-failed")}catch{a||Y(e("\u672A\u80FD\u5F00\u59CB\u5BF9\u5C40\uFF0C\u8BF7\u68C0\u67E5\u5F53\u524D\u6A21\u578B\u914D\u7F6E\u540E\u91CD\u8BD5\u3002","Could not start. Check your current model settings and try again."))}finally{c=!1,E(),H()}}}}for(let o=1;o<=15;o++)for(let u of J){let l=document.createElement("button");l.type="button",l.className="cell",l.dataset.point=`${u}${o}`,l.innerHTML='<span class="stone" aria-hidden="true"></span>',l.addEventListener("click",()=>{A()&&P("move",l.dataset.point)},{signal:v.signal}),l.addEventListener("keydown",M=>{let N={ArrowLeft:-1,ArrowRight:1,ArrowUp:-15,ArrowDown:15}[M.key];if(!N||!A())return;M.preventDefault();let z=I.indexOf(l);for(let U=0;U<225;U++)if(z=(z+N+225)%225,!I[z].disabled){R=z,E(),I[z].focus();break}},{signal:v.signal}),I.push(l),g.append(l)}n(".start").addEventListener("click",()=>void de(),{signal:v.signal}),n(".quit").addEventListener("click",()=>void P("quit"),{signal:v.signal}),n(".resign").addEventListener("click",()=>void P("resign"),{signal:v.signal}),n(".refresh").addEventListener("click",()=>void H(),{signal:v.signal}),n(".sound").addEventListener("click",()=>{L.toggle(),E()},{signal:v.signal});let Z=()=>{a||(a=!0,q++,T++,clearTimeout(O),v.abort(),L.dispose(),D(),d.close(),K(),ee(),s.signal.removeEventListener("abort",Z),p.remove())};return s.signal.addEventListener("abort",Z,{once:!0}),K=s.onRunStateChange(o=>{b=o,E(),H()}),ee=s.onVisibilityChange(o=>{$=o,L.setVisible(o),$||(W=!0),$?Q():(d.close(),T++,clearTimeout(O))}),E(),s.signal.aborted?Z():Q(),Z}export{ke as mount};
