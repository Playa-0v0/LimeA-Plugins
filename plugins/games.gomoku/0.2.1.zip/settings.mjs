var y=`.gomoku-settings {
  --ink: var(--foreground, #ededed);
  --soft: var(--muted-foreground, #b5b5b5);
  --line: var(--border, #353535);
  --green: var(--primary, #adeb78);
  color: var(--ink);
  font: inherit;
}
.gomoku-settings * {
  box-sizing: border-box;
}
.gomoku-settings [hidden] {
  display: none !important;
}
.gomoku-settings .settings-intro {
  margin: 8px 0 24px;
  color: var(--soft);
  font-size: 13px;
}
.gomoku-settings fieldset {
  border: 0;
  margin: 0 0 20px;
  padding: 0;
  min-width: 0;
}
.gomoku-settings legend {
  margin-bottom: 12px;
  font-size: 13px;
  font-weight: 600;
}
.gomoku-settings label {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 12px 0;
  cursor: pointer;
}
.gomoku-settings label + label {
  border-top: 1px solid var(--line);
}
.gomoku-settings input {
  accent-color: var(--green);
  margin: 3px 0 0;
  flex: none;
}
.gomoku-settings input:focus-visible,
.gomoku-settings button:focus-visible {
  outline: 2px solid var(--green);
  outline-offset: 3px;
}
.gomoku-settings strong {
  font-size: 14px;
  font-weight: 500;
}
.gomoku-settings small {
  display: block;
  font-size: 12px;
  line-height: 1.6;
  margin-top: 5px;
  color: var(--soft);
}
.gomoku-settings .difficulty-options > div {
  display: flex;
  flex-wrap: wrap;
  gap: 0 24px;
}
.gomoku-settings .difficulty-options label + label {
  border: 0;
}
.gomoku-settings .settings-feedback {
  margin: 0 0 12px;
  min-height: 20px;
  color: var(--soft);
  font-size: 12px;
}
.gomoku-settings .settings-feedback[role='alert'] {
  color: var(--destructive, #ff9284);
}
.gomoku-settings .settings-note {
  margin-top: 12px;
}
.gomoku-settings button {
  font: inherit;
  cursor: pointer;
  color: var(--ink);
  background: transparent;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 12px;
}
.gomoku-settings button:hover {
  background: var(--muted, #282828);
}
`;function w(h,r){let e=(t,i)=>r.language.startsWith("en")?i:t,s=document.createElement("section");s.className="gomoku-settings";let m=document.createElement("style");m.textContent=y,s.innerHTML=`<p class="settings-intro">${e("\u9009\u62E9\u89D2\u8272\u5982\u4F55\u601D\u8003\u4E0B\u4E00\u6B65\u3002","Choose how your character considers its next move.")}</p>
    <form><fieldset class="mode-options"><legend>${e("\u843D\u5B50\u65B9\u5F0F","Move selection")}</legend>
    <label><input type="radio" name="mode" value="model"><span><strong>${e("\u6A21\u578B\u843D\u5B50","Model only")}</strong><small>${e("\u89D2\u8272\u81EA\u5DF1\u8BFB\u68CB\u76D8\u3001\u60F3\u7B56\u7565\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002","Your character reads the board and chooses its own strategy.")}</small></span></label>
    <label><input type="radio" name="mode" value="engine"><span><strong>${e("\u5F15\u64CE\u8F85\u52A9","Engine assisted")}</strong><small>${e("\u8BA1\u7B97\u4E09\u4E2A\u5019\u9009\u843D\u70B9\u53CA\u8BC4\u5206\uFF0C\u7531\u89D2\u8272\u51B3\u5B9A\u6700\u7EC8\u843D\u5B50\u3002","Calculate up to three scored candidates. Your character makes the final choice.")}</small></span></label></fieldset>
    <fieldset class="difficulty-options" hidden><legend>${e("\u5206\u6790\u96BE\u5EA6","Analysis level")}</legend><div>
    <label><input type="radio" name="difficulty" value="normal"><span><strong>${e("\u666E\u901A","Normal")}</strong><small>${e("\u8F83\u5FEB\u5206\u6790\uFF0C\u8F7B\u677E\u966A\u73A9","Quick analysis, casual play")}</small></span></label>
    <label><input type="radio" name="difficulty" value="hard"><span><strong>${e("\u56F0\u96BE","Hard")}</strong><small>${e("\u591A\u60F3\u51E0\u6B65\uFF0C\u5BFB\u627E\u653B\u9632\u673A\u4F1A","Deeper search for threats")}</small></span></label></div></fieldset>
    <p class="settings-feedback" role="status"></p><button class="retry-settings" type="button" hidden>${e("\u91CD\u65B0\u8BFB\u53D6","Reload settings")}</button>
    <small class="settings-note">${e("\u81EA\u52A8\u4FDD\u5B58\uFF0C\u4ECE\u4E0B\u4E00\u5C40\u751F\u6548\u3002\u6240\u6709\u804A\u5929\u5171\u7528\u6B64\u8BBE\u7F6E\u3002","Saved automatically. Applies next round, across chats.")}</small></form>`,s.prepend(m),h.append(s);let l=s.querySelector("form"),o=s.querySelector(".settings-feedback"),p=s.querySelector(".retry-settings"),g=new AbortController,n=!1,d=!1,a=!1,u=()=>{for(let t of l.querySelectorAll("input"))t.disabled=!d||a},f=t=>{for(let i of l.querySelectorAll("input"))i.checked=t[i.name]===i.value;s.querySelector(".difficulty-options").hidden=t.mode!=="engine"},b=t=>{d=!1,o.textContent=t,o.setAttribute("role","alert"),p.hidden=!1};async function v(){if(!(n||a)){a=!0,d=!1,p.hidden=!0,u(),o.setAttribute("role","status"),o.textContent=e("\u6B63\u5728\u8BFB\u53D6\u8BBE\u7F6E\u2026","Loading settings\u2026");try{let t=await r.command("load-settings",{});if(n)return;f(t),d=!0,o.textContent=""}catch{n||b(e("\u8BBE\u7F6E\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u91CD\u8BD5\u3002","Could not load settings. Please retry."))}finally{a=!1,n||u()}}}l.addEventListener("submit",t=>t.preventDefault(),{signal:g.signal}),l.addEventListener("change",async()=>{if(n||!d||a)return;let t=Object.fromEntries(new FormData(l));f(t),a=!0,u(),o.textContent=e("\u6B63\u5728\u4FDD\u5B58\u2026","Saving\u2026");try{let i=await r.command("save-settings",t);if(n)return;f(i),o.textContent=e("\u5DF2\u4FDD\u5B58\uFF0C\u4E0B\u4E00\u5C40\u751F\u6548","Saved for the next round")}catch{n||b(e("\u4FDD\u5B58\u672A\u786E\u8BA4\uFF0C\u8BF7\u91CD\u65B0\u8BFB\u53D6\u8BBE\u7F6E\u540E\u6838\u5BF9\u3002","Save not confirmed. Reload and check settings."))}finally{a=!1,n||u()}},{signal:g.signal}),p.addEventListener("click",()=>void v(),{signal:g.signal});let c=()=>{n||(n=!0,g.abort(),s.remove(),r.signal.removeEventListener("abort",c))};return r.signal.addEventListener("abort",c,{once:!0}),r.signal.aborted?c():v(),c}export{w as mount};
