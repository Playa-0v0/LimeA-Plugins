var ee=`:host {
  color: var(--foreground, #ededed);
  font-family: inherit;
}
* {
  box-sizing: border-box;
}
.gomoku {
  --ink: var(--foreground, #ededed);
  --soft: var(--muted-foreground, #b5b5b5);
  --line: var(--border, #353535);
  --green: var(--primary, #adeb78);
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  padding: 20px;
  color: var(--ink);
}
button {
  font: inherit;
  cursor: pointer;
  color: var(--ink);
  background: transparent;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 12px;
  transition: background-color 150ms ease-out;
}
button:hover:not(:disabled) {
  background: var(--muted, #282828);
}
button:focus-visible,
summary:focus-visible {
  outline: 2px solid var(--green);
  outline-offset: 3px;
}
button:disabled {
  cursor: default;
  opacity: 0.45;
}
button.primary {
  color: var(--primary-foreground, #1c2b12);
  background: var(--green);
  border-color: transparent;
}
button.primary:hover:not(:disabled) {
  background: color-mix(in srgb, var(--green) 88%, var(--ink));
}
[hidden] {
  display: none !important;
}
.heading,
.heading-actions,
.bottom,
.actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.heading h2 {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
}
.heading p,
.note {
  margin: 7px 0 0;
  color: var(--soft);
  font-size: 12px;
  line-height: 1.6;
}
.refresh,
.sound {
  padding: 6px 10px;
  font-size: 12px;
}
.scoreboard {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 14px;
  width: min(100%, 540px);
  margin: 0 auto;
  padding: 16px 0;
  border-block: 1px solid var(--line);
}
.player {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 9px;
}
.player.model {
  justify-content: flex-end;
  text-align: right;
}
.name {
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: 14px;
}
.color-label {
  display: block;
  margin-top: 4px;
  font-size: 11px;
  color: var(--soft);
}
.player[data-turn='true'] .name {
  color: var(--green);
}
.piece {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  flex: none;
  background: #777;
}
.piece[data-color='black'] {
  background: radial-gradient(circle at 30% 25%, #535761, #191b20 75%);
  border: 1px solid #62656d;
}
.piece[data-color='white'] {
  background: radial-gradient(circle at 30% 25%, #fff, #d7d9df 85%);
  border: 1px solid #b7bbc3;
}
.scores {
  text-align: center;
}
.scores strong {
  font-size: 26px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
  letter-spacing: 0.06em;
  white-space: nowrap;
}
.round {
  display: block;
  margin-top: 4px;
  color: var(--soft);
  font-size: 11px;
}
.status {
  margin: 0;
  text-align: center;
  font-size: 14px;
  min-height: 22px;
  line-height: 1.5;
}
.status[data-result='true'] {
  color: var(--green);
}
.turn-panel[data-result='true'] {
  position: sticky;
  top: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 14px;
  background: var(--background, #141414);
  border: 1px solid var(--line);
  border-radius: 10px;
}
.result-actions {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
}
.result-actions button {
  min-width: 100px;
}
.result-hint {
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  text-align: center;
  line-height: 1.6;
}
.board-layout {
  display: grid;
  grid-template: 16px minmax(0, 1fr) / 16px minmax(0, 1fr);
  gap: 4px;
  width: min(100%, 540px);
  align-self: center;
}
.columns {
  grid-column: 2;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.rows {
  grid-column: 1;
  grid-row: 2;
  display: grid;
  grid-template-rows: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.board {
  grid-column: 2;
  grid-row: 2;
  width: 100%;
  aspect-ratio: 1;
  position: relative;
  border-radius: 8px;
  background: #d8b785;
  border: 1px solid #a88b60;
}
.board > svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}
.cells {
  position: absolute;
  inset: 0;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  grid-template-rows: repeat(15, 1fr);
}
.cell {
  position: relative;
  display: block;
  min-width: 0;
  min-height: 0;
  padding: 0;
  border: 0;
  border-radius: 0;
}
.cell:disabled {
  opacity: 1;
}
.cell:hover:not(:disabled) {
  background: transparent;
}
.cell:focus-visible {
  outline: 2px solid #473a28;
  outline-offset: -2px;
  border-radius: 4px;
}
.stone {
  position: absolute;
  inset: 9%;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 25%, #525660, #17191f 80%);
  box-shadow: 0 1px 2px #40321c66;
}
.cell[data-color='white'] .stone,
.cells[data-human-color='white'] .cell:not([data-color]):hover:not(:disabled)::before {
  background: radial-gradient(circle at 30% 25%, #fff, #d9dce2 80%);
}
.cell:not([data-color]) .stone {
  display: none;
}
.cell[data-last='true'] .stone::after {
  content: '';
  position: absolute;
  inset: 40%;
  background: #fff;
  border-radius: 50%;
}
.cell[data-last='true'][data-color='white'] .stone::after {
  background: #313640;
}
.cell[data-win='true'] .stone {
  outline: 3px solid #527a21;
  outline-offset: 1px;
}
@media (hover: hover) {
  .cell:not([data-color]):hover:not(:disabled)::before {
    content: '';
    position: absolute;
    inset: 9%;
    border-radius: 50%;
    background: #202228;
    opacity: 0.4;
  }
}
.last {
  text-align: center;
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  min-height: 18px;
}
.bottom {
  flex-wrap: wrap;
  margin-top: auto;
  padding-top: 6px;
}
.actions {
  flex-wrap: wrap;
  justify-content: flex-end;
  margin-left: auto;
}
.quit,
.resign {
  font-size: 12px;
}
.error {
  margin: 0;
  color: var(--destructive, #ff9284);
  font-size: 12px;
  line-height: 1.6;
}
.rules {
  color: var(--soft);
  font-size: 12px;
  line-height: 1.7;
}
.rules summary {
  cursor: pointer;
  width: fit-content;
}
.rules p {
  margin: 8px 0 0;
}
@media (max-width: 480px) {
  .gomoku {
    padding: 14px;
    gap: 16px;
  }
  .scoreboard {
    gap: 8px;
  }
  .player {
    gap: 6px;
  }
  .scores strong {
    font-size: 22px;
  }
  .piece {
    width: 20px;
    height: 20px;
  }
  .heading {
    flex-wrap: wrap;
  }
  .heading-actions {
    margin-left: auto;
  }
}
@media (prefers-reduced-motion: reduce) {
  button {
    transition: none;
  }
}
`;var _="ABCDEFGHIJKLMNO";function te(H){let a=!1;try{a=localStorage.getItem("games.gomoku.muted")==="1"}catch{}let g,t,c,q,n=0,k=!1,$=!0,h=new Set,e=new AbortController,p=()=>{n++;for(let l of h)l.stop();h.clear()},f=()=>{if(!(k||a||!$))try{if(g??=new AudioContext,g.state==="suspended"&&(q=g.resume().catch(()=>{})),!c){let l=g;c=fetch(new URL("assets/stone.mp3",H),{signal:e.signal}).then(i=>{if(!i.ok)throw new Error("sound-unavailable");return i.arrayBuffer()}).then(i=>l.decodeAudioData(i)).then(i=>{k||(t=i)}).catch(()=>{c=null})}}catch{}};return{get muted(){return a},unlock:f,play(){if(k||a||!$||!g)return;let l=n;Promise.all([c,q]).then(()=>{if(l!==n||k||a||!$||!t||g.state!=="running")return;let i=g.createBufferSource(),u=g.createGain();i.buffer=t,u.gain.value=.65,i.connect(u).connect(g.destination),h.add(i),i.onended=()=>{h.delete(i),i.disconnect(),u.disconnect()},i.start()}).catch(()=>{})},toggle(){a=!a;try{localStorage.setItem("games.gomoku.muted",a?"1":"0")}catch{}a?p():f()},setVisible(l){$=l,$?g&&f():(p(),g?.suspend().catch(()=>{}))},dispose(){k=!0,e.abort(),p(),g?.close().catch(()=>{})}}}function pe(H,a){let g=a.language.startsWith("en"),t=(r,s)=>g?s:r,c=document.createElement("section");c.className="gomoku";let q=document.createElement("style");q.textContent=ee,c.innerHTML=`<header class="heading"><div><h2>${t("\u4E94\u5B50\u68CB","Gomoku")}</h2><p>${t("\u548C\u5F53\u524D\u89D2\u8272\u4E00\u8D77\uFF0C\u843D\u5B50\u6210\u5C40\u3002","A game with your current character.")}</p></div><div class="heading-actions"><button class="sound" type="button"></button><button class="refresh" type="button">${t("\u540C\u6B65\u68CB\u5C40","Sync game")}</button></div></header>
    <div class="scoreboard"><div class="player human"><span class="piece"></span><div><strong class="name">${t("\u4F60","You")}</strong><span class="color-label"></span></div></div><div class="scores"><strong>0 : 0</strong><span class="round">${t("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors")}</span></div><div class="player model"><div><strong class="name"></strong><span class="color-label"></span></div><span class="piece"></span></div></div>
    <div class="turn-panel"><p class="status" role="status"></p><div class="result-actions" hidden></div><p class="result-hint" hidden>${t("\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\u5F00\u5C40\u3002","Play again selected. The next round starts after your character responds.")}</p></div><div class="board-layout"><div class="columns" aria-hidden="true"></div><div class="rows" aria-hidden="true"></div><div class="board"><svg viewBox="0 0 15 15" aria-hidden="true"></svg><div class="cells" role="group" aria-label="${t("\u4E94\u5B50\u68CB\u68CB\u76D8","Gomoku board")}"></div></div></div><p class="last"></p>
    <p class="error" role="alert" hidden></p><details class="rules"><summary>${t("\u73A9\u6CD5\u4E0E\u89C4\u5219","How to play")}</summary><p>${t("15\xD715 \u81EA\u7531\u4E94\u5B50\u68CB\uFF0C\u65E0\u7981\u624B\u3002\u9ED1\u68CB\u5148\u884C\uFF0C\u6A2A\u3001\u7AD6\u6216\u659C\u5411\u8FDE\u6210\u4E94\u9897\u53CA\u4EE5\u4E0A\u83B7\u80DC\u3002\u68CB\u76D8\u586B\u6EE1\u4E14\u65E0\u4EBA\u83B7\u80DC\u5219\u548C\u68CB\u3002\u70B9\u51FB\u4EA4\u70B9\u843D\u5B50\uFF1B\u6700\u540E\u4E00\u624B\u6709\u5706\u70B9\u6807\u8BB0\u3002\u952E\u76D8\u65B9\u5411\u952E\u9009\u70B9\uFF0C\u56DE\u8F66\u843D\u5B50\u3002\u89D2\u8272\u81EA\u5DF1\u601D\u8003\u843D\u5B50\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002","15\xD715 freestyle Gomoku, with no forbidden moves. Black starts. Five or more stones in a row wins; a full board is a draw. Click an intersection to play. A dot marks the last move. Use arrow keys to select and Enter to play. Your character chooses its moves using the current model.")}</p></details>
    <footer class="bottom"><small class="note">${t("\u68CB\u5C40\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4E2D\u65AD\u540E\u7EE7\u7EED","Saved automatically. Resume anytime.")}</small><div class="actions"><button class="resign" type="button" hidden>${t("\u8BA4\u8F93","Resign")}</button><button class="quit" type="button" hidden>${t("\u7ED3\u675F\u6E38\u620F","End game")}</button><button class="start primary" type="button">${t("\u5F00\u59CB\u5BF9\u5C40","Start game")}</button></div></footer>`,c.prepend(q),H.append(c);let n=r=>c.querySelector(r),k=n(".cells"),$=n(".status"),h=n(".error"),e=null,p=!1,f=!1,l=!0,i=!0,u=!1,B=!1,M,I=0,N=0,L=112,T=!1,J=()=>{},K=()=>{},v=new AbortController,S=te(a.resourceBase),P=!0;c.addEventListener("pointerdown",S.unlock,{capture:!0,signal:v.signal}),c.addEventListener("keydown",S.unlock,{capture:!0,signal:v.signal});let D={mode:a.mode,sessionId:a.sessionId},w=[];n(".columns").replaceChildren(...[..._].map(r=>{let s=document.createElement("span");return s.textContent=r,s})),n(".rows").replaceChildren(...Array.from({length:15},(r,s)=>{let o=document.createElement("span");return o.textContent=String(s+1),o}));let ne=Array.from({length:15},(r,s)=>`<path d="M.5 ${s+.5}H14.5 M${s+.5} .5V14.5"/>`).join("");n(".board > svg").innerHTML=`<g fill="none" stroke="#8b704b" stroke-width=".025">${ne}</g><g fill="#6c5232">${[[3.5,3.5],[11.5,3.5],[7.5,7.5],[3.5,11.5],[11.5,11.5]].map(([r,s])=>`<circle cx="${r}" cy="${s}" r=".09"/>`).join("")}</g>`;let re=()=>a.characterName?.trim()||t("\u89D2\u8272","Character"),C=()=>f&&!p&&l&&e?.status==="active"&&e.turn==="human",O=r=>{h.textContent=r,h.hidden=!1},V=r=>{if(u||r&&e?.matchId===r.matchId&&r.revision<e.revision)return;let s=!P&&e&&r&&e.matchId===r.matchId&&e.roundId===r.roundId&&r.moves.length>e.moves.length&&r.status!=="paused";e=r,P=!1,s&&S.play(),f=!0,T&&(h.hidden=!0,T=!1),y()};function y(){if(u)return;c.dataset.status=e?.status??"idle",c.dataset.turn=e?.turn??"",c.dataset.roundId=e?.roundId??"",c.dataset.moves=String(e?.moves.length??0);let r=re();n(".model .name").textContent=r,n(".model .name").title=r;for(let d of["human","model"]){let m=e?e.black===d?"black":"white":"";n(`.${d} .piece`).dataset.color=m,n(`.${d} .color-label`).textContent=m?m==="black"?t("\u9ED1\u68CB \xB7 \u5148\u624B","Black \xB7 first"):t("\u767D\u68CB \xB7 \u540E\u624B","White \xB7 second"):t("\u5F85\u5206\u914D","Unassigned"),n(`.player.${d}`).dataset.turn=String(e?.status==="active"&&e.turn===d)}n(".scores strong").textContent=`${e?.scores.human??0} : ${e?.scores.model??0}`,n(".round").textContent=e?t(`\u7B2C ${e.roundNumber} \u5C40 \xB7 \u548C\u68CB ${e.scores.draw}`,`Round ${e.roundNumber} \xB7 Draws ${e.scores.draw}`):t("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors");let s=e?.status==="active",o=e&&["round-over","waiting-replay"].includes(e.status),A=!!e?.replayRequested;n(".turn-panel").dataset.result=String(!!o),n(".result-actions").hidden=!o,n(".result-hint").hidden=!o||!A&&e.status!=="round-over",n(".result-hint").textContent=A?t("\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\u5F00\u5C40\u3002","Play again selected. The next round starts after your character responds."):t("\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\uFF0C\u53EF\u9009\u62E9\u4E0B\u6B21\u518D\u73A9\u3002","You can leave after your character finishes responding.");let R=n(o?".result-actions":".actions");n(".start").parentElement!==R&&(o?R.append(n(".start"),n(".quit")):R.append(n(".quit"),n(".start"))),$.dataset.result=String(!!o),$.textContent=f?e?e.status==="ended"?t("\u5BF9\u5C40\u5DF2\u7ED3\u675F\uFF0C\u6BD4\u5206\u5DF2\u4FDD\u5B58","Game ended. Scores saved."):o?e.winner==="draw"?t("\u8FD9\u4E00\u5C40\u548C\u68CB","This round is a draw"):e.winner==="human"?t("\u8FD9\u4E00\u5C40\uFF0C\u4F60\u8D62\u4E86","You won this round"):t(`\u8FD9\u4E00\u5C40\uFF0C${r}\u8D62\u4E86`,`${r} won this round`):e.status==="paused"||!l?t("\u5BF9\u5C40\u5DF2\u6682\u505C\uFF0C\u68CB\u76D8\u5DF2\u4FDD\u7559","Game paused. Your board is saved."):e.turn==="human"?t("\u8F6E\u5230\u4F60\u843D\u5B50","Your turn"):t(`${r}\u6B63\u5728\u601D\u8003\u2026`,`${r} is thinking\u2026`):l?t("\u8BF7\u7B49\u5F53\u524D\u5BF9\u8BDD\u7ED3\u675F\u540E\u518D\u5F00\u5C40","Wait for the current conversation to finish"):t("\u51C6\u5907\u597D\u4E86\u5417\uFF1F\u5F00\u59CB\u4E00\u5C40\u4E94\u5B50\u68CB\u5427","Ready for a game of Gomoku?"):t("\u6B63\u5728\u540C\u6B65\u68CB\u5C40\u2026","Syncing game\u2026");let E=new Map((e?.moves??[]).map(d=>[`${d.column}${d.row}`,d.player])),Y=new Set((e?.winningLine??[]).map(d=>`${d.column}${d.row}`)),x=e?.moves.at(-1);k.dataset.humanColor=e?.black==="human"?"black":"white";for(let[d,m]of w.entries()){let z=m.dataset.point,F=E.get(z),U=F?e.black===F?"black":"white":null;U?m.dataset.color=U:delete m.dataset.color,m.dataset.last=String(x&&z===`${x.column}${x.row}`),m.dataset.win=String(Y.has(z)),m.disabled=!C()||!!F,m.tabIndex=d===L&&!m.disabled?0:-1,m.setAttribute("aria-label",U?`${z} ${U==="black"?t("\u9ED1\u68CB","black"):t("\u767D\u68CB","white")}`:t(`\u843D\u5B50\u4E8E ${z}`,`Play ${z}`))}C()&&(w[L]?.disabled||!w.some(d=>d.tabIndex===0))&&(L=w.findIndex(d=>!d.disabled),L>=0&&(w[L].tabIndex=0)),n(".last").textContent=x?t(`\u7B2C ${e.moves.length} \u624B \xB7 ${x.player==="human"?"\u4F60":r}\u843D\u5728 ${x.column}${x.row}`,`Move ${e.moves.length} \xB7 ${x.player==="human"?"You":r} played ${x.column}${x.row}`):t("\u9ED1\u68CB\u5148\u884C \xB7 \u70B9\u51FB\u4EA4\u70B9\u843D\u5B50","Black starts \xB7 Click an intersection"),n(".start").hidden=!!(e&&l&&!o&&!["ended","paused"].includes(e.status)),n(".start").disabled=p||!f||l&&!o||o&&A,n(".start").textContent=o?t("\u518D\u6765\u4E00\u5C40","Play again"):e&&!["ended"].includes(e.status)?t("\u7EE7\u7EED\u5BF9\u5C40","Resume game"):t("\u5F00\u59CB\u5BF9\u5C40","Start game"),n(".quit").hidden=!e||e.status==="ended";let Q=C()||e?.status==="waiting-replay"||e?.status==="paused"&&!l,X=t("\u8BF7\u7B49\u5230\u4F60\u7684\u56DE\u5408\u6216\u89D2\u8272\u56DE\u5E94\u7ED3\u675F\u540E\u64CD\u4F5C","Wait for your turn or for your character to finish responding");n(".quit").disabled=p||!f||!Q,n(".quit").title=Q?"":X,n(".quit").textContent=o?t("\u4E0B\u6B21\u518D\u73A9","Maybe later"):t("\u7ED3\u675F\u6E38\u620F","End game"),n(".resign").hidden=!s||!l,n(".resign").disabled=!C(),n(".resign").title=C()?"":X,n(".note").textContent=s&&e.turn==="model"?t("\u89D2\u8272\u6B63\u5728\u601D\u8003\uFF0C\u8F6E\u5230\u4F60\u65F6\u53EF\u8BA4\u8F93\u6216\u7ED3\u675F","Your character is thinking. Resign or leave on your turn."):t("\u68CB\u5C40\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4E2D\u65AD\u540E\u7EE7\u7EED","Saved automatically. Resume anytime."),n(".sound").textContent=S.muted?t("\u58F0\u97F3\u5173","Sound off"):t("\u58F0\u97F3\u5F00","Sound on"),n(".sound").setAttribute("aria-pressed",String(!S.muted)),n(".refresh").disabled=p||B}async function G(){if(u||B||p||!i)return;B=!0;let r=I;try{let s=await a.command("load-match",D);r===I&&!u&&V(s)}catch{!u&&r===I&&(f=!1,T=!0,O(t("\u68CB\u5C40\u540C\u6B65\u5931\u8D25\uFF0C\u8BF7\u70B9\u51FB\u201C\u540C\u6B65\u68CB\u5C40\u201D\u91CD\u8BD5\u3002","Could not sync. Click \u201CSync game\u201D to retry.")))}finally{B=!1,y()}}function W(){let r=++N;clearTimeout(M),!(u||!i)&&G().finally(()=>{!u&&i&&r===N&&(M=setTimeout(W,600))})}async function j(r,s){if(!(u||p||!f||!e)&&!(r==="resign"&&n(".resign").disabled)&&!(r==="quit"&&n(".quit").disabled)){p=!0,I++,h.hidden=!0,y();try{V(await a.command("match-action",{...D,matchId:e.matchId,roundId:e.roundId,revision:e.revision,action:r,...s?{row:Number(s.slice(1)),column:s[0]}:{}}))}catch{if(!u){O(t("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u5DF2\u91CD\u65B0\u8BFB\u53D6\u68CB\u5C40\uFF0C\u8BF7\u6838\u5BF9\u540E\u518D\u64CD\u4F5C\u3002","Action not confirmed. Reloading the saved board; check before trying again."));try{V(await a.command("load-match",D))}catch{f=!1,T=!0,O(t("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u68CB\u5C40\u540C\u6B65\u4E5F\u5931\u8D25\u4E86\uFF0C\u8BF7\u6062\u590D\u8FDE\u63A5\u540E\u540C\u6B65\u6838\u5BF9\u3002","Action and sync could not be confirmed. Reconnect and sync the saved board."))}}}finally{p=!1,y()}}}async function oe(){if(!(u||p||!f)){if(["round-over","waiting-replay"].includes(e?.status)&&l)return j("replay");if(!l){p=!0,I++,h.hidden=!0,y();try{if(!await a.startRun("start",t("\u966A\u6211\u4E0B\u4E94\u5B50\u68CB\u5427\uFF0C\u8BF7\u4F7F\u7528\u4E94\u5B50\u68CB\u63D2\u4EF6\u5F00\u59CB\u6216\u7EE7\u7EED\u5BF9\u5C40\u3002","Play Gomoku with me. Use the Gomoku plugin to start or resume.")))throw new Error("start-failed")}catch{u||O(t("\u672A\u80FD\u5F00\u59CB\u5BF9\u5C40\uFF0C\u8BF7\u68C0\u67E5\u5F53\u524D\u6A21\u578B\u914D\u7F6E\u540E\u91CD\u8BD5\u3002","Could not start. Check your current model settings and try again."))}finally{p=!1,y(),G()}}}}for(let r=1;r<=15;r++)for(let s of _){let o=document.createElement("button");o.type="button",o.className="cell",o.dataset.point=`${s}${r}`,o.innerHTML='<span class="stone" aria-hidden="true"></span>',o.addEventListener("click",()=>{C()&&j("move",o.dataset.point)},{signal:v.signal}),o.addEventListener("keydown",A=>{let R={ArrowLeft:-1,ArrowRight:1,ArrowUp:-15,ArrowDown:15}[A.key];if(!R||!C())return;A.preventDefault();let E=w.indexOf(o);for(let Y=0;Y<225;Y++)if(E=(E+R+225)%225,!w[E].disabled){L=E,y(),w[E].focus();break}},{signal:v.signal}),w.push(o),k.append(o)}n(".start").addEventListener("click",()=>void oe(),{signal:v.signal}),n(".quit").addEventListener("click",()=>void j("quit"),{signal:v.signal}),n(".resign").addEventListener("click",()=>void j("resign"),{signal:v.signal}),n(".refresh").addEventListener("click",()=>void G(),{signal:v.signal}),n(".sound").addEventListener("click",()=>{S.toggle(),y()},{signal:v.signal});let Z=()=>{u||(u=!0,I++,N++,clearTimeout(M),v.abort(),S.dispose(),J(),K(),a.signal.removeEventListener("abort",Z),c.remove())};return a.signal.addEventListener("abort",Z,{once:!0}),J=a.onRunStateChange(r=>{l=r,y(),G()}),K=a.onVisibilityChange(r=>{i=r,S.setVisible(r),i||(P=!0),i?W():(N++,clearTimeout(M))}),y(),a.signal.aborted?Z():W(),Z}export{pe as mount};
