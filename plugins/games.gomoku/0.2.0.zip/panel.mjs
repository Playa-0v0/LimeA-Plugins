var de=`:host {
  color: var(--foreground, #ededed);
  font-family: inherit;
}
* {
  box-sizing: border-box;
}
.gomoku {
  --ink: var(--foreground, #ededed);
  --soft: var(--muted-foreground, #b5b5b5);
  --line: var(--border, #353535);
  --green: var(--primary, #adeb78);
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  padding: 20px;
  color: var(--ink);
}
button {
  font: inherit;
  cursor: pointer;
  color: var(--ink);
  background: transparent;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 12px;
  transition: background-color 150ms ease-out;
}
button:hover:not(:disabled) {
  background: var(--muted, #282828);
}
button:focus-visible,
summary:focus-visible {
  outline: 2px solid var(--green);
  outline-offset: 3px;
}
button:disabled {
  cursor: default;
  opacity: 0.45;
}
button.primary {
  color: var(--primary-foreground, #1c2b12);
  background: var(--green);
  border-color: transparent;
}
button.primary:hover:not(:disabled) {
  background: color-mix(in srgb, var(--green) 88%, var(--ink));
}
[hidden] {
  display: none !important;
}
.heading,
.heading-actions,
.bottom,
.actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.heading h2 {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
}
.heading p,
.note {
  margin: 7px 0 0;
  color: var(--soft);
  font-size: 12px;
  line-height: 1.6;
}
.refresh,
.sound,
.settings-button {
  padding: 6px 10px;
  font-size: 12px;
}
.heading-actions {
  flex-wrap: wrap;
  justify-content: flex-end;
}
.settings-dialog {
  width: min(440px, calc(100vw - 32px));
  max-height: calc(100vh - 40px);
  overflow: auto;
  padding: 24px;
  color: var(--ink);
  background: var(--background, #141414);
  border: 1px solid var(--line);
  border-radius: 14px;
  box-shadow: 0 16px 56px #0006;
}
.settings-dialog::backdrop {
  background: #0008;
}
.dialog-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.dialog-heading h3 {
  margin: 0;
  font-size: 18px;
}
.close-settings {
  padding: 2px 10px;
  font-size: 24px;
  border: 0;
}
.settings-intro {
  margin: 8px 0 24px;
  color: var(--soft);
  font-size: 13px;
}
.settings-dialog fieldset {
  border: 0;
  margin: 0 0 20px;
  padding: 0;
  min-width: 0;
}
.settings-dialog legend {
  margin-bottom: 12px;
  font-size: 13px;
  font-weight: 600;
}
.settings-dialog label {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 12px 0;
  cursor: pointer;
}
.settings-dialog label + label {
  border-top: 1px solid var(--line);
}
.settings-dialog input {
  accent-color: var(--green);
  margin: 3px 0 0;
  flex: none;
}
.settings-dialog input:focus-visible {
  outline: 2px solid var(--green);
  outline-offset: 3px;
}
.settings-dialog strong {
  font-size: 14px;
  font-weight: 500;
}
.settings-dialog small {
  display: block;
  font-size: 12px;
  line-height: 1.6;
  margin-top: 5px;
  color: var(--soft);
}
.difficulty-options > div {
  display: flex;
  gap: 24px;
}
.difficulty-options label + label {
  border: 0;
}
.settings-feedback {
  margin: 0 0 12px;
  min-height: 20px;
  color: var(--soft);
  font-size: 12px;
}
.settings-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
}
.settings-footer small {
  margin: 0;
  max-width: 25ch;
}
.settings-footer button {
  flex: none;
}
.scoreboard {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 14px;
  width: min(100%, 540px);
  margin: 0 auto;
  padding: 16px 0;
  border-block: 1px solid var(--line);
}
.player {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 9px;
}
.player.model {
  justify-content: flex-end;
  text-align: right;
}
.name {
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: 14px;
}
.color-label {
  display: block;
  margin-top: 4px;
  font-size: 11px;
  color: var(--soft);
}
.player[data-turn='true'] .name {
  color: var(--green);
}
.piece {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  flex: none;
  background: #777;
}
.piece[data-color='black'] {
  background: radial-gradient(circle at 30% 25%, #535761, #191b20 75%);
  border: 1px solid #62656d;
}
.piece[data-color='white'] {
  background: radial-gradient(circle at 30% 25%, #fff, #d7d9df 85%);
  border: 1px solid #b7bbc3;
}
.scores {
  text-align: center;
}
.scores strong {
  font-size: 26px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
  letter-spacing: 0.06em;
  white-space: nowrap;
}
.round {
  display: block;
  margin-top: 4px;
  color: var(--soft);
  font-size: 11px;
}
.status {
  margin: 0;
  text-align: center;
  font-size: 14px;
  min-height: 22px;
  line-height: 1.5;
}
.status[data-result='true'] {
  color: var(--green);
}
.turn-panel[data-result='true'] {
  position: sticky;
  top: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 14px;
  background: var(--background, #141414);
  border: 1px solid var(--line);
  border-radius: 10px;
}
.result-actions {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
}
.result-actions button {
  min-width: 100px;
}
.result-hint {
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  text-align: center;
  line-height: 1.6;
}
.board-layout {
  display: grid;
  grid-template: 16px minmax(0, 1fr) / 16px minmax(0, 1fr);
  gap: 4px;
  width: min(100%, 540px);
  align-self: center;
}
.columns {
  grid-column: 2;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.rows {
  grid-column: 1;
  grid-row: 2;
  display: grid;
  grid-template-rows: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.board {
  grid-column: 2;
  grid-row: 2;
  width: 100%;
  aspect-ratio: 1;
  position: relative;
  border-radius: 8px;
  background: #d8b785;
  border: 1px solid #a88b60;
}
.board > svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}
.cells {
  position: absolute;
  inset: 0;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  grid-template-rows: repeat(15, 1fr);
}
.cell {
  position: relative;
  display: block;
  min-width: 0;
  min-height: 0;
  padding: 0;
  border: 0;
  border-radius: 0;
}
.cell:disabled {
  opacity: 1;
}
.cell:hover:not(:disabled) {
  background: transparent;
}
.cell:focus-visible {
  outline: 2px solid #473a28;
  outline-offset: -2px;
  border-radius: 4px;
}
.stone {
  position: absolute;
  inset: 9%;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 25%, #525660, #17191f 80%);
  box-shadow: 0 1px 2px #40321c66;
}
.cell[data-color='white'] .stone,
.cells[data-human-color='white'] .cell:not([data-color]):hover:not(:disabled)::before {
  background: radial-gradient(circle at 30% 25%, #fff, #d9dce2 80%);
}
.cell:not([data-color]) .stone {
  display: none;
}
.cell[data-last='true'] .stone::after {
  content: '';
  position: absolute;
  inset: 40%;
  background: #fff;
  border-radius: 50%;
}
.cell[data-last='true'][data-color='white'] .stone::after {
  background: #313640;
}
.cell[data-win='true'] .stone {
  outline: 3px solid #527a21;
  outline-offset: 1px;
}
@media (hover: hover) {
  .cell:not([data-color]):hover:not(:disabled)::before {
    content: '';
    position: absolute;
    inset: 9%;
    border-radius: 50%;
    background: #202228;
    opacity: 0.4;
  }
}
.last {
  text-align: center;
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  min-height: 18px;
}
.bottom {
  flex-wrap: wrap;
  margin-top: auto;
  padding-top: 6px;
}
.actions {
  flex-wrap: wrap;
  justify-content: flex-end;
  margin-left: auto;
}
.quit,
.resign {
  font-size: 12px;
}
.error {
  margin: 0;
  color: var(--destructive, #ff9284);
  font-size: 12px;
  line-height: 1.6;
}
.rules {
  color: var(--soft);
  font-size: 12px;
  line-height: 1.7;
}
.rules summary {
  cursor: pointer;
  width: fit-content;
}
.rules p {
  margin: 8px 0 0;
}
@media (max-width: 480px) {
  .gomoku {
    padding: 14px;
    gap: 16px;
  }
  .scoreboard {
    gap: 8px;
  }
  .player {
    gap: 6px;
  }
  .scores strong {
    font-size: 22px;
  }
  .piece {
    width: 20px;
    height: 20px;
  }
  .heading {
    flex-wrap: wrap;
  }
  .heading-actions {
    margin-left: auto;
  }
}
@media (prefers-reduced-motion: reduce) {
  button {
    transition: none;
  }
}
`;var re="ABCDEFGHIJKLMNO";function ce(J){let s=!1;try{s=localStorage.getItem("games.gomoku.muted")==="1"}catch{}let f,e,c,j,o=0,h=!1,i=!0,C=new Set,T=new AbortController,w=()=>{o++;for(let d of C)d.stop();C.clear()},n=()=>{if(!(h||s||!i))try{if(f??=new AudioContext,f.state==="suspended"&&(j=f.resume().catch(()=>{})),!c){let d=f;c=fetch(new URL("assets/stone.mp3",J),{signal:T.signal}).then(l=>{if(!l.ok)throw new Error("sound-unavailable");return l.arrayBuffer()}).then(l=>d.decodeAudioData(l)).then(l=>{h||(e=l)}).catch(()=>{c=null})}}catch{}};return{get muted(){return s},unlock:n,play(){if(h||s||!i||!f)return;let d=o;Promise.all([c,j]).then(()=>{if(d!==o||h||s||!i||!e||f.state!=="running")return;let l=f.createBufferSource(),m=f.createGain();l.buffer=e,m.gain.value=.65,l.connect(m).connect(f.destination),C.add(l),l.onended=()=>{C.delete(l),l.disconnect(),m.disconnect()},l.start()}).catch(()=>{})},toggle(){s=!s;try{localStorage.setItem("games.gomoku.muted",s?"1":"0")}catch{}s?w():n()},setVisible(d){i=d,i?f&&n():(w(),f?.suspend().catch(()=>{}))},dispose(){h=!0,T.abort(),w(),f?.close().catch(()=>{})}}}function we(J,s){let f=s.language.startsWith("en"),e=(t,r)=>f?r:t,c=document.createElement("section");c.className="gomoku";let j=document.createElement("style");j.textContent=de,c.innerHTML=`<header class="heading"><div><h2>${e("\u4E94\u5B50\u68CB","Gomoku")}</h2><p>${e("\u548C\u5F53\u524D\u89D2\u8272\u4E00\u8D77\uFF0C\u843D\u5B50\u6210\u5C40\u3002","A game with your current character.")}</p></div><div class="heading-actions"><button class="sound" type="button"></button><button class="refresh" type="button">${e("\u540C\u6B65\u68CB\u5C40","Sync game")}</button></div></header>
    <div class="scoreboard"><div class="player human"><span class="piece"></span><div><strong class="name">${e("\u4F60","You")}</strong><span class="color-label"></span></div></div><div class="scores"><strong>0 : 0</strong><span class="round">${e("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors")}</span></div><div class="player model"><div><strong class="name"></strong><span class="color-label"></span></div><span class="piece"></span></div></div>
    <div class="turn-panel"><p class="status" role="status"></p><div class="result-actions" hidden></div><p class="result-hint" hidden>${e("\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\u5F00\u5C40\u3002","Play again selected. The next round starts after your character responds.")}</p></div><div class="board-layout"><div class="columns" aria-hidden="true"></div><div class="rows" aria-hidden="true"></div><div class="board"><svg viewBox="0 0 15 15" aria-hidden="true"></svg><div class="cells" role="group" aria-label="${e("\u4E94\u5B50\u68CB\u68CB\u76D8","Gomoku board")}"></div></div></div><p class="last"></p>
    <p class="error" role="alert" hidden></p><details class="rules"><summary>${e("\u73A9\u6CD5\u4E0E\u89C4\u5219","How to play")}</summary><p>${e("15\xD715 \u81EA\u7531\u4E94\u5B50\u68CB\uFF0C\u65E0\u7981\u624B\u3002\u9ED1\u68CB\u5148\u884C\uFF0C\u6A2A\u3001\u7AD6\u6216\u659C\u5411\u8FDE\u6210\u4E94\u9897\u53CA\u4EE5\u4E0A\u83B7\u80DC\u3002\u68CB\u76D8\u586B\u6EE1\u4E14\u65E0\u4EBA\u83B7\u80DC\u5219\u548C\u68CB\u3002\u70B9\u51FB\u4EA4\u70B9\u843D\u5B50\uFF1B\u6700\u540E\u4E00\u624B\u6709\u5706\u70B9\u6807\u8BB0\u3002\u952E\u76D8\u65B9\u5411\u952E\u9009\u70B9\uFF0C\u56DE\u8F66\u843D\u5B50\u3002\u89D2\u8272\u81EA\u5DF1\u601D\u8003\u843D\u5B50\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002","15\xD715 freestyle Gomoku, with no forbidden moves. Black starts. Five or more stones in a row wins; a full board is a draw. Click an intersection to play. A dot marks the last move. Use arrow keys to select and Enter to play. Your character chooses its moves using the current model.")}</p></details>
    <footer class="bottom"><small class="note">${e("\u68CB\u5C40\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4E2D\u65AD\u540E\u7EE7\u7EED","Saved automatically. Resume anytime.")}</small><div class="actions"><button class="resign" type="button" hidden>${e("\u8BA4\u8F93","Resign")}</button><button class="quit" type="button" hidden>${e("\u7ED3\u675F\u6E38\u620F","End game")}</button><button class="start primary" type="button">${e("\u5F00\u59CB\u5BF9\u5C40","Start game")}</button></div></footer>`,c.prepend(j),J.append(c);let o=t=>c.querySelector(t),h=document.createElement("button");h.type="button",h.className="settings-button",h.textContent=e("\u5BF9\u5C40\u8BBE\u7F6E","Game settings"),o(".heading-actions").append(h);let i=document.createElement("dialog");i.className="settings-dialog",i.setAttribute("aria-labelledby","gomoku-settings-title"),i.innerHTML=`<div class="dialog-heading"><h3 id="gomoku-settings-title">${e("\u5BF9\u5C40\u8BBE\u7F6E","Game settings")}</h3><button class="close-settings" type="button" aria-label="${e("\u5173\u95ED\u8BBE\u7F6E","Close settings")}">\xD7</button></div>
    <p class="settings-intro">${e("\u9009\u62E9\u89D2\u8272\u5982\u4F55\u601D\u8003\u4E0B\u4E00\u6B65\u3002","Choose how your character considers its next move.")}</p>
    <form><fieldset class="mode-options"><legend>${e("\u843D\u5B50\u65B9\u5F0F","Move selection")}</legend>
    <label><input type="radio" name="mode" value="model"><span><strong>${e("\u6A21\u578B\u843D\u5B50","Model only")}</strong><small>${e("\u89D2\u8272\u81EA\u5DF1\u8BFB\u68CB\u76D8\u3001\u60F3\u7B56\u7565\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002","Your character reads the board and chooses its own strategy.")}</small></span></label>
    <label><input type="radio" name="mode" value="engine"><span><strong>${e("\u5F15\u64CE\u8F85\u52A9","Engine assisted")}</strong><small>${e("\u8BA1\u7B97\u4E09\u4E2A\u5019\u9009\u843D\u70B9\u53CA\u8BC4\u5206\uFF0C\u7531\u89D2\u8272\u51B3\u5B9A\u6700\u7EC8\u843D\u5B50\u3002","Calculate up to three scored candidates. Your character makes the final choice.")}</small></span></label></fieldset>
    <fieldset class="difficulty-options" hidden><legend>${e("\u5206\u6790\u96BE\u5EA6","Analysis level")}</legend><div>
    <label><input type="radio" name="difficulty" value="normal"><span><strong>${e("\u666E\u901A","Normal")}</strong><small>${e("\u8F83\u5FEB\u5206\u6790\uFF0C\u8F7B\u677E\u966A\u73A9","Quick analysis, casual play")}</small></span></label>
    <label><input type="radio" name="difficulty" value="hard"><span><strong>${e("\u56F0\u96BE","Hard")}</strong><small>${e("\u591A\u60F3\u51E0\u6B65\uFF0C\u5BFB\u627E\u653B\u9632\u673A\u4F1A","Deeper search for threats")}</small></span></label></div></fieldset>
    <p class="settings-feedback" role="status"></p><div class="settings-footer"><small>${e("\u81EA\u52A8\u4FDD\u5B58\uFF0C\u4ECE\u4E0B\u4E00\u5C40\u751F\u6548\u3002\u6240\u6709\u804A\u5929\u5171\u7528\u6B64\u8BBE\u7F6E\u3002","Saved automatically. Applies next round, across chats.")}</small><button class="done-settings primary" type="button">${e("\u5B8C\u6210","Done")}</button></div></form>`,c.append(i);let C=o(".cells"),T=o(".status"),w=o(".error"),n=null,d=!1,l=!1,m=!0,A=!0,p=!1,O=!1,D,z=0,Y=0,q=112,Z=!1,ae=()=>{},se=()=>{},g=new AbortController,E=!1,H=!1,$=0,R=i.querySelector(".settings-feedback"),G=i.querySelector("form"),K=t=>{for(let r of G.querySelectorAll("input"))r.checked=t[r.name]===r.value;i.querySelector(".difficulty-options").hidden=t.mode!=="engine"},U=t=>{for(let r of G.querySelectorAll("input"))r.disabled=t};h.addEventListener("click",async()=>{if(i.open)return;i.showModal();let t=++$;E=!1,U(!0),R.textContent=e("\u6B63\u5728\u8BFB\u53D6\u8BBE\u7F6E\u2026","Loading settings\u2026");try{let r=await s.command("load-settings",{});if(p||t!==$||!i.open)return;K(r),E=!0,R.textContent=""}catch{if(p||t!==$||!i.open)return;R.textContent=e("\u8BBE\u7F6E\u8BFB\u53D6\u5931\u8D25\uFF0C\u8BF7\u5173\u95ED\u540E\u91CD\u8BD5\u3002","Could not load settings. Close and retry.")}finally{t===$&&U(!E||H)}},{signal:g.signal}),G.addEventListener("submit",t=>t.preventDefault(),{signal:g.signal}),G.addEventListener("change",async()=>{if(!E||H)return;let t=Object.fromEntries(new FormData(G)),r=$;K(t),H=!0,U(!0),R.textContent=e("\u6B63\u5728\u4FDD\u5B58\u2026","Saving\u2026");try{let a=await s.command("save-settings",t);if(p||r!==$||!i.open)return;K(a),R.textContent=e("\u5DF2\u4FDD\u5B58\uFF0C\u4E0B\u4E00\u5C40\u751F\u6548","Saved for the next round")}catch{if(p||r!==$||!i.open)return;E=!1,R.textContent=e("\u4FDD\u5B58\u672A\u786E\u8BA4\uFF0C\u8BF7\u5173\u95ED\u540E\u91CD\u65B0\u8BFB\u53D6\u8BBE\u7F6E\u3002","Save not confirmed. Close and reload settings.")}finally{H=!1,U(!E)}},{signal:g.signal}),i.addEventListener("close",()=>{$++,E=!1},{signal:g.signal});for(let t of i.querySelectorAll(".close-settings,.done-settings"))t.addEventListener("click",()=>i.close(),{signal:g.signal});let S=ce(s.resourceBase),X=!0;c.addEventListener("pointerdown",S.unlock,{capture:!0,signal:g.signal}),c.addEventListener("keydown",S.unlock,{capture:!0,signal:g.signal});let ee={mode:s.mode,sessionId:s.sessionId},k=[];o(".columns").replaceChildren(...[...re].map(t=>{let r=document.createElement("span");return r.textContent=t,r})),o(".rows").replaceChildren(...Array.from({length:15},(t,r)=>{let a=document.createElement("span");return a.textContent=String(r+1),a}));let ue=Array.from({length:15},(t,r)=>`<path d="M.5 ${r+.5}H14.5 M${r+.5} .5V14.5"/>`).join("");o(".board > svg").innerHTML=`<g fill="none" stroke="#8b704b" stroke-width=".025">${ue}</g><g fill="#6c5232">${[[3.5,3.5],[11.5,3.5],[7.5,7.5],[3.5,11.5],[11.5,11.5]].map(([t,r])=>`<circle cx="${t}" cy="${r}" r=".09"/>`).join("")}</g>`;let pe=()=>s.characterName?.trim()||e("\u89D2\u8272","Character"),I=()=>l&&!d&&m&&n?.status==="active"&&n.turn==="human",F=t=>{w.textContent=t,w.hidden=!1},te=t=>{if(p||t&&n?.matchId===t.matchId&&t.revision<n.revision)return;let r=!X&&n&&t&&n.matchId===t.matchId&&n.roundId===t.roundId&&t.moves.length>n.moves.length&&t.status!=="paused";n=t,X=!1,r&&S.play(),l=!0,Z&&(w.hidden=!0,Z=!1),x()};function x(){if(p)return;c.dataset.status=n?.status??"idle",c.dataset.turn=n?.turn??"",c.dataset.roundId=n?.roundId??"",c.dataset.moves=String(n?.moves.length??0);let t=pe();o(".model .name").textContent=t,o(".model .name").title=t;for(let u of["human","model"]){let b=n?n.black===u?"black":"white":"";o(`.${u} .piece`).dataset.color=b,o(`.${u} .color-label`).textContent=b?b==="black"?e("\u9ED1\u68CB \xB7 \u5148\u624B","Black \xB7 first"):e("\u767D\u68CB \xB7 \u540E\u624B","White \xB7 second"):e("\u5F85\u5206\u914D","Unassigned"),o(`.player.${u}`).dataset.turn=String(n?.status==="active"&&n.turn===u)}o(".scores strong").textContent=`${n?.scores.human??0} : ${n?.scores.model??0}`,o(".round").textContent=n?e(`\u7B2C ${n.roundNumber} \u5C40 \xB7 \u548C\u68CB ${n.scores.draw}`,`Round ${n.roundNumber} \xB7 Draws ${n.scores.draw}`):e("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors");let r=n?.status==="active",a=n&&["round-over","waiting-replay"].includes(n.status),B=!!n?.replayRequested;o(".turn-panel").dataset.result=String(!!a),o(".result-actions").hidden=!a,o(".result-hint").hidden=!a||!B&&n.status!=="round-over",o(".result-hint").textContent=B?e("\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\u5F00\u5C40\u3002","Play again selected. The next round starts after your character responds."):e("\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\uFF0C\u53EF\u9009\u62E9\u4E0B\u6B21\u518D\u73A9\u3002","You can leave after your character finishes responding.");let N=o(a?".result-actions":".actions");o(".start").parentElement!==N&&(a?N.append(o(".start"),o(".quit")):N.append(o(".quit"),o(".start"))),T.dataset.result=String(!!a),T.textContent=l?n?n.status==="ended"?e("\u5BF9\u5C40\u5DF2\u7ED3\u675F\uFF0C\u6BD4\u5206\u5DF2\u4FDD\u5B58","Game ended. Scores saved."):a?n.winner==="draw"?e("\u8FD9\u4E00\u5C40\u548C\u68CB","This round is a draw"):n.winner==="human"?e("\u8FD9\u4E00\u5C40\uFF0C\u4F60\u8D62\u4E86","You won this round"):e(`\u8FD9\u4E00\u5C40\uFF0C${t}\u8D62\u4E86`,`${t} won this round`):n.status==="paused"||!m?e("\u5BF9\u5C40\u5DF2\u6682\u505C\uFF0C\u68CB\u76D8\u5DF2\u4FDD\u7559","Game paused. Your board is saved."):n.turn==="human"?e("\u8F6E\u5230\u4F60\u843D\u5B50","Your turn"):e(`${t}\u6B63\u5728\u601D\u8003\u2026`,`${t} is thinking\u2026`):m?e("\u8BF7\u7B49\u5F53\u524D\u5BF9\u8BDD\u7ED3\u675F\u540E\u518D\u5F00\u5C40","Wait for the current conversation to finish"):e("\u51C6\u5907\u597D\u4E86\u5417\uFF1F\u5F00\u59CB\u4E00\u5C40\u4E94\u5B50\u68CB\u5427","Ready for a game of Gomoku?"):e("\u6B63\u5728\u540C\u6B65\u68CB\u5C40\u2026","Syncing game\u2026");let L=new Map((n?.moves??[]).map(u=>[`${u.column}${u.row}`,u.player])),_=new Set((n?.winningLine??[]).map(u=>`${u.column}${u.row}`)),y=n?.moves.at(-1);C.dataset.humanColor=n?.black==="human"?"black":"white";for(let[u,b]of k.entries()){let M=b.dataset.point,oe=L.get(M),Q=oe?n.black===oe?"black":"white":null;Q?b.dataset.color=Q:delete b.dataset.color,b.dataset.last=String(y&&M===`${y.column}${y.row}`),b.dataset.win=String(_.has(M)),b.disabled=!I()||!!oe,b.tabIndex=u===q&&!b.disabled?0:-1,b.setAttribute("aria-label",Q?`${M} ${Q==="black"?e("\u9ED1\u68CB","black"):e("\u767D\u68CB","white")}`:e(`\u843D\u5B50\u4E8E ${M}`,`Play ${M}`))}I()&&(k[q]?.disabled||!k.some(u=>u.tabIndex===0))&&(q=k.findIndex(u=>!u.disabled),q>=0&&(k[q].tabIndex=0)),o(".last").textContent=y?e(`\u7B2C ${n.moves.length} \u624B \xB7 ${y.player==="human"?"\u4F60":t}\u843D\u5728 ${y.column}${y.row}`,`Move ${n.moves.length} \xB7 ${y.player==="human"?"You":t} played ${y.column}${y.row}`):e("\u9ED1\u68CB\u5148\u884C \xB7 \u70B9\u51FB\u4EA4\u70B9\u843D\u5B50","Black starts \xB7 Click an intersection"),o(".start").hidden=!!(n&&m&&!a&&!["ended","paused"].includes(n.status)),o(".start").disabled=d||!l||m&&!a||a&&B,o(".start").textContent=a?e("\u518D\u6765\u4E00\u5C40","Play again"):n&&!["ended"].includes(n.status)?e("\u7EE7\u7EED\u5BF9\u5C40","Resume game"):e("\u5F00\u59CB\u5BF9\u5C40","Start game"),o(".quit").hidden=!n||n.status==="ended";let ie=I()||n?.status==="waiting-replay"||n?.status==="paused"&&!m,le=e("\u8BF7\u7B49\u5230\u4F60\u7684\u56DE\u5408\u6216\u89D2\u8272\u56DE\u5E94\u7ED3\u675F\u540E\u64CD\u4F5C","Wait for your turn or for your character to finish responding");o(".quit").disabled=d||!l||!ie,o(".quit").title=ie?"":le,o(".quit").textContent=a?e("\u4E0B\u6B21\u518D\u73A9","Maybe later"):e("\u7ED3\u675F\u6E38\u620F","End game"),o(".resign").hidden=!r||!m,o(".resign").disabled=!I(),o(".resign").title=I()?"":le,o(".note").textContent=r&&n.turn==="model"?e("\u89D2\u8272\u6B63\u5728\u601D\u8003\uFF0C\u8F6E\u5230\u4F60\u65F6\u53EF\u8BA4\u8F93\u6216\u7ED3\u675F","Your character is thinking. Resign or leave on your turn."):e("\u68CB\u5C40\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4E2D\u65AD\u540E\u7EE7\u7EED","Saved automatically. Resume anytime."),o(".sound").textContent=S.muted?e("\u58F0\u97F3\u5173","Sound off"):e("\u58F0\u97F3\u5F00","Sound on"),o(".sound").setAttribute("aria-pressed",String(!S.muted)),o(".refresh").disabled=d||O}async function P(){if(p||O||d||!A)return;O=!0;let t=z;try{let r=await s.command("load-match",ee);t===z&&!p&&te(r)}catch{!p&&t===z&&(l=!1,Z=!0,F(e("\u68CB\u5C40\u540C\u6B65\u5931\u8D25\uFF0C\u8BF7\u70B9\u51FB\u201C\u540C\u6B65\u68CB\u5C40\u201D\u91CD\u8BD5\u3002","Could not sync. Click \u201CSync game\u201D to retry.")))}finally{O=!1,x()}}function ne(){let t=++Y;clearTimeout(D),!(p||!A)&&P().finally(()=>{!p&&A&&t===Y&&(D=setTimeout(ne,600))})}async function V(t,r){if(!(p||d||!l||!n)&&!(t==="resign"&&o(".resign").disabled)&&!(t==="quit"&&o(".quit").disabled)){d=!0,z++,w.hidden=!0,x();try{te(await s.command("match-action",{...ee,matchId:n.matchId,roundId:n.roundId,revision:n.revision,action:t,...r?{row:Number(r.slice(1)),column:r[0]}:{}}))}catch{if(!p){F(e("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u5DF2\u91CD\u65B0\u8BFB\u53D6\u68CB\u5C40\uFF0C\u8BF7\u6838\u5BF9\u540E\u518D\u64CD\u4F5C\u3002","Action not confirmed. Reloading the saved board; check before trying again."));try{te(await s.command("load-match",ee))}catch{l=!1,Z=!0,F(e("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u68CB\u5C40\u540C\u6B65\u4E5F\u5931\u8D25\u4E86\uFF0C\u8BF7\u6062\u590D\u8FDE\u63A5\u540E\u540C\u6B65\u6838\u5BF9\u3002","Action and sync could not be confirmed. Reconnect and sync the saved board."))}}}finally{d=!1,x()}}}async function ge(){if(!(p||d||!l)){if(["round-over","waiting-replay"].includes(n?.status)&&m)return V("replay");if(!m){d=!0,z++,w.hidden=!0,x();try{if(!await s.startRun("start",e("\u966A\u6211\u4E0B\u4E94\u5B50\u68CB\u5427\uFF0C\u8BF7\u4F7F\u7528\u4E94\u5B50\u68CB\u63D2\u4EF6\u5F00\u59CB\u6216\u7EE7\u7EED\u5BF9\u5C40\u3002","Play Gomoku with me. Use the Gomoku plugin to start or resume.")))throw new Error("start-failed")}catch{p||F(e("\u672A\u80FD\u5F00\u59CB\u5BF9\u5C40\uFF0C\u8BF7\u68C0\u67E5\u5F53\u524D\u6A21\u578B\u914D\u7F6E\u540E\u91CD\u8BD5\u3002","Could not start. Check your current model settings and try again."))}finally{d=!1,x(),P()}}}}for(let t=1;t<=15;t++)for(let r of re){let a=document.createElement("button");a.type="button",a.className="cell",a.dataset.point=`${r}${t}`,a.innerHTML='<span class="stone" aria-hidden="true"></span>',a.addEventListener("click",()=>{I()&&V("move",a.dataset.point)},{signal:g.signal}),a.addEventListener("keydown",B=>{let N={ArrowLeft:-1,ArrowRight:1,ArrowUp:-15,ArrowDown:15}[B.key];if(!N||!I())return;B.preventDefault();let L=k.indexOf(a);for(let _=0;_<225;_++)if(L=(L+N+225)%225,!k[L].disabled){q=L,x(),k[L].focus();break}},{signal:g.signal}),k.push(a),C.append(a)}o(".start").addEventListener("click",()=>void ge(),{signal:g.signal}),o(".quit").addEventListener("click",()=>void V("quit"),{signal:g.signal}),o(".resign").addEventListener("click",()=>void V("resign"),{signal:g.signal}),o(".refresh").addEventListener("click",()=>void P(),{signal:g.signal}),o(".sound").addEventListener("click",()=>{S.toggle(),x()},{signal:g.signal});let W=()=>{p||(p=!0,z++,Y++,clearTimeout(D),g.abort(),S.dispose(),i.close(),ae(),se(),s.signal.removeEventListener("abort",W),c.remove())};return s.signal.addEventListener("abort",W,{once:!0}),ae=s.onRunStateChange(t=>{m=t,x(),P()}),se=s.onVisibilityChange(t=>{A=t,S.setVisible(t),A||(X=!0),A?ne():(i.close(),Y++,clearTimeout(D))}),x(),s.signal.aborted?W():ne(),W}export{we as mount};
