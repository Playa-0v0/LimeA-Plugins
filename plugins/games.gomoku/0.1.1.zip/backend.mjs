// src/game.mjs
import { randomInt, randomUUID } from "node:crypto";

// src/rules.mjs
var SIZE = 15;
var COLUMNS = "ABCDEFGHIJKLMNO";
var other = (player) => player === "human" ? "model" : "human";
var colorOf = (match, player) => player === match.black ? "black" : "white";
function coordinate(row, column) {
  if (!Number.isInteger(row) || row < 1 || row > SIZE || typeof column !== "string" || !/^[A-O]$/.test(column))
    throw new Error("invalid-coordinate: row must be 1..15 and column A..O");
  return `${column}${row}`;
}
function boardOf(match) {
  const board = Array.from({ length: SIZE }, () => Array(SIZE).fill(null));
  for (const move of match.moves) board[move.row - 1][COLUMNS.indexOf(move.column)] = move.player;
  return board;
}
function lineThrough(board, row, col, player) {
  for (const [dy, dx] of [
    [0, 1],
    [1, 0],
    [1, 1],
    [1, -1]
  ]) {
    const line = [{ row: row + 1, column: COLUMNS[col] }];
    for (const sign of [-1, 1]) {
      for (let y = row + dy * sign, x = col + dx * sign; y >= 0 && y < SIZE && x >= 0 && x < SIZE && board[y][x] === player; y += dy * sign, x += dx * sign) {
        line.push({ row: y + 1, column: COLUMNS[x] });
      }
    }
    if (line.length >= 5) return line;
  }
  return [];
}
function place(match, player, row, column) {
  if (match.status !== "active" || match.turn !== player) throw new Error("not-your-turn");
  coordinate(row, column);
  const board = boardOf(match);
  const x = COLUMNS.indexOf(column), y = row - 1;
  if (board[y][x]) throw new Error("cell-occupied: choose an empty point marked .");
  board[y][x] = player;
  match.moves.push({ row, column, player });
  match.winningLine = lineThrough(board, y, x, player);
  if (match.winningLine.length || match.moves.length === SIZE * SIZE) {
    match.status = "round-over";
    match.winner = match.winningLine.length ? player : "draw";
    match.scores[match.winner]++;
    match.reason = match.winner === "draw" ? "board-full" : "five-in-row";
    match.turn = null;
  } else match.turn = other(player);
}
function textBoard(match) {
  const rows = boardOf(match).map(
    (cells, index) => `${String(index + 1).padStart(2, "0")} ${cells.map((player) => player ? player === match.black ? "X" : "O" : ".").join(" ")}`
  );
  return ["   " + [...COLUMNS].join(" "), ...rows].join("\n");
}
function toolState(match) {
  return {
    matchId: match.matchId,
    roundId: match.roundId,
    revision: match.revision,
    roundNumber: match.roundNumber,
    status: match.status,
    turn: match.turn,
    modelColor: colorOf(match, "model"),
    moveCount: match.moves.length,
    lastMove: match.moves.at(-1) ?? null,
    winner: match.winner,
    reason: match.reason,
    replayRequested: Boolean(match.replayRequested),
    scores: { ...match.scores }
  };
}
function publicMatch(match) {
  if (!match) return null;
  const { operations: _operations, ...state } = match;
  return state;
}

// src/game.mjs
var migrations = [
  {
    id: "1000_initial",
    sql: "CREATE TABLE matches (session_id TEXT PRIMARY KEY, state TEXT NOT NULL CHECK(json_valid(state)));"
  }
];
async function createGame(database, { first = () => randomInt(2) === 0 ? "human" : "model" } = {}) {
  let queue = Promise.resolve(), closed = false;
  const waiters = /* @__PURE__ */ new Map();
  const serial = (action) => {
    if (closed) return Promise.reject(new Error("game-closed"));
    const result = queue.then(action);
    queue = result.catch(() => {
    });
    return result;
  };
  const key = (context) => {
    if (context?.mode !== "chat" || typeof context.sessionId !== "string" || !context.sessionId || context.sessionId.length > 128)
      throw new Error("invalid-game-scope");
    return context.sessionId;
  };
  const read = async (id) => {
    const row = await database.get("SELECT state FROM matches WHERE session_id=?", [id]);
    return row ? JSON.parse(row.state) : null;
  };
  const notify = (id) => {
    for (const wake of waiters.get(id) ?? []) wake();
  };
  const write = async (id, match) => {
    match.revision++;
    try {
      await database.run(
        "INSERT INTO matches(session_id,state) VALUES (?,?) ON CONFLICT(session_id) DO UPDATE SET state=excluded.state",
        [id, JSON.stringify(match)]
      );
    } finally {
      notify(id);
    }
    return publicMatch(match);
  };
  const newRound = (match) => {
    match.roundId = randomUUID();
    match.roundNumber++;
    match.moves = [];
    match.black = first();
    match.turn = match.black;
    match.status = "active";
    match.winner = null;
    match.winningLine = [];
    match.reason = null;
    delete match.pausedPhase;
    delete match.replayRequested;
  };
  const assertRun = (match, context) => {
    if (!match || match.runId !== context.runId) throw new Error("stale-game-run");
  };
  const wait = async (context) => {
    const id = key(context);
    while (true) {
      context.signal.throwIfAborted();
      let wake;
      const changed = new Promise((resolve) => {
        wake = resolve;
      });
      if (!waiters.has(id)) waiters.set(id, /* @__PURE__ */ new Set());
      waiters.get(id).add(wake);
      context.signal.addEventListener("abort", wake, { once: true });
      try {
        const match = await serial(() => read(id));
        assertRun(match, context);
        context.signal.throwIfAborted();
        if (match.status === "ended" || match.status === "round-over" || match.status === "active" && match.turn === "model")
          return toolState(match);
        if (match.status === "paused") throw new Error("game-paused");
        await changed;
      } finally {
        context.signal.removeEventListener("abort", wake);
        waiters.get(id)?.delete(wake);
        if (!waiters.get(id)?.size) waiters.delete(id);
      }
    }
  };
  for (const row of await database.all("SELECT session_id,state FROM matches")) {
    const match = JSON.parse(row.state);
    if (!["paused", "ended"].includes(match.status)) {
      match.pausedPhase = match.status;
      match.status = "paused";
      match.reason = "interrupted";
      await write(row.session_id, match);
    }
  }
  return {
    load: (context) => serial(async () => publicMatch(await read(key(context)))),
    async start(_input, context) {
      const id = key(context);
      context.signal.throwIfAborted();
      await serial(async () => {
        context.signal.throwIfAborted();
        let match = await read(id);
        if (match && !["paused", "ended"].includes(match.status) && match.runId !== context.runId)
          throw new Error("game-already-running");
        if (match?.runId === context.runId && (match.operations.includes(context.executionId) || match.status === "ended"))
          return;
        if (!match || match.status === "ended") {
          match = {
            matchId: randomUUID(),
            roundId: "",
            roundNumber: 0,
            revision: 0,
            runId: context.runId,
            scores: { human: 0, model: 0, draw: 0 },
            operations: []
          };
          newRound(match);
        } else if (match.status === "paused") {
          match.runId = context.runId;
          match.status = match.pausedPhase;
          match.reason = match.winner ? match.winner === "draw" ? "board-full" : match.winningLine.length ? "five-in-row" : "resigned" : null;
          match.operations = [];
        } else if (!["round-over", "waiting-replay"].includes(match.status))
          throw new Error("game-already-running");
        if (match.status === "round-over") {
          if (match.replayRequested) newRound(match);
          else match.status = "waiting-replay";
        }
        match.operations.push(context.executionId);
        await write(id, match);
      });
      return wait(context);
    },
    async modelMove(input, context) {
      const id = key(context);
      context.signal.throwIfAborted();
      await serial(async () => {
        context.signal.throwIfAborted();
        const match = await read(id);
        assertRun(match, context);
        if (match.status === "ended" || match.operations.includes(context.executionId)) return;
        if (input.roundId !== match.roundId || input.revision !== match.revision)
          throw new Error("stale-round: use current roundId and revision");
        place(match, "model", input.row, input.column);
        match.operations.push(context.executionId);
        await write(id, match);
      });
      return wait(context);
    },
    async act(payload) {
      return serial(async () => {
        const id = key(payload), match = await read(id);
        if (!match || payload.matchId !== match.matchId || payload.roundId !== match.roundId || payload.revision !== match.revision)
          throw new Error("stale-round");
        if (payload.action === "quit") {
          if (match.status === "ended") throw new Error("game-ended");
          match.status = "ended";
          match.turn = null;
          match.reason = "user-ended";
        } else if (payload.action === "replay") {
          if (match.status === "round-over" && !match.replayRequested) match.replayRequested = true;
          else if (match.status === "waiting-replay") newRound(match);
          else throw new Error("not-waiting-for-replay");
        } else if (payload.action === "resign") {
          if (match.status !== "active") throw new Error("game-not-active");
          match.status = "round-over";
          match.turn = null;
          match.winner = "model";
          match.winningLine = [];
          match.reason = "resigned";
          match.scores.model++;
        } else if (payload.action === "move") place(match, "human", payload.row, payload.column);
        else throw new Error("invalid-game-action");
        return write(id, match);
      });
    },
    async policy(context) {
      return serial(async () => {
        const match = await read(key(context));
        if (!match || match.runId !== context.runId || match.status === "paused") return null;
        const state = JSON.stringify(toolState(match));
        if (match.status === "ended")
          return {
            revision: String(match.revision),
            required: false,
            toolIds: [],
            instruction: `\u7528\u6237\u624B\u52A8\u7ED3\u675F\u4E86\u4E94\u5B50\u68CB\uFF0C\u4FDD\u7559\u5DF2\u7ED3\u7B97\u6BD4\u5206\uFF0C\u672A\u5B8C\u6210\u7684\u672C\u5C40\u4E0D\u8BA1\u8F93\u8D62\u3002\u72B6\u6001\uFF1A${state}\u3002\u7B80\u77ED\u56DE\u5E94\u5E76\u7ED3\u675F\uFF0C\u4E0D\u5F97\u91CD\u65B0\u5F00\u5C40\u3002`
          };
        if (match.status === "round-over")
          return {
            revision: String(match.revision),
            required: true,
            toolIds: ["start"],
            instruction: `\u4E94\u5B50\u68CB\u672C\u5C40\u5DF2\u7ED3\u675F\uFF0C\u540E\u53F0\u5224\u5B9A\u7ED3\u679C\uFF1A${state}\u3002\u5148\u6309\u5F53\u524D\u89D2\u8272\u53E3\u543B\u7528\u4E00\u53E5\u8BDD\u5BA3\u5E03\u7ED3\u679C\uFF0C\u65E0\u9700\u957F\u7BC7\u590D\u76D8\u3002${match.replayRequested ? "\u7528\u6237\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u8C03\u7528 start \u5F00\u59CB\u4E0B\u4E00\u5C40\u3002" : "\u754C\u9762\u5DF2\u663E\u793A\u518D\u6765\u4E00\u5C40\u548C\u4E0B\u6B21\u518D\u73A9\uFF0C\u8C03\u7528 start \u7B49\u5F85\u7528\u6237\u9009\u62E9\uFF0C\u4E0D\u8981\u518D\u6B21\u8BE2\u95EE\u6216\u66FF\u7528\u6237\u51B3\u5B9A\u3002"}`
          };
        if (match.status === "active" && match.turn === "model")
          return {
            revision: String(match.revision),
            required: true,
            toolIds: ["place_stone"],
            instruction: `\u8F6E\u5230\u4F60\u4E0B\u4E94\u5B50\u68CB\u300215\xD715\uFF0C\u65E0\u7981\u624B\uFF1B\u9ED1\u68CB\u5148\u884C\uFF0C\u6A2A\u7AD6\u659C\u8FDE\u7EED5\u5B50\u6216\u4EE5\u4E0A\u83B7\u80DC\u3002\u5217A..O\u4ECE\u5DE6\u5230\u53F3\uFF0C\u884C1..15\u4ECE\u4E0A\u5230\u4E0B\uFF1BX=\u9ED1\u68CB\uFF0CO=\u767D\u68CB\uFF0C.=\u7A7A\u70B9\u3002\u4F60\u6267${match.black === "model" ? "\u9ED1(X)" : "\u767D(O)"}\uFF0C\u53EA\u53EF\u9009\u62E9\u7A7A\u70B9\u3002\u4EE5\u4EE5\u4E0B\u5B8C\u6574\u6700\u65B0\u68CB\u76D8\u4E3A\u51C6\uFF0C\u4E0D\u4F9D\u8D56\u65E7\u5BF9\u8BDD\u731C\u6D4B\uFF0C\u4E0D\u66FF\u7528\u6237\u843D\u5B50\uFF0C\u4E5F\u4E0D\u81EA\u884C\u5BA3\u5224\u80DC\u8D1F\u3002\u7528 place_stone \u4F20\u5165\u5F53\u524D roundId\u3001revision\u3001row\u3001column\u3002\u53EF\u5148\u7B80\u77ED\u8BF4\u4E00\u53E5\u966A\u73A9\u7684\u8BDD\u3002
\u72B6\u6001\uFF1A${state}
\u68CB\u76D8\uFF1A
${textBoard(match)}`
          };
        throw new Error("game-wait-not-owned");
      });
    },
    async finished(context) {
      return serial(async () => {
        const id = key(context), match = await read(id);
        if (match?.runId === context.runId && !["ended", "paused"].includes(match.status)) {
          match.pausedPhase = match.status;
          match.status = "paused";
          match.reason = "interrupted";
          await write(id, match);
        }
      });
    },
    async dispose() {
      closed = true;
      for (const id of waiters.keys()) notify(id);
      await queue;
    }
  };
}

// src/backend.mjs
async function apply(context) {
  const database = await context.storage.openDatabase({ name: "matches", migrations });
  const game = await createGame(database);
  context.onDispose(async () => {
    await game.dispose();
    await database.close();
  });
  context.commands.register(
    "load-match",
    (payload) => payload?.sessionId ? game.load(payload) : null
  );
  context.commands.register("match-action", async (payload) => {
    if (payload?.action !== "quit" && !await context.sessions.isRunning(payload?.sessionId))
      throw new Error("game-paused");
    return game.act(payload);
  });
  context.tools.register("start", game.start);
  context.tools.register("place_stone", game.modelMove);
  context.tools.interaction({ policy: game.policy, finished: game.finished });
}
export {
  apply
};
