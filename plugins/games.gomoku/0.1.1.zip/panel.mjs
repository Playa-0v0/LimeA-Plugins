var W=`:host {
  color: var(--foreground, #ededed);
  font-family: inherit;
}
* {
  box-sizing: border-box;
}
.gomoku {
  --ink: var(--foreground, #ededed);
  --soft: var(--muted-foreground, #b5b5b5);
  --line: var(--border, #353535);
  --green: var(--primary, #adeb78);
  display: flex;
  flex-direction: column;
  gap: 20px;
  min-height: 100%;
  padding: 20px;
  color: var(--ink);
}
button {
  font: inherit;
  cursor: pointer;
  color: var(--ink);
  background: transparent;
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 12px;
  transition: background-color 150ms ease-out;
}
button:hover:not(:disabled) {
  background: var(--muted, #282828);
}
button:focus-visible,
summary:focus-visible {
  outline: 2px solid var(--green);
  outline-offset: 3px;
}
button:disabled {
  cursor: default;
  opacity: 0.45;
}
button.primary {
  color: var(--primary-foreground, #1c2b12);
  background: var(--green);
  border-color: transparent;
}
button.primary:hover:not(:disabled) {
  background: color-mix(in srgb, var(--green) 88%, var(--ink));
}
[hidden] {
  display: none !important;
}
.heading,
.bottom,
.actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.heading h2 {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
}
.heading p,
.note {
  margin: 7px 0 0;
  color: var(--soft);
  font-size: 12px;
  line-height: 1.6;
}
.refresh {
  padding: 6px 10px;
  font-size: 12px;
}
.scoreboard {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 14px;
  width: min(100%, 540px);
  margin: 0 auto;
  padding: 16px 0;
  border-block: 1px solid var(--line);
}
.player {
  min-width: 0;
  display: flex;
  align-items: center;
  gap: 9px;
}
.player.model {
  justify-content: flex-end;
  text-align: right;
}
.name {
  display: block;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: 14px;
}
.color-label {
  display: block;
  margin-top: 4px;
  font-size: 11px;
  color: var(--soft);
}
.player[data-turn='true'] .name {
  color: var(--green);
}
.piece {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  flex: none;
  background: #777;
}
.piece[data-color='black'] {
  background: radial-gradient(circle at 30% 25%, #535761, #191b20 75%);
  border: 1px solid #62656d;
}
.piece[data-color='white'] {
  background: radial-gradient(circle at 30% 25%, #fff, #d7d9df 85%);
  border: 1px solid #b7bbc3;
}
.scores {
  text-align: center;
}
.scores strong {
  font-size: 26px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
  letter-spacing: 0.06em;
  white-space: nowrap;
}
.round {
  display: block;
  margin-top: 4px;
  color: var(--soft);
  font-size: 11px;
}
.status {
  margin: 0;
  text-align: center;
  font-size: 14px;
  min-height: 22px;
  line-height: 1.5;
}
.status[data-result='true'] {
  color: var(--green);
}
.turn-panel[data-result='true'] {
  position: sticky;
  top: 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 14px;
  background: var(--background, #141414);
  border: 1px solid var(--line);
  border-radius: 10px;
}
.result-actions {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 10px;
}
.result-actions button {
  min-width: 100px;
}
.result-hint {
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  text-align: center;
  line-height: 1.6;
}
.board-layout {
  display: grid;
  grid-template: 16px minmax(0, 1fr) / 16px minmax(0, 1fr);
  gap: 4px;
  width: min(100%, 540px);
  align-self: center;
}
.columns {
  grid-column: 2;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.rows {
  grid-column: 1;
  grid-row: 2;
  display: grid;
  grid-template-rows: repeat(15, 1fr);
  text-align: center;
  color: var(--soft);
  font-size: 10px;
  align-items: center;
}
.board {
  grid-column: 2;
  grid-row: 2;
  width: 100%;
  aspect-ratio: 1;
  position: relative;
  border-radius: 8px;
  background: #d8b785;
  border: 1px solid #a88b60;
}
.board > svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}
.cells {
  position: absolute;
  inset: 0;
  display: grid;
  grid-template-columns: repeat(15, 1fr);
  grid-template-rows: repeat(15, 1fr);
}
.cell {
  position: relative;
  display: block;
  min-width: 0;
  min-height: 0;
  padding: 0;
  border: 0;
  border-radius: 0;
}
.cell:disabled {
  opacity: 1;
}
.cell:hover:not(:disabled) {
  background: transparent;
}
.cell:focus-visible {
  outline: 2px solid #473a28;
  outline-offset: -2px;
  border-radius: 4px;
}
.stone {
  position: absolute;
  inset: 9%;
  border-radius: 50%;
  background: radial-gradient(circle at 30% 25%, #525660, #17191f 80%);
  box-shadow: 0 1px 2px #40321c66;
}
.cell[data-color='white'] .stone,
.cells[data-human-color='white'] .cell:not([data-color]):hover:not(:disabled)::before {
  background: radial-gradient(circle at 30% 25%, #fff, #d9dce2 80%);
}
.cell:not([data-color]) .stone {
  display: none;
}
.cell[data-last='true'] .stone::after {
  content: '';
  position: absolute;
  inset: 40%;
  background: #fff;
  border-radius: 50%;
}
.cell[data-last='true'][data-color='white'] .stone::after {
  background: #313640;
}
.cell[data-win='true'] .stone {
  outline: 3px solid #527a21;
  outline-offset: 1px;
}
@media (hover: hover) {
  .cell:not([data-color]):hover:not(:disabled)::before {
    content: '';
    position: absolute;
    inset: 9%;
    border-radius: 50%;
    background: #202228;
    opacity: 0.4;
  }
}
.last {
  text-align: center;
  margin: 0;
  color: var(--soft);
  font-size: 12px;
  min-height: 18px;
}
.bottom {
  flex-wrap: wrap;
  margin-top: auto;
  padding-top: 6px;
}
.actions {
  flex-wrap: wrap;
  justify-content: flex-end;
  margin-left: auto;
}
.quit,
.resign {
  font-size: 12px;
}
.error {
  margin: 0;
  color: var(--destructive, #ff9284);
  font-size: 12px;
  line-height: 1.6;
}
.rules {
  color: var(--soft);
  font-size: 12px;
  line-height: 1.7;
}
.rules summary {
  cursor: pointer;
  width: fit-content;
}
.rules p {
  margin: 8px 0 0;
}
@media (max-width: 480px) {
  .gomoku {
    padding: 14px;
    gap: 16px;
  }
  .scoreboard {
    gap: 8px;
  }
  .player {
    gap: 6px;
  }
  .scores strong {
    font-size: 22px;
  }
  .piece {
    width: 20px;
    height: 20px;
  }
}
@media (prefers-reduced-motion: reduce) {
  button {
    transition: none;
  }
}
`;var U="ABCDEFGHIJKLMNO";function ae(_,s){let J=s.language.startsWith("en"),t=(n,a)=>J?a:n,p=document.createElement("section");p.className="gomoku";let Y=document.createElement("style");Y.textContent=W,p.innerHTML=`<header class="heading"><div><h2>${t("\u4E94\u5B50\u68CB","Gomoku")}</h2><p>${t("\u548C\u5F53\u524D\u89D2\u8272\u4E00\u8D77\uFF0C\u843D\u5B50\u6210\u5C40\u3002","A game with your current character.")}</p></div><button class="refresh" type="button">${t("\u540C\u6B65\u68CB\u5C40","Sync game")}</button></header>
    <div class="scoreboard"><div class="player human"><span class="piece"></span><div><strong class="name">${t("\u4F60","You")}</strong><span class="color-label"></span></div></div><div class="scores"><strong>0 : 0</strong><span class="round">${t("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors")}</span></div><div class="player model"><div><strong class="name"></strong><span class="color-label"></span></div><span class="piece"></span></div></div>
    <div class="turn-panel"><p class="status" role="status"></p><div class="result-actions" hidden></div><p class="result-hint" hidden>${t("\u5DF2\u9009\u62E9\u518D\u6765\u4E00\u5C40\uFF0C\u7B49\u5F85\u89D2\u8272\u56DE\u5E94\u540E\u5F00\u5C40\u3002","Play again selected. The next round starts after your character responds.")}</p></div><div class="board-layout"><div class="columns" aria-hidden="true"></div><div class="rows" aria-hidden="true"></div><div class="board"><svg viewBox="0 0 15 15" aria-hidden="true"></svg><div class="cells" role="group" aria-label="${t("\u4E94\u5B50\u68CB\u68CB\u76D8","Gomoku board")}"></div></div></div><p class="last"></p>
    <p class="error" role="alert" hidden></p><details class="rules"><summary>${t("\u73A9\u6CD5\u4E0E\u89C4\u5219","How to play")}</summary><p>${t("15\xD715 \u81EA\u7531\u4E94\u5B50\u68CB\uFF0C\u65E0\u7981\u624B\u3002\u9ED1\u68CB\u5148\u884C\uFF0C\u6A2A\u3001\u7AD6\u6216\u659C\u5411\u8FDE\u6210\u4E94\u9897\u53CA\u4EE5\u4E0A\u83B7\u80DC\u3002\u68CB\u76D8\u586B\u6EE1\u4E14\u65E0\u4EBA\u83B7\u80DC\u5219\u548C\u68CB\u3002\u70B9\u51FB\u4EA4\u70B9\u843D\u5B50\uFF1B\u6700\u540E\u4E00\u624B\u6709\u5706\u70B9\u6807\u8BB0\u3002\u952E\u76D8\u65B9\u5411\u952E\u9009\u70B9\uFF0C\u56DE\u8F66\u843D\u5B50\u3002\u89D2\u8272\u81EA\u5DF1\u601D\u8003\u843D\u5B50\uFF0C\u68CB\u529B\u53D6\u51B3\u4E8E\u5F53\u524D\u6A21\u578B\u3002","15\xD715 freestyle Gomoku, with no forbidden moves. Black starts. Five or more stones in a row wins; a full board is a draw. Click an intersection to play. A dot marks the last move. Use arrow keys to select and Enter to play. Your character chooses its moves using the current model.")}</p></details>
    <footer class="bottom"><small class="note">${t("\u68CB\u5C40\u81EA\u52A8\u4FDD\u5B58\uFF0C\u53EF\u4E2D\u65AD\u540E\u7EE7\u7EED","Saved automatically. Resume anytime.")}</small><div class="actions"><button class="resign" type="button" hidden>${t("\u8BA4\u8F93","Resign")}</button><button class="quit" type="button" hidden>${t("\u7ED3\u675F\u6E38\u620F","End game")}</button><button class="start primary" type="button">${t("\u5F00\u59CB\u5BF9\u5C40","Start game")}</button></div></footer>`,p.prepend(Y),_.append(p);let r=n=>p.querySelector(n),D=r(".cells"),P=r(".status"),E=r(".error"),e=null,c=!1,g=!1,m=!0,C=!0,l=!1,I=!1,L,y=0,z=0,w=112,A=!1,F=()=>{},V=()=>{},v=new AbortController,j={mode:s.mode,sessionId:s.sessionId},b=[];r(".columns").replaceChildren(...[...U].map(n=>{let a=document.createElement("span");return a.textContent=n,a})),r(".rows").replaceChildren(...Array.from({length:15},(n,a)=>{let o=document.createElement("span");return o.textContent=String(a+1),o}));let K=Array.from({length:15},(n,a)=>`<path d="M.5 ${a+.5}H14.5 M${a+.5} .5V14.5"/>`).join("");r(".board > svg").innerHTML=`<g fill="none" stroke="#8b704b" stroke-width=".025">${K}</g><g fill="#6c5232">${[[3.5,3.5],[11.5,3.5],[7.5,7.5],[3.5,11.5],[11.5,11.5]].map(([n,a])=>`<circle cx="${n}" cy="${a}" r=".09"/>`).join("")}</g>`;let X=()=>s.characterName?.trim()||t("\u89D2\u8272","Character"),R=()=>g&&!c&&m&&e?.status==="active"&&e.turn==="human",q=n=>{E.textContent=n,E.hidden=!1},G=n=>{l||n&&e?.matchId===n.matchId&&n.revision<e.revision||(e=n,g=!0,A&&(E.hidden=!0,A=!1),h())};function h(){if(l)return;p.dataset.status=e?.status??"idle",p.dataset.turn=e?.turn??"",p.dataset.roundId=e?.roundId??"",p.dataset.moves=String(e?.moves.length??0);let n=X();r(".model .name").textContent=n,r(".model .name").title=n;for(let i of["human","model"]){let d=e?e.black===i?"black":"white":"";r(`.${i} .piece`).dataset.color=d,r(`.${i} .color-label`).textContent=d?d==="black"?t("\u9ED1\u68CB \xB7 \u5148\u624B","Black \xB7 first"):t("\u767D\u68CB \xB7 \u540E\u624B","White \xB7 second"):t("\u5F85\u5206\u914D","Unassigned"),r(`.player.${i}`).dataset.turn=String(e?.status==="active"&&e.turn===i)}r(".scores strong").textContent=`${e?.scores.human??0} : ${e?.scores.model??0}`,r(".round").textContent=e?t(`\u7B2C ${e.roundNumber} \u5C40 \xB7 \u548C\u68CB ${e.scores.draw}`,`Round ${e.roundNumber} \xB7 Draws ${e.scores.draw}`):t("\u968F\u673A\u5206\u914D\u9ED1\u767D","Random colors");let a=e?.status==="active",o=e&&["round-over","waiting-replay"].includes(e.status),S=!!e?.replayRequested;r(".turn-panel").dataset.result=String(!!o),r(".result-actions").hidden=!o,r(".result-hint").hidden=!o||!S;let k=r(o?".result-actions":".actions");r(".start").parentElement!==k&&(o?k.append(r(".start"),r(".quit")):k.append(r(".quit"),r(".start"))),P.dataset.result=String(!!o),P.textContent=g?e?e.status==="ended"?t("\u5BF9\u5C40\u5DF2\u7ED3\u675F\uFF0C\u6BD4\u5206\u5DF2\u4FDD\u5B58","Game ended. Scores saved."):o?e.winner==="draw"?t("\u8FD9\u4E00\u5C40\u548C\u68CB","This round is a draw"):e.winner==="human"?t("\u8FD9\u4E00\u5C40\uFF0C\u4F60\u8D62\u4E86","You won this round"):t(`\u8FD9\u4E00\u5C40\uFF0C${n}\u8D62\u4E86`,`${n} won this round`):e.status==="paused"||!m?t("\u5BF9\u5C40\u5DF2\u6682\u505C\uFF0C\u68CB\u76D8\u5DF2\u4FDD\u7559","Game paused. Your board is saved."):e.turn==="human"?t("\u8F6E\u5230\u4F60\u843D\u5B50","Your turn"):t(`${n}\u6B63\u5728\u601D\u8003\u2026`,`${n} is thinking\u2026`):m?t("\u8BF7\u7B49\u5F53\u524D\u5BF9\u8BDD\u7ED3\u675F\u540E\u518D\u5F00\u5C40","Wait for the current conversation to finish"):t("\u51C6\u5907\u597D\u4E86\u5417\uFF1F\u5F00\u59CB\u4E00\u5C40\u4E94\u5B50\u68CB\u5427","Ready for a game of Gomoku?"):t("\u6B63\u5728\u540C\u6B65\u68CB\u5C40\u2026","Syncing game\u2026");let x=new Map((e?.moves??[]).map(i=>[`${i.column}${i.row}`,i.player])),O=new Set((e?.winningLine??[]).map(i=>`${i.column}${i.row}`)),f=e?.moves.at(-1);D.dataset.humanColor=e?.black==="human"?"black":"white";for(let[i,d]of b.entries()){let $=d.dataset.point,H=x.get($),T=H?e.black===H?"black":"white":null;T?d.dataset.color=T:delete d.dataset.color,d.dataset.last=String(f&&$===`${f.column}${f.row}`),d.dataset.win=String(O.has($)),d.disabled=!R()||!!H,d.tabIndex=i===w&&!d.disabled?0:-1,d.setAttribute("aria-label",T?`${$} ${T==="black"?t("\u9ED1\u68CB","black"):t("\u767D\u68CB","white")}`:t(`\u843D\u5B50\u4E8E ${$}`,`Play ${$}`))}R()&&(b[w]?.disabled||!b.some(i=>i.tabIndex===0))&&(w=b.findIndex(i=>!i.disabled),w>=0&&(b[w].tabIndex=0)),r(".last").textContent=f?t(`\u7B2C ${e.moves.length} \u624B \xB7 ${f.player==="human"?"\u4F60":n}\u843D\u5728 ${f.column}${f.row}`,`Move ${e.moves.length} \xB7 ${f.player==="human"?"You":n} played ${f.column}${f.row}`):t("\u9ED1\u68CB\u5148\u884C \xB7 \u70B9\u51FB\u4EA4\u70B9\u843D\u5B50","Black starts \xB7 Click an intersection"),r(".start").hidden=!!(e&&m&&!o&&!["ended","paused"].includes(e.status)),r(".start").disabled=c||!g||m&&!o||o&&S,r(".start").textContent=o?t("\u518D\u6765\u4E00\u5C40","Play again"):e&&!["ended"].includes(e.status)?t("\u7EE7\u7EED\u5BF9\u5C40","Resume game"):t("\u5F00\u59CB\u5BF9\u5C40","Start game"),r(".quit").hidden=!e||e.status==="ended",r(".quit").disabled=c||!g,r(".quit").textContent=o?t("\u4E0B\u6B21\u518D\u73A9","Maybe later"):t("\u7ED3\u675F\u6E38\u620F","End game"),r(".resign").hidden=!a||!m,r(".resign").disabled=c||!g,r(".refresh").disabled=c||I}async function M(){if(l||I||c||!C)return;I=!0;let n=y;try{let a=await s.command("load-match",j);n===y&&!l&&G(a)}catch{!l&&n===y&&(g=!1,A=!0,q(t("\u68CB\u5C40\u540C\u6B65\u5931\u8D25\uFF0C\u8BF7\u70B9\u51FB\u201C\u540C\u6B65\u68CB\u5C40\u201D\u91CD\u8BD5\u3002","Could not sync. Click \u201CSync game\u201D to retry.")))}finally{I=!1,h()}}function Z(){let n=++z;clearTimeout(L),!(l||!C)&&M().finally(()=>{!l&&C&&n===z&&(L=setTimeout(Z,600))})}async function B(n,a){if(!(l||c||!g||!e)){c=!0,y++,E.hidden=!0,h();try{G(await s.command("match-action",{...j,matchId:e.matchId,roundId:e.roundId,revision:e.revision,action:n,...a?{row:Number(a.slice(1)),column:a[0]}:{}}))}catch{if(!l){q(t("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u5DF2\u91CD\u65B0\u8BFB\u53D6\u68CB\u5C40\uFF0C\u8BF7\u6838\u5BF9\u540E\u518D\u64CD\u4F5C\u3002","Action not confirmed. Reloading the saved board; check before trying again."));try{G(await s.command("load-match",j))}catch{g=!1,A=!0,q(t("\u64CD\u4F5C\u672A\u786E\u8BA4\uFF0C\u68CB\u5C40\u540C\u6B65\u4E5F\u5931\u8D25\u4E86\uFF0C\u8BF7\u6062\u590D\u8FDE\u63A5\u540E\u540C\u6B65\u6838\u5BF9\u3002","Action and sync could not be confirmed. Reconnect and sync the saved board."))}}}finally{c=!1,h()}}}async function Q(){if(!(l||c||!g)){if(["round-over","waiting-replay"].includes(e?.status)&&m)return B("replay");if(!m){c=!0,y++,E.hidden=!0,h();try{if(!await s.startRun("start",t("\u966A\u6211\u4E0B\u4E94\u5B50\u68CB\u5427\uFF0C\u8BF7\u4F7F\u7528\u4E94\u5B50\u68CB\u63D2\u4EF6\u5F00\u59CB\u6216\u7EE7\u7EED\u5BF9\u5C40\u3002","Play Gomoku with me. Use the Gomoku plugin to start or resume.")))throw new Error("start-failed")}catch{l||q(t("\u672A\u80FD\u5F00\u59CB\u5BF9\u5C40\uFF0C\u8BF7\u68C0\u67E5\u5F53\u524D\u6A21\u578B\u914D\u7F6E\u540E\u91CD\u8BD5\u3002","Could not start. Check your current model settings and try again."))}finally{c=!1,h(),M()}}}}for(let n=1;n<=15;n++)for(let a of U){let o=document.createElement("button");o.type="button",o.className="cell",o.dataset.point=`${a}${n}`,o.innerHTML='<span class="stone" aria-hidden="true"></span>',o.addEventListener("click",()=>{R()&&B("move",o.dataset.point)},{signal:v.signal}),o.addEventListener("keydown",S=>{let k={ArrowLeft:-1,ArrowRight:1,ArrowUp:-15,ArrowDown:15}[S.key];if(!k||!R())return;S.preventDefault();let x=b.indexOf(o);for(let O=0;O<225;O++)if(x=(x+k+225)%225,!b[x].disabled){w=x,h(),b[x].focus();break}},{signal:v.signal}),b.push(o),D.append(o)}r(".start").addEventListener("click",()=>void Q(),{signal:v.signal}),r(".quit").addEventListener("click",()=>void B("quit"),{signal:v.signal}),r(".resign").addEventListener("click",()=>void B("resign"),{signal:v.signal}),r(".refresh").addEventListener("click",()=>void M(),{signal:v.signal});let N=()=>{l||(l=!0,y++,z++,clearTimeout(L),v.abort(),F(),V(),s.signal.removeEventListener("abort",N),p.remove())};return s.signal.addEventListener("abort",N,{once:!0}),F=s.onRunStateChange(n=>{m=n,h(),M()}),V=s.onVisibilityChange(n=>{C=n,C?Z():(z++,clearTimeout(L))}),h(),s.signal.aborted?N():Z(),N}export{ae as mount};
