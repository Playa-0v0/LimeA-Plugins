// src/settings.css
var settings_default = ":host {\n  color: var(--foreground, #efefef);\n  font: 14px/1.5 system-ui;\n}\n*,\n*::before,\n*::after {\n  box-sizing: border-box;\n}\n.wallpaper-settings {\n  max-width: 780px;\n  padding: 20px;\n}\nh2 {\n  font-size: 20px;\n  margin: 0 0 8px;\n}\np {\n  color: var(--muted-foreground, #bbb);\n  margin: 0 0 18px;\n}\n.actions {\n  display: flex;\n  gap: 8px;\n  flex-wrap: wrap;\n}\nbutton,\nselect {\n  font: inherit;\n  color: inherit;\n  background: var(--surface, #303030);\n  border: 1px solid var(--border, #555);\n  border-radius: 6px;\n  padding: 8px 12px;\n}\nbutton {\n  cursor: pointer;\n}\nbutton:hover {\n  background: var(--surface-hover, #444);\n}\nbutton:disabled {\n  opacity: 0.6;\n  cursor: wait;\n}\nbutton:focus-visible,\ninput:focus-visible,\nselect:focus-visible {\n  outline: 2px solid var(--primary, #adeb78);\n  outline-offset: 2px;\n}\noutput {\n  display: block;\n  min-height: 24px;\n  margin: 12px 0;\n  color: var(--muted-foreground, #bbb);\n  overflow-wrap: anywhere;\n}\n.library {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(min(170px, 100%), 1fr));\n  gap: 12px;\n  max-height: min(360px, 45vh);\n  overflow-y: auto;\n  border-block: 1px solid var(--border, #555);\n  padding: 12px 4px;\n  scrollbar-gutter: stable;\n}\n.library > [role='listitem'] {\n  min-width: 0;\n}\n.wallpaper-item {\n  display: flex;\n  flex-direction: column;\n  text-align: start;\n  width: 100%;\n  height: 100%;\n  min-width: 0;\n  padding: 0;\n  overflow: hidden;\n  border: 1px solid var(--border, #555);\n  border-radius: var(--ui-radius-md, 8px);\n  background: var(--surface, #252525);\n}\n.wallpaper-cover {\n  display: grid;\n  place-items: center;\n  position: relative;\n  width: 100%;\n  aspect-ratio: 16 / 9;\n  background: var(--muted, #292929);\n}\n.wallpaper-cover img {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.wallpaper-placeholder {\n  color: var(--muted-foreground, #bbb);\n  font-size: 12px;\n  padding: 12px;\n  text-align: center;\n}\n.wallpaper-type,\n.wallpaper-selected {\n  position: absolute;\n  top: 7px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  font-size: 11px;\n  line-height: 1.5;\n}\n.wallpaper-type {\n  left: 7px;\n  background: rgb(0 0 0 / 72%);\n  color: #fff;\n}\n.wallpaper-selected {\n  right: 7px;\n  background: var(--primary, #adeb78);\n  color: var(--primary-foreground, #152009);\n}\n.wallpaper-title {\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n  -webkit-line-clamp: 2;\n  min-height: 36px;\n  padding: 9px 10px;\n  overflow: hidden;\n  overflow-wrap: anywhere;\n  font-size: 12px;\n  line-height: 18px;\n}\n.library-empty {\n  grid-column: 1 / -1;\n  margin: 0;\n  padding: 20px 8px;\n}\n.wallpaper-item[aria-pressed='true'] {\n  border-color: var(--primary, #adeb78);\n  box-shadow: inset 0 0 0 1px var(--primary, #adeb78);\n}\n.wallpaper-item[aria-pressed='true'] .wallpaper-title {\n  color: var(--primary, #adeb78);\n}\n.wallpaper-cover [hidden] {\n  display: none;\n}\nform {\n  display: grid;\n  gap: 14px;\n  padding: 20px 0;\n}\nlabel {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  min-width: 0;\n}\nlabel input,\nlabel select {\n  margin-left: auto;\n}\n.host-control {\n  display: inline-flex;\n  align-items: center;\n  min-width: 0;\n}\nlabel .host-control {\n  margin-left: auto;\n}\n.host-control[data-type='slider'] {\n  width: min(38vw, 210px);\n}\ninput[type='range'] {\n  width: min(38vw, 210px);\n  accent-color: var(--primary, #adeb78);\n}\ninput[type='checkbox'] {\n  width: 18px;\n  height: 18px;\n  accent-color: var(--primary, #adeb78);\n}\n[data-value] {\n  width: 44px;\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n}\n.note {\n  font-size: 12px;\n  margin: 0;\n}\n";

// src/preview-library.mjs
function mountPreviewLibrary(library, { t, command, onSelect, signal }) {
  const cards = /* @__PURE__ */ new Map();
  const cache = /* @__PURE__ */ new Map();
  const queue = /* @__PURE__ */ new Set();
  let active = 0, disposed = false, supported = true;
  const kinds = {
    image: t("\u56FE\u7247", "Image"),
    video: t("\u89C6\u9891", "Video"),
    web: t("\u7F51\u9875", "Web"),
    scene: t("\u573A\u666F", "Scene")
  };
  const placeholder = (card, message) => {
    card.image.hidden = true;
    card.image.removeAttribute("src");
    card.placeholder.hidden = false;
    card.placeholder.textContent = message;
  };
  function show(card, src) {
    if (!src) {
      placeholder(card, t("\u6682\u65E0\u9884\u89C8", "No preview"));
      return;
    }
    card.image.onload = () => {
      if (disposed || !card.visible) return;
      card.image.hidden = false;
      card.placeholder.hidden = true;
    };
    card.image.onerror = () => placeholder(card, t("\u6682\u65E0\u9884\u89C8", "No preview"));
    card.image.src = src;
  }
  function enqueue(card) {
    if (!supported) {
      placeholder(card, t("\u66F4\u65B0 LimeA \u663E\u793A\u9884\u89C8", "Update LimeA for previews"));
    } else if (cache.has(card.id)) {
      const src = cache.get(card.id);
      cache.delete(card.id);
      cache.set(card.id, src);
      show(card, src);
    } else if (!card.loading) {
      queue.add(card);
      pump();
    }
  }
  function pump() {
    while (!disposed && active < 2 && queue.size) {
      const card = queue.values().next().value;
      queue.delete(card);
      if (!card.visible || !cards.has(card.id)) continue;
      active++;
      card.loading = true;
      const generation = card.generation;
      void command("preview", card.id).then((result) => {
        if (disposed || generation !== card.generation || cards.get(card.id) !== card) return;
        const src = typeof result?.src === "string" && result.src.startsWith("data:image/webp;base64,") ? result.src : null;
        cache.set(card.id, src);
        while (cache.size > 96) cache.delete(cache.keys().next().value);
        if (card.visible) show(card, src);
      }).catch(() => {
        if (!disposed && card.visible)
          placeholder(card, t("\u9884\u89C8\u52A0\u8F7D\u5931\u8D25", "Preview unavailable"));
      }).finally(() => {
        active--;
        card.loading = false;
        if (!disposed && generation !== card.generation && card.visible) enqueue(card);
        pump();
      });
    }
  }
  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        const card = cards.get(entry.target.dataset.id);
        if (!card) continue;
        card.visible = entry.isIntersecting;
        if (card.visible) enqueue(card);
        else {
          queue.delete(card);
          placeholder(card, t("\u6B63\u5728\u52A0\u8F7D\u9884\u89C8\u2026", "Loading preview\u2026"));
        }
      }
    },
    { root: library, rootMargin: "80px" }
  );
  function createCard(item) {
    const wrapper = document.createElement("div");
    wrapper.setAttribute("role", "listitem");
    wrapper.dataset.id = item.id;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "wallpaper-item";
    button.dataset.id = item.id;
    const cover = document.createElement("span");
    cover.className = "wallpaper-cover";
    const image = document.createElement("img");
    image.alt = "";
    image.hidden = true;
    image.decoding = "async";
    image.draggable = false;
    const empty = document.createElement("span");
    empty.className = "wallpaper-placeholder";
    empty.textContent = t("\u6B63\u5728\u52A0\u8F7D\u9884\u89C8\u2026", "Loading preview\u2026");
    const kind = document.createElement("span");
    kind.className = "wallpaper-type";
    const selected = document.createElement("span");
    selected.className = "wallpaper-selected";
    selected.setAttribute("aria-hidden", "true");
    selected.textContent = t("\u2713 \u5DF2\u9009", "\u2713 Selected");
    const name = document.createElement("span");
    name.className = "wallpaper-title";
    cover.append(image, empty, kind, selected);
    button.append(cover, name);
    button.onclick = () => onSelect(item.id);
    wrapper.append(button);
    const card = {
      id: item.id,
      wrapper,
      button,
      image,
      placeholder: empty,
      name,
      kind,
      selected,
      visible: false,
      loading: false,
      generation: 0
    };
    cards.set(item.id, card);
    library.append(wrapper);
    observer.observe(wrapper);
    return card;
  }
  const destroy = () => {
    if (disposed) return;
    disposed = true;
    observer.disconnect();
    queue.clear();
    for (const card of cards.values()) card.image.removeAttribute("src");
    cards.clear();
    cache.clear();
  };
  signal.addEventListener("abort", destroy, { once: true });
  return {
    update(items, current, previewsSupported) {
      if (disposed) return;
      supported = previewsSupported !== false;
      library.querySelector(".library-empty")?.remove();
      const ids = new Set(items.map((item) => item.id));
      for (const [id, card] of cards) {
        if (ids.has(id)) continue;
        observer.unobserve(card.wrapper);
        queue.delete(card);
        card.wrapper.remove();
        cards.delete(id);
        cache.delete(id);
      }
      for (const item of items) {
        const card = cards.get(item.id) ?? createCard(item);
        card.name.textContent = item.title;
        card.kind.textContent = kinds[item.type] ?? item.type;
        card.button.title = item.title;
        card.button.setAttribute("aria-label", `${item.title} \xB7 ${card.kind.textContent}`);
        card.button.setAttribute("aria-pressed", String(item.id === current));
        card.selected.hidden = item.id !== current;
      }
      if (!items.length) {
        const empty = document.createElement("p");
        empty.className = "library-empty";
        empty.textContent = t(
          "\u8FD8\u6CA1\u6709\u58C1\u7EB8\uFF0C\u9009\u62E9\u6587\u4EF6\u6216\u626B\u63CF\u5DF2\u8BA2\u9605\u7684\u5DE5\u574A\u5E93\u3002",
          "No wallpapers yet. Choose a file or scan your subscribed workshop library."
        );
        library.append(empty);
      }
    },
    refresh() {
      cache.clear();
      for (const card of cards.values()) {
        card.generation++;
        if (card.visible) enqueue(card);
      }
    },
    destroy
  };
}

// src/settings.mjs
async function mount(container, ctx) {
  const en = ctx.language.startsWith("en");
  const t = (zh, english) => en ? english : zh;
  const style = document.createElement("style");
  style.textContent = settings_default;
  const page = document.createElement("section");
  page.className = "wallpaper-settings";
  page.innerHTML = `<header><h2>${t("\u58C1\u7EB8\u4E0E\u73BB\u7483\u5916\u89C2", "Wallpaper & glass")}</h2><p>${t("\u9009\u62E9\u672C\u5730\u56FE\u7247\u3001\u89C6\u9891\u6216 Wallpaper Engine \u9879\u76EE\u7684 project.json\u3002\u6587\u4EF6\u7559\u5728\u539F\u4F4D\u7F6E\u3002", "Choose an image, video, or a Wallpaper Engine project.json. Files stay in place.")}</p></header>
    <div class="actions"><button data-action="pick">${t("\u9009\u62E9\u6587\u4EF6", "Choose file")}</button><button data-action="scan">${t("\u626B\u63CF\u5DE5\u574A\u5E93", "Scan workshop")}</button><button data-action="clear">${t("\u6062\u590D\u9ED8\u8BA4\u80CC\u666F", "Clear wallpaper")}</button></div>
    <output role="status" aria-live="polite"></output><div class="library" role="list" aria-label="${t("\u58C1\u7EB8\u5E93", "Wallpapers")}"></div>
    <form><label>${t("\u73BB\u7483\u5916\u89C2", "Glass appearance")}<input name="glass" type="checkbox"></label>
    <label>${t("\u5DE5\u4F5C\u533A\u4E0D\u900F\u660E\u5EA6", "Workspace opacity")}<input aria-label="${t("\u5DE5\u4F5C\u533A\u4E0D\u900F\u660E\u5EA6", "Workspace opacity")}" name="opacity" type="range" min="0.5" max="1" step="0.01"><span data-value="opacity"></span></label>
    <label>${t("\u5916\u6846\u52A0\u6DF1", "Darken window frame")}<input aria-label="${t("\u5916\u6846\u52A0\u6DF1", "Darken window frame")}" aria-describedby="shell-dim-hint" name="shellDim" type="range" min="0" max="0.8" step="0.01"><span data-value="shellDim"></span></label>
    <p id="shell-dim-hint" class="note">${t("\u53EA\u52A0\u6DF1\u6807\u9898\u680F\u3001\u5DE6\u4FA7\u680F\u548C\u56DB\u5468\u7559\u767D\u30020% \u4E0D\u989D\u5916\u52A0\u6DF1\uFF0C\u6570\u503C\u8D8A\u9AD8\uFF0C\u5916\u6846\u8D8A\u6DF1\u3002", "Darkens only the title bar, left sidebar, and window insets. 0% adds no extra shading; higher values make the frame darker.")}</p>
    <label>${t("\u6A21\u7CCA\u7A0B\u5EA6", "Blur")}<input aria-label="${t("\u6A21\u7CCA\u7A0B\u5EA6", "Blur")}" name="blur" type="range" min="0" max="24" step="1"><span data-value="blur"></span></label>
    <label>${t("\u58C1\u7EB8\u538B\u6697", "Dim wallpaper")}<input aria-label="${t("\u58C1\u7EB8\u538B\u6697", "Dim wallpaper")}" name="dim" type="range" min="0" max="0.8" step="0.01"><span data-value="dim"></span></label>
    <label>${t("\u5E27\u7387\u4E0A\u9650", "Frame rate")}<select name="fps"><option>15</option><option>30</option><option>60</option></select></label>
    <label>${t("\u586B\u5145\u65B9\u5F0F", "Fit")}<select name="fit"><option value="cover">${t("\u586B\u6EE1", "Cover")}</option><option value="contain">${t("\u5B8C\u6574\u663E\u793A", "Contain")}</option><option value="stretch">${t("\u62C9\u4F38", "Stretch")}</option></select></label>
    <label>${t("\u6682\u505C\u64AD\u653E", "Pause playback")}<input name="paused" type="checkbox"></label></form>
    <p class="note">${t("\u9ED8\u8BA4\u9759\u97F3\uFF0C\u7A97\u53E3\u9690\u85CF\u65F6\u6682\u505C\u3002\u573A\u666F\u517C\u5BB9\u6027\u53D6\u51B3\u4E8E WebWallGL\uFF1B\u4E0D\u652F\u6301\u542F\u52A8\u5E94\u7528\u7A0B\u5E8F\u7C7B\u58C1\u7EB8\u3002", "Muted by default; pauses when hidden. Scene compatibility depends on WebWallGL. Application wallpapers are not supported.")}</p>`;
  container.append(style, page);
  let disposed = false;
  let savedData;
  const output = page.querySelector("output"), library = page.querySelector(".library"), form = page.querySelector("form");
  const libraryView = mountPreviewLibrary(library, {
    t,
    command: ctx.command,
    signal: ctx.signal,
    onSelect: (id) => void action("select", id)
  });
  const fields = [...form.elements];
  const actionButtons = [...page.querySelectorAll("[data-action]")];
  const widgets = /* @__PURE__ */ new Map();
  const controls = () => [...fields, ...actionButtons, ...library.querySelectorAll("button")];
  const valueText = (field) => field.name === "blur" ? `${field.value}px` : `${Math.round(field.value * 100)}%`;
  function syncControl(field) {
    const widget = widgets.get(field);
    if (!widget) return;
    widget.options.disabled = field.disabled;
    if (widget.options.type === "switch") widget.options.checked = field.checked;
    if (widget.options.type === "select") widget.options.value = field.value;
    if (widget.options.type === "slider") {
      widget.options.value = Number(field.value);
      widget.options.valueText = valueText(field);
    }
    widget.handle.update({ ...widget.options });
  }
  function preview(field) {
    const label = page.querySelector(`[data-value="${field.name}"]`);
    if (label) label.textContent = valueText(field);
    syncControl(field);
  }
  function configure(field) {
    preview(field);
    void action("configure", {
      [field.name]: field.type === "checkbox" ? field.checked : field.name === "fit" ? field.value : Number(field.value)
    });
  }
  function mountControl(element, options) {
    const target = document.createElement("span");
    target.className = "host-control";
    target.dataset.type = options.type;
    element.replaceWith(target);
    const handle = ctx.controls.mount(target, options);
    widgets.set(element, { handle, options });
  }
  function render(data) {
    savedData = data;
    libraryView.update(data.items, data.settings.current, data.previewsSupported);
    for (const field of fields) {
      if (field.type === "checkbox") field.checked = data.settings[field.name];
      else field.value = data.settings[field.name];
      preview(field);
    }
    if (data.error) output.textContent = data.error;
  }
  async function action(method, payload) {
    controls().forEach((el) => {
      el.disabled = true;
      syncControl(el);
    });
    output.textContent = t("\u5904\u7406\u4E2D\u2026", "Working\u2026");
    try {
      const result = await ctx.command(method, payload);
      const data = await ctx.command("list");
      if (disposed) return;
      output.textContent = method === "scan" ? t(`\u627E\u5230 ${result.count} \u4E2A\u9879\u76EE`, `Found ${result.count} projects`) : t("\u5DF2\u4FDD\u5B58", "Saved");
      render(data);
      if (method === "scan" || method === "pick") libraryView.refresh();
    } catch (error) {
      if (!disposed) {
        if (savedData) render(savedData);
        output.textContent = error.message;
      }
    } finally {
      if (!disposed)
        controls().forEach((el) => {
          el.disabled = false;
          syncControl(el);
        });
    }
  }
  actionButtons.forEach(
    (button) => button.onclick = () => void action(
      button.dataset.action === "clear" ? "select" : button.dataset.action,
      button.dataset.action === "clear" ? null : void 0
    )
  );
  form.onchange = (event) => {
    if (fields.includes(event.target)) configure(event.target);
  };
  form.oninput = (event) => {
    if (fields.includes(event.target)) preview(event.target);
  };
  form.onsubmit = (event) => event.preventDefault();
  render(await ctx.command("list"));
  if (ctx.controls) {
    for (const button of actionButtons) {
      mountControl(button, { type: "button", label: button.textContent, onPress: button.onclick });
    }
    for (const field of fields) {
      const label = field.closest("label").firstChild.textContent;
      if (field.type === "checkbox") {
        mountControl(field, {
          type: "switch",
          label,
          checked: field.checked,
          onCheckedChange(value) {
            field.checked = value;
            configure(field);
          }
        });
      } else if (field.type === "range") {
        mountControl(field, {
          type: "slider",
          label,
          value: Number(field.value),
          valueText: valueText(field),
          min: Number(field.min),
          max: Number(field.max),
          step: Number(field.step),
          onValueChange(value) {
            field.value = String(value);
            preview(field);
          },
          onValueCommit(value) {
            field.value = String(value);
            configure(field);
          }
        });
      } else {
        mountControl(field, {
          type: "select",
          label,
          value: field.value,
          options: [...field.options].map((option) => ({
            value: option.value,
            label: option.textContent
          })),
          onValueChange(value) {
            field.value = value;
            configure(field);
          }
        });
      }
    }
  }
  const cleanup = () => {
    disposed = true;
    libraryView.destroy();
    for (const { handle } of widgets.values()) handle.destroy();
    widgets.clear();
    page.remove();
    style.remove();
  };
  ctx.signal.addEventListener("abort", cleanup, { once: true });
  if (ctx.signal.aborted) cleanup();
  return cleanup;
}
export {
  mount
};
