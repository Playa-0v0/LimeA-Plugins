// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  display: flex;\n  align-items: center;\n  gap: var(--ui-space-2);\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0;\n  padding-bottom: var(--ui-space-3);\n  border-bottom: 1px solid var(--border);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro {\n  margin-bottom: var(--ui-space-8);\n}\n.intro ul {\n  display: grid;\n  gap: var(--ui-space-2);\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.intro li {\n  position: relative;\n  padding-left: var(--ui-space-4);\n  color: var(--muted-foreground);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.intro li::before {\n  content: '';\n  position: absolute;\n  top: 0.7em;\n  left: 0;\n  width: 0.25rem;\n  height: 0.25rem;\n  border-radius: 50%;\n  background: currentColor;\n}\n.intro strong {\n  color: var(--foreground);\n  font-weight: 600;\n}\n.section-icon,\n.feature-icon,\n.section-count {\n  color: var(--muted-foreground);\n}\n.section-icon,\n.feature-icon {\n  display: inline-flex;\n  flex: none;\n}\n.section-count {\n  font-size: var(--ui-text-sm);\n  font-weight: 400;\n}\n.features,\n.settings,\n.usage {\n  margin-top: var(--ui-space-8);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n}\n.features li {\n  display: flex;\n  align-items: flex-start;\n  gap: var(--ui-space-4);\n  padding: var(--ui-space-5) 0 0;\n}\n.feature-icon {\n  width: 2.25rem;\n  min-height: 2.25rem;\n  align-items: center;\n  justify-content: center;\n}\n.features p {\n  color: var(--muted-foreground);\n}\n.settings-description {\n  margin-top: var(--ui-space-4);\n  color: var(--muted-foreground);\n}\n.settings-body {\n  margin-top: var(--ui-space-4);\n}\n.settings-loading {\n  color: var(--muted-foreground);\n}\n.usage p {\n  margin-top: var(--ui-space-4);\n  text-wrap: pretty;\n}\n.usage blockquote {\n  margin: var(--ui-space-3) 0 0;\n  padding: var(--ui-space-2) 0 var(--ui-space-2) var(--ui-space-4);\n  border-left: 2px solid var(--border);\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  text-wrap: pretty;\n}\n";

// src/settings.css
var settings_default = ":host {\n  color: var(--foreground, #efefef);\n  font: 14px/1.5 system-ui;\n}\n*,\n*::before,\n*::after {\n  box-sizing: border-box;\n}\n.wallpaper-settings {\n  max-width: 780px;\n  padding: 20px;\n}\nh2 {\n  font-size: 20px;\n  margin: 0 0 8px;\n}\np {\n  color: var(--muted-foreground, #bbb);\n  margin: 0 0 18px;\n}\n.actions {\n  display: flex;\n  gap: 8px;\n  flex-wrap: wrap;\n}\nbutton,\nselect {\n  font: inherit;\n  color: inherit;\n  background: var(--surface, #303030);\n  border: 1px solid var(--border, #555);\n  border-radius: 6px;\n  padding: 8px 12px;\n}\nbutton {\n  cursor: pointer;\n}\nbutton:hover {\n  background: var(--surface-hover, #444);\n}\nbutton:disabled {\n  opacity: 0.6;\n  cursor: wait;\n}\nbutton:focus-visible,\ninput:focus-visible,\nselect:focus-visible {\n  outline: 2px solid var(--primary, #adeb78);\n  outline-offset: 2px;\n}\noutput {\n  display: block;\n  min-height: 24px;\n  margin: 12px 0;\n  color: var(--muted-foreground, #bbb);\n  overflow-wrap: anywhere;\n}\n.library {\n  display: grid;\n  grid-template-columns: repeat(auto-fill, minmax(min(170px, 100%), 1fr));\n  gap: 12px;\n  max-height: min(360px, 45vh);\n  overflow-y: auto;\n  border-block: 1px solid var(--border, #555);\n  padding: 12px 4px;\n  scrollbar-gutter: stable;\n}\n.library > [role='listitem'] {\n  min-width: 0;\n}\n.wallpaper-item {\n  display: flex;\n  flex-direction: column;\n  text-align: start;\n  width: 100%;\n  height: 100%;\n  min-width: 0;\n  padding: 0;\n  overflow: hidden;\n  border: 1px solid var(--border, #555);\n  border-radius: var(--ui-radius-md, 8px);\n  background: var(--surface, #252525);\n}\n.wallpaper-cover {\n  display: grid;\n  place-items: center;\n  position: relative;\n  width: 100%;\n  aspect-ratio: 16 / 9;\n  background: var(--muted, #292929);\n}\n.wallpaper-cover img {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  object-fit: cover;\n}\n.wallpaper-placeholder {\n  color: var(--muted-foreground, #bbb);\n  font-size: 12px;\n  padding: 12px;\n  text-align: center;\n}\n.wallpaper-type,\n.wallpaper-selected {\n  position: absolute;\n  top: 7px;\n  padding: 2px 6px;\n  border-radius: 4px;\n  font-size: 11px;\n  line-height: 1.5;\n}\n.wallpaper-type {\n  left: 7px;\n  background: rgb(0 0 0 / 72%);\n  color: #fff;\n}\n.wallpaper-selected {\n  right: 7px;\n  background: var(--primary, #adeb78);\n  color: var(--primary-foreground, #152009);\n}\n.wallpaper-title {\n  display: -webkit-box;\n  -webkit-box-orient: vertical;\n  -webkit-line-clamp: 2;\n  min-height: 36px;\n  padding: 9px 10px;\n  overflow: hidden;\n  overflow-wrap: anywhere;\n  font-size: 12px;\n  line-height: 18px;\n}\n.library-empty {\n  grid-column: 1 / -1;\n  margin: 0;\n  padding: 20px 8px;\n}\n.wallpaper-item[aria-pressed='true'] {\n  border-color: var(--primary, #adeb78);\n  box-shadow: inset 0 0 0 1px var(--primary, #adeb78);\n}\n.wallpaper-item[aria-pressed='true'] .wallpaper-title {\n  color: var(--primary, #adeb78);\n}\n.wallpaper-cover [hidden] {\n  display: none;\n}\nform {\n  display: grid;\n  gap: 14px;\n  padding: 20px 0;\n}\nlabel {\n  display: flex;\n  align-items: center;\n  gap: 12px;\n  min-width: 0;\n}\nlabel input,\nlabel select {\n  margin-left: auto;\n}\n.host-control {\n  display: inline-flex;\n  align-items: center;\n  min-width: 0;\n}\nlabel .host-control {\n  margin-left: auto;\n}\n.host-control[data-type='slider'] {\n  width: min(38vw, 210px);\n}\ninput[type='range'] {\n  width: min(38vw, 210px);\n  accent-color: var(--primary, #adeb78);\n}\ninput[type='checkbox'] {\n  width: 18px;\n  height: 18px;\n  accent-color: var(--primary, #adeb78);\n}\n[data-value] {\n  width: 44px;\n  text-align: right;\n  font-variant-numeric: tabular-nums;\n}\n.note {\n  font-size: 12px;\n  margin: 0;\n}\n";

// src/preview-library.mjs
function mountPreviewLibrary(library, { t, command, onSelect, signal }) {
  const cards = /* @__PURE__ */ new Map();
  const cache = /* @__PURE__ */ new Map();
  const queue = /* @__PURE__ */ new Set();
  let active = 0, disposed = false, supported = true;
  const kinds = {
    image: t("\u56FE\u7247", "Image"),
    video: t("\u89C6\u9891", "Video"),
    web: t("\u7F51\u9875", "Web"),
    scene: t("\u573A\u666F", "Scene")
  };
  const placeholder = (card, message) => {
    card.image.hidden = true;
    card.image.removeAttribute("src");
    card.placeholder.hidden = false;
    card.placeholder.textContent = message;
  };
  function show(card, src) {
    if (!src) {
      placeholder(card, t("\u6682\u65E0\u9884\u89C8", "No preview"));
      return;
    }
    card.image.onload = () => {
      if (disposed || !card.visible) return;
      card.image.hidden = false;
      card.placeholder.hidden = true;
    };
    card.image.onerror = () => placeholder(card, t("\u6682\u65E0\u9884\u89C8", "No preview"));
    card.image.src = src;
  }
  function enqueue(card) {
    if (!supported) {
      placeholder(card, t("\u66F4\u65B0 LimeA \u663E\u793A\u9884\u89C8", "Update LimeA for previews"));
    } else if (cache.has(card.id)) {
      const src = cache.get(card.id);
      cache.delete(card.id);
      cache.set(card.id, src);
      show(card, src);
    } else if (!card.loading) {
      queue.add(card);
      pump();
    }
  }
  function pump() {
    while (!disposed && active < 2 && queue.size) {
      const card = queue.values().next().value;
      queue.delete(card);
      if (!card.visible || !cards.has(card.id)) continue;
      active++;
      card.loading = true;
      const generation = card.generation;
      void command("preview", card.id).then((result) => {
        if (disposed || generation !== card.generation || cards.get(card.id) !== card) return;
        const src = typeof result?.src === "string" && result.src.startsWith("data:image/webp;base64,") ? result.src : null;
        cache.set(card.id, src);
        while (cache.size > 96) cache.delete(cache.keys().next().value);
        if (card.visible) show(card, src);
      }).catch(() => {
        if (!disposed && card.visible)
          placeholder(card, t("\u9884\u89C8\u52A0\u8F7D\u5931\u8D25", "Preview unavailable"));
      }).finally(() => {
        active--;
        card.loading = false;
        if (!disposed && generation !== card.generation && card.visible) enqueue(card);
        pump();
      });
    }
  }
  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        const card = cards.get(entry.target.dataset.id);
        if (!card) continue;
        card.visible = entry.isIntersecting;
        if (card.visible) enqueue(card);
        else {
          queue.delete(card);
          placeholder(card, t("\u6B63\u5728\u52A0\u8F7D\u9884\u89C8\u2026", "Loading preview\u2026"));
        }
      }
    },
    { root: library, rootMargin: "80px" }
  );
  function createCard(item) {
    const wrapper = document.createElement("div");
    wrapper.setAttribute("role", "listitem");
    wrapper.dataset.id = item.id;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "wallpaper-item";
    button.dataset.id = item.id;
    const cover = document.createElement("span");
    cover.className = "wallpaper-cover";
    const image = document.createElement("img");
    image.alt = "";
    image.hidden = true;
    image.decoding = "async";
    image.draggable = false;
    const empty = document.createElement("span");
    empty.className = "wallpaper-placeholder";
    empty.textContent = t("\u6B63\u5728\u52A0\u8F7D\u9884\u89C8\u2026", "Loading preview\u2026");
    const kind = document.createElement("span");
    kind.className = "wallpaper-type";
    const selected = document.createElement("span");
    selected.className = "wallpaper-selected";
    selected.setAttribute("aria-hidden", "true");
    selected.textContent = t("\u2713 \u5DF2\u9009", "\u2713 Selected");
    const name = document.createElement("span");
    name.className = "wallpaper-title";
    cover.append(image, empty, kind, selected);
    button.append(cover, name);
    button.onclick = () => onSelect(item.id);
    wrapper.append(button);
    const card = {
      id: item.id,
      wrapper,
      button,
      image,
      placeholder: empty,
      name,
      kind,
      selected,
      visible: false,
      loading: false,
      generation: 0
    };
    cards.set(item.id, card);
    library.append(wrapper);
    observer.observe(wrapper);
    return card;
  }
  const destroy = () => {
    if (disposed) return;
    disposed = true;
    observer.disconnect();
    queue.clear();
    for (const card of cards.values()) card.image.removeAttribute("src");
    cards.clear();
    cache.clear();
  };
  signal.addEventListener("abort", destroy, { once: true });
  return {
    update(items, current, previewsSupported) {
      if (disposed) return;
      supported = previewsSupported !== false;
      library.querySelector(".library-empty")?.remove();
      const ids = new Set(items.map((item) => item.id));
      for (const [id, card] of cards) {
        if (ids.has(id)) continue;
        observer.unobserve(card.wrapper);
        queue.delete(card);
        card.wrapper.remove();
        cards.delete(id);
        cache.delete(id);
      }
      for (const item of items) {
        const card = cards.get(item.id) ?? createCard(item);
        card.name.textContent = item.title;
        card.kind.textContent = kinds[item.type] ?? item.type;
        card.button.title = item.title;
        card.button.setAttribute("aria-label", `${item.title} \xB7 ${card.kind.textContent}`);
        card.button.setAttribute("aria-pressed", String(item.id === current));
        card.selected.hidden = item.id !== current;
      }
      if (!items.length) {
        const empty = document.createElement("p");
        empty.className = "library-empty";
        empty.textContent = t(
          "\u8FD8\u6CA1\u6709\u58C1\u7EB8\uFF0C\u9009\u62E9\u6587\u4EF6\u6216\u626B\u63CF\u5DF2\u8BA2\u9605\u7684\u5DE5\u574A\u5E93\u3002",
          "No wallpapers yet. Choose a file or scan your subscribed workshop library."
        );
        library.append(empty);
      }
    },
    refresh() {
      cache.clear();
      for (const card of cards.values()) {
        card.generation++;
        if (card.visible) enqueue(card);
      }
    },
    destroy
  };
}

// src/settings.mjs
async function mount(container, ctx) {
  const en2 = ctx.language.startsWith("en");
  const t = (zh2, english) => en2 ? english : zh2;
  const style = document.createElement("style");
  style.textContent = settings_default;
  const page = document.createElement("section");
  page.className = "wallpaper-settings";
  page.innerHTML = `<div class="actions"><button data-action="pick">${t("\u9009\u62E9\u6587\u4EF6", "Choose file")}</button><button data-action="scan">${t("\u626B\u63CF\u5DE5\u574A\u5E93", "Scan workshop")}</button><button data-action="clear">${t("\u6062\u590D\u9ED8\u8BA4\u80CC\u666F", "Clear wallpaper")}</button></div>
    <output role="status" aria-live="polite"></output><div class="library" role="list" aria-label="${t("\u58C1\u7EB8\u5E93", "Wallpapers")}"></div>
    <form><label>${t("\u73BB\u7483\u5916\u89C2", "Glass appearance")}<input name="glass" type="checkbox"></label>
    <label>${t("\u5DE5\u4F5C\u533A\u4E0D\u900F\u660E\u5EA6", "Workspace opacity")}<input aria-label="${t("\u5DE5\u4F5C\u533A\u4E0D\u900F\u660E\u5EA6", "Workspace opacity")}" name="opacity" type="range" min="0.5" max="1" step="0.01"><span data-value="opacity"></span></label>
    <label>${t("\u5916\u6846\u52A0\u6DF1", "Darken window frame")}<input aria-label="${t("\u5916\u6846\u52A0\u6DF1", "Darken window frame")}" aria-describedby="shell-dim-hint" name="shellDim" type="range" min="0" max="0.8" step="0.01"><span data-value="shellDim"></span></label>
    <p id="shell-dim-hint" class="note">${t("\u53EA\u52A0\u6DF1\u6807\u9898\u680F\u3001\u5DE6\u4FA7\u680F\u548C\u56DB\u5468\u7559\u767D\u30020% \u4E0D\u989D\u5916\u52A0\u6DF1\uFF0C\u6570\u503C\u8D8A\u9AD8\uFF0C\u5916\u6846\u8D8A\u6DF1\u3002", "Darkens only the title bar, left sidebar, and window insets. 0% adds no extra shading; higher values make the frame darker.")}</p>
    <label>${t("\u6A21\u7CCA\u7A0B\u5EA6", "Blur")}<input aria-label="${t("\u6A21\u7CCA\u7A0B\u5EA6", "Blur")}" name="blur" type="range" min="0" max="24" step="1"><span data-value="blur"></span></label>
    <label>${t("\u58C1\u7EB8\u538B\u6697", "Dim wallpaper")}<input aria-label="${t("\u58C1\u7EB8\u538B\u6697", "Dim wallpaper")}" name="dim" type="range" min="0" max="0.8" step="0.01"><span data-value="dim"></span></label>
    <label>${t("\u5E27\u7387\u4E0A\u9650", "Frame rate")}<select name="fps"><option>15</option><option>30</option><option>60</option></select></label>
    <label>${t("\u586B\u5145\u65B9\u5F0F", "Fit")}<select name="fit"><option value="cover">${t("\u586B\u6EE1", "Cover")}</option><option value="contain">${t("\u5B8C\u6574\u663E\u793A", "Contain")}</option><option value="stretch">${t("\u62C9\u4F38", "Stretch")}</option></select></label>
    <label>${t("\u6682\u505C\u64AD\u653E", "Pause playback")}<input name="paused" type="checkbox"></label></form>
    <p class="note">${t("\u9ED8\u8BA4\u9759\u97F3\uFF0C\u7A97\u53E3\u9690\u85CF\u65F6\u6682\u505C\u3002\u573A\u666F\u517C\u5BB9\u6027\u53D6\u51B3\u4E8E WebWallGL\uFF1B\u4E0D\u652F\u6301\u542F\u52A8\u5E94\u7528\u7A0B\u5E8F\u7C7B\u58C1\u7EB8\u3002", "Muted by default; pauses when hidden. Scene compatibility depends on WebWallGL. Application wallpapers are not supported.")}</p>`;
  container.append(style, page);
  let disposed = false;
  let savedData;
  const output = page.querySelector("output"), library = page.querySelector(".library"), form = page.querySelector("form");
  const libraryView = mountPreviewLibrary(library, {
    t,
    command: ctx.command,
    signal: ctx.signal,
    onSelect: (id) => void action("select", id)
  });
  const fields = [...form.elements];
  const actionButtons = [...page.querySelectorAll("[data-action]")];
  const widgets = /* @__PURE__ */ new Map();
  const controls = () => [...fields, ...actionButtons, ...library.querySelectorAll("button")];
  const valueText = (field) => field.name === "blur" ? `${field.value}px` : `${Math.round(field.value * 100)}%`;
  function syncControl(field) {
    const widget = widgets.get(field);
    if (!widget) return;
    widget.options.disabled = field.disabled;
    if (widget.options.type === "switch") widget.options.checked = field.checked;
    if (widget.options.type === "select") widget.options.value = field.value;
    if (widget.options.type === "slider") {
      widget.options.value = Number(field.value);
      widget.options.valueText = valueText(field);
    }
    widget.handle.update({ ...widget.options });
  }
  function preview(field) {
    const label = page.querySelector(`[data-value="${field.name}"]`);
    if (label) label.textContent = valueText(field);
    syncControl(field);
  }
  function configure(field) {
    preview(field);
    void action("configure", {
      [field.name]: field.type === "checkbox" ? field.checked : field.name === "fit" ? field.value : Number(field.value)
    });
  }
  function mountControl(element, options) {
    const target = document.createElement("span");
    target.className = "host-control";
    target.dataset.type = options.type;
    element.replaceWith(target);
    const handle = ctx.controls.mount(target, options);
    widgets.set(element, { handle, options });
  }
  function render(data) {
    savedData = data;
    libraryView.update(data.items, data.settings.current, data.previewsSupported);
    for (const field of fields) {
      if (field.type === "checkbox") field.checked = data.settings[field.name];
      else field.value = data.settings[field.name];
      preview(field);
    }
    if (data.error) output.textContent = data.error;
  }
  async function action(method, payload) {
    controls().forEach((el) => {
      el.disabled = true;
      syncControl(el);
    });
    output.textContent = t("\u5904\u7406\u4E2D\u2026", "Working\u2026");
    try {
      const result = await ctx.command(method, payload);
      const data = await ctx.command("list");
      if (disposed) return;
      output.textContent = method === "scan" ? t(`\u627E\u5230 ${result.count} \u4E2A\u9879\u76EE`, `Found ${result.count} projects`) : t("\u5DF2\u4FDD\u5B58", "Saved");
      render(data);
      if (method === "scan" || method === "pick") libraryView.refresh();
    } catch (error) {
      if (!disposed) {
        if (savedData) render(savedData);
        output.textContent = error.message;
      }
    } finally {
      if (!disposed)
        controls().forEach((el) => {
          el.disabled = false;
          syncControl(el);
        });
    }
  }
  actionButtons.forEach(
    (button) => button.onclick = () => void action(
      button.dataset.action === "clear" ? "select" : button.dataset.action,
      button.dataset.action === "clear" ? null : void 0
    )
  );
  form.onchange = (event) => {
    if (fields.includes(event.target)) configure(event.target);
  };
  form.oninput = (event) => {
    if (fields.includes(event.target)) preview(event.target);
  };
  form.onsubmit = (event) => event.preventDefault();
  render(await ctx.command("list"));
  if (ctx.controls) {
    for (const button of actionButtons) {
      mountControl(button, { type: "button", label: button.textContent, onPress: button.onclick });
    }
    for (const field of fields) {
      const label = field.closest("label").firstChild.textContent;
      if (field.type === "checkbox") {
        mountControl(field, {
          type: "switch",
          label,
          checked: field.checked,
          onCheckedChange(value) {
            field.checked = value;
            configure(field);
          }
        });
      } else if (field.type === "range") {
        mountControl(field, {
          type: "slider",
          label,
          value: Number(field.value),
          valueText: valueText(field),
          min: Number(field.min),
          max: Number(field.max),
          step: Number(field.step),
          onValueChange(value) {
            field.value = String(value);
            preview(field);
          },
          onValueCommit(value) {
            field.value = String(value);
            configure(field);
          }
        });
      } else {
        mountControl(field, {
          type: "select",
          label,
          value: field.value,
          options: [...field.options].map((option) => ({
            value: option.value,
            label: option.textContent
          })),
          onValueChange(value) {
            field.value = value;
            configure(field);
          }
        });
      }
    }
  }
  const cleanup = () => {
    disposed = true;
    libraryView.destroy();
    for (const { handle } of widgets.values()) handle.destroy();
    widgets.clear();
    page.remove();
    style.remove();
  };
  ctx.signal.addEventListener("abort", cleanup, { once: true });
  if (ctx.signal.aborted) cleanup();
  return cleanup;
}

// src/page-strings.mjs
var zh = {
  introLabel: "\u58C1\u7EB8\u4E0E\u73BB\u7483\u5916\u89C2\u80FD\u505A\u4EC0\u4E48",
  introSourcesTitle: "\u591A\u79CD\u6765\u6E90\uFF1A",
  introSourcesDetail: "\u672C\u5730\u56FE\u7247\u3001\u89C6\u9891\u3001Wallpaper Engine \u7684 project.json\uFF0C\u6216\u76F4\u63A5\u626B\u63CF Steam \u5DE5\u574A\u5E93\u3002",
  introLibraryTitle: "\u7F29\u7565\u56FE\u9009\u62E9\uFF1A",
  introLibraryDetail: "\u58C1\u7EB8\u5E93\u7528\u5C01\u9762\u7F51\u683C\u5C55\u793A\uFF0C\u5BBD\u7A97\u53E3\u4E09\u5217\u3001\u7A84\u7A97\u53E3\u4E24\u5217\uFF0C\u6807\u51FA\u540D\u79F0\u3001\u7C7B\u578B\u548C\u5DF2\u9009\u9879\u76EE\u3002",
  introGlassTitle: "\u73BB\u7483\u4E0E\u538B\u6697\uFF1A",
  introGlassDetail: "\u73BB\u7483\u5F00\u5173\u63A7\u5236\u6A21\u7CCA\uFF0C\u6ED1\u52A8\u6761\u8C03\u6574\u5DE5\u4F5C\u533A\u4E0D\u900F\u660E\u5EA6\u3001\u58C1\u7EB8\u538B\u6697\u548C\u5916\u6846\u52A0\u6DF1\u3002",
  introSafeTitle: "\u5B89\u5168\u4E0E\u6062\u590D\uFF1A",
  introSafeDetail: "\u5A92\u4F53\u53EA\u901A\u8FC7\u56DE\u73AF\u5730\u5740\u548C\u968F\u673A\u51ED\u636E\u63D0\u4F9B\uFF0C\u6587\u4EF6\u7559\u5728\u539F\u4F4D\u7F6E\uFF1B\u505C\u7528\u6216\u6E05\u9664\u540E\u6062\u590D\u539F\u751F\u5916\u89C2\u3002",
  featuresTitle: "\u63D2\u4EF6\u529F\u80FD",
  sourcesTitle: "\u58C1\u7EB8\u6765\u6E90",
  sourcesDetail: "\u652F\u6301\u672C\u5730\u56FE\u7247\u3001\u9759\u97F3\u89C6\u9891\u3001Wallpaper Engine \u9879\u76EE\u7684 project.json \u548C\u7F51\u9875\u58C1\u7EB8\uFF1B\u4E0D\u4E0B\u8F7D\u5DE5\u574A\u5185\u5BB9\uFF0C\u4E0D\u542F\u52A8\u5E94\u7528\u7A0B\u5E8F\u7C7B\u58C1\u7EB8\u3002",
  libraryTitle: "\u9884\u89C8\u4E0E\u9009\u62E9",
  libraryDetail: "\u5DE5\u574A\u9879\u76EE\u4F18\u5148\u8BFB\u53D6 project.json \u7684 preview\uFF0C\u672C\u5730\u56FE\u7247\u4F7F\u7528\u81EA\u8EAB\u7F29\u7565\u56FE\uFF1B\u53EA\u52A0\u8F7D\u53EF\u89C6\u533A\u9644\u8FD1\u5C01\u9762\uFF0C\u6700\u591A\u4E24\u9879\u8BF7\u6C42\uFF0C\u524D\u7AEF\u7F13\u5B58 96 \u9879\u3002",
  glassTitle: "\u73BB\u7483\u5916\u89C2",
  glassDetail: "\u73BB\u7483\u5F00\u5173\u53EA\u63A7\u5236\u6A21\u7CCA\uFF0C\u5173\u95ED\u540E\u4ECD\u663E\u793A\u58C1\u7EB8\u5E76\u4FDD\u7559\u4E0D\u900F\u660E\u5EA6\uFF1B\u53EF\u8C03\u5DE5\u4F5C\u533A\u4E0D\u900F\u660E\u5EA6\u3001\u6A21\u7CCA\u548C\u58C1\u7EB8\u538B\u6697\u3002",
  frameTitle: "\u5916\u6846\u52A0\u6DF1",
  frameDetail: "\u53EA\u52A0\u6DF1\u6807\u9898\u680F\u3001\u5DE6\u4FA7\u680F\u548C\u56DB\u5468\u7559\u767D\uFF0C0%\u201380% \u53EF\u8C03\uFF0C\u9ED8\u8BA4 35%\uFF1B\u4E0D\u6539\u53D8\u5DE5\u4F5C\u533A\u5185\u5BB9\u533A\u57DF\u3002",
  playbackTitle: "\u64AD\u653E\u63A7\u5236",
  playbackDetail: "\u5E27\u7387\u53EF\u9009 15/30/60\uFF0C\u586B\u5145\u65B9\u5F0F\u652F\u6301 cover\u3001contain\u3001stretch\uFF0C\u4E5F\u53EF\u4EE5\u6682\u505C\u64AD\u653E\uFF1B\u5A92\u4F53\u9ED8\u8BA4\u9759\u97F3\uFF0C\u7A97\u53E3\u9690\u85CF\u65F6\u6682\u505C\u3002",
  securityTitle: "\u5B89\u5168\u8FB9\u754C",
  securityDetail: "\u58C1\u7EB8\u811A\u672C\u8FD0\u884C\u5728\u72EC\u7ACB\u56DE\u73AF\u6765\u6E90\u7684\u53D7\u9650\u6846\u67B6\u4E2D\uFF0C\u4E0D\u83B7\u5F97 LimeA \u684C\u9762\u6865\u63A5\uFF1B\u5A92\u4F53\u8DEF\u5F84\u6709\u968F\u673A\u51ED\u636E\u4E14\u53EA\u8BFB\uFF0C\u5355\u6587\u4EF6\u9009\u62E9\u4E0D\u5F00\u653E\u540C\u76EE\u5F55\u5176\u4ED6\u6587\u4EF6\u3002",
  stateTitle: "\u72B6\u6001\u4E0E\u6062\u590D",
  stateDetail: "\u914D\u7F6E\u548C\u58C1\u7EB8\u5217\u8868\u5B58\u5165\u5BBF\u4E3B SQLite\uFF0C\u5347\u7EA7\u4E0D\u91CD\u7F6E\uFF1B\u6E05\u9664\u4EC5\u53D6\u6D88\u9009\u62E9\uFF0C\u4E0D\u5220\u9664\u539F\u6587\u4EF6\u3002\u626B\u63CF\u5931\u8D25\u6216\u573A\u666F\u4E0D\u517C\u5BB9\u4F1A\u5728\u8BBE\u7F6E\u533A\u63D0\u793A\u3002",
  pageSettingsTitle: "\u5916\u89C2\u8BBE\u7F6E",
  settingsLoading: "\u6B63\u5728\u8BFB\u53D6\u5916\u89C2\u8BBE\u7F6E\u2026",
  pageSettingsDescription: "\u9009\u62E9\u56FE\u7247\u3001\u89C6\u9891\u6216 Wallpaper Engine \u9879\u76EE\u7684 project.json\uFF1B\u4E5F\u53EF\u4EE5\u626B\u63CF Steam \u5DE5\u574A\u5E93\u3002\u9009\u62E9\u540E\u7ACB\u5373\u5E94\u7528\u5E76\u81EA\u52A8\u4FDD\u5B58\u3002",
  settingsLoadFailed: "\u5916\u89C2\u8BBE\u7F6E\u52A0\u8F7D\u5931\u8D25\uFF0C\u8BF7\u8FD4\u56DE\u540E\u91CD\u8BD5\u3002",
  usageTitle: "\u5F00\u59CB\u4F7F\u7528",
  usage: "\u5728\u4E0B\u65B9\u300C\u5916\u89C2\u8BBE\u7F6E\u300D\u9009\u62E9\u58C1\u7EB8\uFF0C\u518D\u8C03\u6574\u73BB\u7483\u3001\u6A21\u7CCA\u3001\u538B\u6697\u3001\u5916\u6846\u548C\u64AD\u653E\u9009\u9879\u3002\u6240\u6709\u6539\u52A8\u81EA\u52A8\u4FDD\u5B58\uFF0C\u91CD\u542F\u540E\u6062\u590D\u3002",
  usageExample: "\u5EFA\u8BAE\u5148\u9009\u4E00\u5F20\u9AD8\u5206\u8FA8\u7387\u56FE\u7247\uFF0C\u518D\u8C03\u6574\u5DE5\u4F5C\u533A\u4E0D\u900F\u660E\u5EA6\u548C\u6A21\u7CCA\uFF0C\u770B\u770B\u5B9E\u9645\u6548\u679C\u3002"
};
var en = {
  introLabel: "What Wallpaper & Glass can do",
  introSourcesTitle: "Many sources:",
  introSourcesDetail: "Local images, videos, a Wallpaper Engine project.json, or a scan of your Steam workshop library.",
  introLibraryTitle: "Pick from previews:",
  introLibraryDetail: "The wallpaper library uses a cover grid: three columns on wide windows, two on narrow ones, with name, type and selection marked.",
  introGlassTitle: "Glass and dimming:",
  introGlassDetail: "The glass toggle controls blur; sliders adjust workspace opacity, wallpaper dimming and frame darkening.",
  introSafeTitle: "Safe and reversible:",
  introSafeDetail: "Media is served over loopback with random credentials; files stay in place, and disabling or clearing restores the native background.",
  featuresTitle: "Plugin features",
  sourcesTitle: "Wallpaper sources",
  sourcesDetail: "Local images, muted videos, Wallpaper Engine project.json files and web wallpapers. It does not download workshop content or start application wallpapers.",
  libraryTitle: "Previews and selection",
  libraryDetail: "Workshop projects prefer the preview in project.json, while local images use their own thumbnail. Only covers near the viewport load, at most two requests, with a 96-item client cache.",
  glassTitle: "Glass appearance",
  glassDetail: "The glass toggle controls blur only; turning it off still shows the wallpaper and keeps the opacity setting. Workspace opacity, blur and wallpaper dimming are adjustable.",
  frameTitle: "Darker window frame",
  frameDetail: "Darkens only the title bar, left sidebar and window insets, adjustable from 0% to 80% with a 35% default; the workspace content area is unchanged.",
  playbackTitle: "Playback controls",
  playbackDetail: "Frame rate 15/30/60, fit cover, contain or stretch, and pause playback. Media is muted by default and pauses when the window is hidden.",
  securityTitle: "Security boundary",
  securityDetail: "Wallpaper scripts run in a restricted frame on a separate loopback origin without the LimeA desktop bridge. Media paths use random read-only credentials, and a single-file choice does not expose its directory.",
  stateTitle: "State and recovery",
  stateDetail: "Configuration and the wallpaper list are stored in host SQLite and survive upgrades; clearing only deselects and never deletes original files. Scan failures or incompatible scenes appear in settings.",
  pageSettingsTitle: "Appearance settings",
  settingsLoading: "Loading appearance settings\u2026",
  pageSettingsDescription: "Choose an image, video, or Wallpaper Engine project.json, or scan your Steam workshop library. Changes apply immediately and save automatically.",
  settingsLoadFailed: "Could not load appearance settings. Go back and try again.",
  usageTitle: "Start using it",
  usage: "Pick a wallpaper in Appearance settings below, then adjust glass, blur, dimming, frame and playback options. Everything saves automatically and returns after a restart.",
  usageExample: "Try a high-resolution image first, then tune workspace opacity and blur to see the effect."
};

// src/page.mjs
async function mount2(container, context) {
  if (!context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "wallpaper-page";
  root.innerHTML = `
    <section class="intro" aria-label="">
      <ul></ul>
    </section>
    <section class="features" aria-labelledby="wallpaper-features-title">
      <h2 id="wallpaper-features-title"><span class="section-icon" data-icon="blocks"></span><span class="heading-label"></span><span class="section-count"></span></h2>
      <ul></ul>
    </section>
    <section class="settings" aria-labelledby="wallpaper-settings-title">
      <h2 id="wallpaper-settings-title"><span class="section-icon" data-icon="link"></span><span class="heading-label"></span></h2>
      <p class="settings-description"></p>
      <div class="settings-body"><p class="settings-loading" role="status"></p></div>
    </section>
    <section class="usage" aria-labelledby="wallpaper-usage-title">
      <h2 id="wallpaper-usage-title"><span class="section-icon" data-icon="message-square"></span><span class="heading-label"></span></h2>
      <p></p>
      <blockquote></blockquote>
    </section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query(".intro").setAttribute("aria-label", t.introLabel);
  const introItems = [
    [t.introSourcesTitle, t.introSourcesDetail],
    [t.introLibraryTitle, t.introLibraryDetail],
    [t.introGlassTitle, t.introGlassDetail],
    [t.introSafeTitle, t.introSafeDetail]
  ];
  const introList = query(".intro ul");
  for (const [title, detail] of introItems) {
    const item = document.createElement("li");
    const heading = document.createElement("strong");
    heading.textContent = title;
    const copy = document.createElement("span");
    copy.textContent = detail;
    item.append(heading, copy);
    introList.append(item);
  }
  const features = [
    { icon: "blocks", title: t.sourcesTitle, detail: t.sourcesDetail },
    { icon: "list-tree", title: t.libraryTitle, detail: t.libraryDetail },
    { icon: "circle-check", title: t.glassTitle, detail: t.glassDetail },
    { icon: "circle-dashed", title: t.frameTitle, detail: t.frameDetail },
    { icon: "refresh-cw", title: t.playbackTitle, detail: t.playbackDetail },
    { icon: "shield-check", title: t.securityTitle, detail: t.securityDetail },
    { icon: "file-text", title: t.stateTitle, detail: t.stateDetail }
  ];
  const featureList = query(".features ul");
  for (const feature of features) {
    const item = document.createElement("li");
    const iconSlot = document.createElement("span");
    iconSlot.className = "feature-icon";
    iconSlot.dataset.icon = feature.icon;
    const copy = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = feature.title;
    const detail = document.createElement("p");
    detail.textContent = feature.detail;
    copy.append(heading, detail);
    item.append(iconSlot, copy);
    featureList.append(item);
  }
  query(".features h2 .heading-label").textContent = t.featuresTitle;
  query(".features h2 .section-count").textContent = String(features.length);
  query(".settings h2 .heading-label").textContent = t.pageSettingsTitle;
  query(".settings-description").textContent = t.pageSettingsDescription;
  const loading = query(".settings-loading");
  loading.textContent = t.settingsLoading;
  query(".usage h2 .heading-label").textContent = t.usageTitle;
  query(".usage p").textContent = t.usage;
  query(".usage blockquote").textContent = t.usageExample;
  const handles = [];
  for (const slot of root.querySelectorAll("[data-icon]")) {
    const name = slot.dataset.icon;
    if (context.controls.icons?.includes(name))
      handles.push(context.controls.mount(slot, { type: "icon", name, size: 18 }));
    else slot.hidden = true;
  }
  let settingsCleanup = () => {
  };
  try {
    settingsCleanup = await mount(query(".settings-body"), context);
    loading.remove();
  } catch {
    loading.textContent = t.settingsLoadFailed;
    loading.setAttribute("role", "alert");
  }
  function cleanup() {
    settingsCleanup();
    for (const handle of handles) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  return cleanup;
}
export {
  mount2 as mount
};
