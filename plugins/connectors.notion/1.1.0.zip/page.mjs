// src/page.css
var page_default = ":host {\n  color: var(--foreground);\n  font-family: inherit;\n}\n* {\n  box-sizing: border-box;\n}\n[hidden] {\n  display: none !important;\n}\nh2 {\n  font-size: var(--ui-text-base);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-4);\n}\nh3 {\n  font-size: var(--ui-text-sm);\n  font-weight: 600;\n  margin: 0 0 var(--ui-space-1);\n}\np {\n  margin: 0;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.account {\n  border: 1px solid var(--border);\n  border-radius: var(--ui-radius-lg);\n  padding: var(--ui-space-5);\n}\n.account-row {\n  display: flex;\n  align-items: center;\n  flex-wrap: wrap;\n  gap: var(--ui-space-4);\n}\n.account-summary {\n  flex: 1;\n  min-width: min(100%, 14rem);\n}\n.account-name {\n  display: block;\n  font-size: var(--ui-text-sm);\n  line-height: var(--ui-leading-prose);\n  overflow-wrap: anywhere;\n}\n.account-hint {\n  margin-top: var(--ui-space-1);\n  color: var(--muted-foreground);\n}\n.account-actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: var(--ui-space-2);\n}\n.account-status {\n  margin-top: var(--ui-space-4);\n  color: var(--muted-foreground);\n}\n.account-error {\n  margin-top: var(--ui-space-4);\n}\n.account-error p {\n  color: var(--destructive);\n  margin-bottom: var(--ui-space-2);\n}\n.features,\n.usage {\n  margin-top: var(--ui-space-7);\n}\n.features ul {\n  margin: 0;\n  padding: 0;\n  list-style: none;\n  border-top: 1px solid var(--border);\n}\n.features li {\n  padding: var(--ui-space-4) 0;\n  border-bottom: 1px solid var(--border);\n}\n.features p {\n  color: var(--muted-foreground);\n}\n.usage p {\n  text-wrap: pretty;\n}\n";

// src/strings.mjs
var zh = {
  accountTitle: "\u8D26\u53F7\u8FDE\u63A5",
  loading: "\u6B63\u5728\u8BFB\u53D6\u8FDE\u63A5\u72B6\u6001\u2026",
  loadFailed: "\u65E0\u6CD5\u8BFB\u53D6\u8FDE\u63A5\u72B6\u6001\uFF0C\u8BF7\u91CD\u8BD5\u3002",
  retry: "\u91CD\u8BD5",
  vaultUnavailable: "\u7CFB\u7EDF\u51ED\u636E\u4FDD\u62A4\u4E0D\u53EF\u7528\uFF0C\u65E0\u6CD5\u4FDD\u5B58\u8D26\u53F7\u3002\u8BF7\u89E3\u9501\u7CFB\u7EDF\u5BC6\u94A5\u73AF\u540E\u91CD\u8BD5\u3002",
  refreshUnavailable: "\u5F53\u524D\u8FDE\u63A5\u65E0\u6CD5\u5237\u65B0\uFF0C\u8BF7\u65AD\u5F00\u540E\u91CD\u65B0\u6388\u6743\u3002",
  actionFailed: "\u64CD\u4F5C\u672A\u5B8C\u6210\u3002\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\uFF1B\u5DF2\u6709\u8BF7\u6C42\u4F1A\u6309\u539F\u8BB0\u5F55\u6062\u590D\u3002",
  reauthorization: "\u6388\u6743\u5DF2\u5931\u6548\uFF0C\u8BF7\u5237\u65B0\u8FDE\u63A5\uFF0C\u6216\u65AD\u5F00\u540E\u91CD\u65B0\u6388\u6743\u3002",
  notConnected: "\u5C1A\u672A\u8FDE\u63A5\u8D26\u53F7",
  unknownExpiry: "\u670D\u52A1\u672A\u63D0\u4F9B\u5230\u671F\u65F6\u95F4\uFF1B\u8BFB\u53D6\u5931\u8D25\u65F6\u4F1A\u63D0\u793A\u91CD\u65B0\u6388\u6743\u3002",
  knownExpiry: "\u51ED\u636E\u5230\u671F\u65F6\u95F4\uFF1A{{date}}",
  connect: "\u8FDE\u63A5 Notion",
  refresh: "\u5237\u65B0\u8FDE\u63A5",
  disconnect: "\u65AD\u5F00\u8FDE\u63A5",
  authorizing: "\u7B49\u5F85\u6D4F\u89C8\u5668\u6388\u6743",
  authorizingHint: "\u5728\u6D4F\u89C8\u5668\u4E2D\u9009\u62E9\u5DE5\u4F5C\u533A\uFF0C\u5E76\u5171\u4EAB\u5141\u8BB8 LimeA \u8BFB\u53D6\u7684\u9875\u9762\u3002\u5B8C\u6210\u540E\u8FD9\u91CC\u4F1A\u81EA\u52A8\u66F4\u65B0\u3002",
  continue: "\u7EE7\u7EED\u6388\u6743",
  cancel: "\u53D6\u6D88\u6388\u6743",
  savedAcknowledging: "\u8FDE\u63A5\u5DF2\u4FDD\u5B58\uFF0C\u6B63\u5728\u786E\u8BA4\u6388\u6743\u7ED3\u679C\u2026",
  recoveryHint: "\u4E0A\u6B21\u8BF7\u6C42\u5C1A\u672A\u5B8C\u6210\u6216\u7ED3\u679C\u65E0\u6CD5\u786E\u8BA4\u3002\u5BBF\u4E3B\u4F1A\u6838\u5BF9\u539F\u8BF7\u6C42\uFF1B\u5982\u9700\u91CD\u65B0\u6388\u6743\uFF0C\u8BF7\u5148\u65AD\u5F00\u8FDE\u63A5\u3002",
  refreshPending: "\u6B63\u5728\u6838\u5BF9\u5237\u65B0\u7ED3\u679C\uFF0C\u8BF7\u7A0D\u5019\u2026",
  revokePending: "\u672C\u5730\u8BBF\u95EE\u5DF2\u5173\u95ED\uFF0C\u6B63\u5728\u6838\u5BF9\u8FDC\u7A0B\u64A4\u9500\u7ED3\u679C\u2026",
  granted: "\u5DF2\u5141\u8BB8\u4F7F\u7528\u5F53\u524D\u8FDE\u63A5",
  notGranted: "\u5C1A\u672A\u5141\u8BB8\u4F7F\u7528\u5F53\u524D\u8FDE\u63A5",
  privacyHint: "\u5BBF\u4E3B\u4F7F\u7528\u7CFB\u7EDF\u52A0\u5BC6\u4FDD\u62A4\u51ED\u636E\uFF0C\u754C\u9762\u4E0E\u53EA\u8BFB\u63D2\u4EF6\u901A\u8FC7\u53D7\u9650\u63A5\u53E3\u5DE5\u4F5C\u3002\u542F\u7528\u63D2\u4EF6\u5373\u4FE1\u4EFB\u5176\u4EE3\u7801\u3002\u8BF7\u5728 Notion \u4E2D\u53EA\u5171\u4EAB\u6240\u9700\u9875\u9762\uFF0C\u5E76\u4EC5\u5F00\u542F\u8BFB\u53D6\u80FD\u529B\u3002",
  auth: {
    failed: "\u6388\u6743\u672A\u5B8C\u6210\uFF0C\u53EF\u4EE5\u91CD\u65B0\u8FDE\u63A5\u3002",
    expired: "\u6388\u6743\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002",
    unknown: "\u6388\u6743\u7ED3\u679C\u65E0\u6CD5\u786E\u8BA4\uFF0C\u8BF7\u91CD\u65B0\u8FDE\u63A5\u3002",
    cancelled: "\u6388\u6743\u5DF2\u53D6\u6D88\u3002\u5BBF\u4E3B\u4F1A\u5C1D\u8BD5\u6E05\u7406\u8FDC\u7A0B\u51ED\u636E\uFF1B\u65E0\u6CD5\u786E\u8BA4\u65F6\uFF0C\u53EF\u5728 Notion \u7684\u8FDE\u63A5\u8BBE\u7F6E\u4E2D\u624B\u52A8\u79FB\u9664 LimeA\u3002"
  },
  revocation: {
    not_requested: "\u672C\u5730\u8FDE\u63A5\u5DF2\u5173\u95ED\u3002",
    pending: "\u672C\u5730\u8FDE\u63A5\u5DF2\u5173\u95ED\uFF0C\u6B63\u5728\u5C1D\u8BD5\u64A4\u9500\u8FDC\u7A0B\u6388\u6743\u3002",
    confirmed: "\u672C\u5730\u8FDE\u63A5\u5DF2\u5173\u95ED\uFF0C\u8FDC\u7A0B\u6388\u6743\u5DF2\u64A4\u9500\u3002",
    unknown: "\u672C\u5730\u8FDE\u63A5\u5DF2\u5173\u95ED\uFF0C\u8FDC\u7A0B\u64A4\u9500\u7ED3\u679C\u65E0\u6CD5\u786E\u8BA4\u3002\u53EF\u5728 Notion \u7684\u8FDE\u63A5\u8BBE\u7F6E\u4E2D\u624B\u52A8\u79FB\u9664 LimeA\u3002",
    failed: "\u672C\u5730\u8FDE\u63A5\u5DF2\u5173\u95ED\uFF0C\u8FDC\u7A0B\u64A4\u9500\u5931\u8D25\u3002\u8BF7\u5728 Notion \u7684\u8FDE\u63A5\u8BBE\u7F6E\u4E2D\u624B\u52A8\u79FB\u9664 LimeA\u3002"
  },
  featuresTitle: "\u63D2\u4EF6\u529F\u80FD",
  searchTitle: "\u641C\u7D22\u9875\u9762",
  searchDetail: "\u6309\u6807\u9898\u67E5\u627E\u4F60\u5171\u4EAB\u7684\u9875\u9762\uFF0C\u652F\u6301\u7FFB\u9875\uFF0C\u4E0D\u641C\u7D22\u9875\u9762\u6B63\u6587\u3002",
  pageTitle: "\u8BFB\u53D6\u9875\u9762\u4FE1\u606F",
  pageDetail: "\u67E5\u770B\u5DF2\u5171\u4EAB\u9875\u9762\u7684\u6807\u9898\u53CA\u53D7\u652F\u6301\u7684\u5C5E\u6027\u3002",
  blocksTitle: "\u8BFB\u53D6\u9875\u9762\u5185\u5BB9",
  blocksDetail: "\u9010\u9875\u8BFB\u53D6\u6587\u672C\u548C\u5D4C\u5957\u5185\u5BB9\u5757\uFF0C\u4E0D\u4E0B\u8F7D\u9644\u4EF6\u3002",
  usageTitle: "\u5F00\u59CB\u4F7F\u7528",
  usage: "\u8FDE\u63A5\u8D26\u53F7\u5E76\u5728\u4E0B\u65B9\u5141\u8BB8\u8BFB\u53D6\u540E\uFF0C\u5411 LimeA \u53D1\u9001\u4E00\u6761\u65B0\u6D88\u606F\u3002\u4F8B\u5982\uFF1A\u201C\u5E2E\u6211\u5728 Notion \u627E\u5230\u9879\u76EE\u7B14\u8BB0\uFF0C\u5E76\u603B\u7ED3\u4E0B\u4E00\u6B65\u8981\u505A\u7684\u4E8B\u3002\u201D",
  readOnly: "\u53EA\u8BFB \xB7 \u4EC5\u9650\u5DF2\u5171\u4EAB\u9875\u9762",
  ready: "\u5DF2\u8FDE\u63A5"
};
var en = {
  accountTitle: "Account",
  loading: "Loading connection\u2026",
  loadFailed: "Could not load connections. Try again.",
  retry: "Retry",
  vaultUnavailable: "System credential protection is unavailable. Unlock your system keyring and try again.",
  refreshUnavailable: "This connection cannot be refreshed. Disconnect and authorize again.",
  actionFailed: "The action did not complete. Check your network and retry; existing requests recover using their saved identity.",
  reauthorization: "Authorization has expired. Refresh, or disconnect and authorize again.",
  notConnected: "No account connected",
  unknownExpiry: "The service did not provide an expiry time. You will be prompted if authorization becomes invalid.",
  knownExpiry: "Credentials expire: {{date}}",
  connect: "Connect Notion",
  refresh: "Refresh connection",
  disconnect: "Disconnect",
  authorizing: "Waiting for browser authorization",
  authorizingHint: "Choose a workspace and share the pages LimeA may read in your browser. This page updates automatically.",
  continue: "Continue authorization",
  cancel: "Cancel authorization",
  savedAcknowledging: "Connection saved. Acknowledging the authorization result\u2026",
  recoveryHint: "The previous request is incomplete or uncertain. LimeA will check the original request. Disconnect first if you need to authorize again.",
  refreshPending: "Checking the refresh result\u2026",
  revokePending: "Local access is disabled. Checking remote revocation\u2026",
  granted: "Allowed to use this connection",
  notGranted: "Not allowed to use this connection",
  privacyHint: "The host protects credentials with system encryption. The UI and read-only plugin use scoped interfaces. Enabling a plugin trusts its code. Share only the pages you need and enable only read capabilities in Notion.",
  auth: {
    failed: "Authorization did not complete. Connect again.",
    expired: "Authorization expired. Connect again.",
    unknown: "Authorization result is uncertain. Connect again.",
    cancelled: "Authorization cancelled. LimeA will attempt cleanup; if uncertain, remove LimeA in Notion connection settings."
  },
  revocation: {
    not_requested: "Local connection disabled.",
    pending: "Local connection disabled. Attempting remote revocation.",
    confirmed: "Local connection disabled and remote authorization revoked.",
    unknown: "Local connection disabled. Remote revocation could not be confirmed. You can remove LimeA in Notion connection settings.",
    failed: "Local connection disabled. Remote revocation failed. Remove LimeA in Notion connection settings."
  },
  featuresTitle: "What this plugin can do",
  searchTitle: "Search pages",
  searchDetail: "Find shared pages by title. Results do not include full-text search.",
  pageTitle: "Read page information",
  pageDetail: "Read titles and supported properties from a shared page.",
  blocksTitle: "Read page content",
  blocksDetail: "Read text blocks page by page, including nested blocks. No attachment downloads.",
  usageTitle: "Start a conversation",
  usage: "After connecting and allowing access below, send a new message to LimeA. For example: \u201CFind my project notes in Notion and summarize the next steps.\u201D",
  readOnly: "Read only \xB7 shared pages",
  ready: "Connected"
};

// src/page.mjs
function mount(container, context) {
  if (!context.connections || !context.controls) throw new Error("plugin-host-upgrade-required");
  const t = context.language.startsWith("zh") ? zh : en;
  const style = document.createElement("style");
  style.textContent = page_default;
  const root = document.createElement("div");
  root.className = "notion-page";
  root.innerHTML = `
    <section class="account" aria-labelledby="notion-account-title">
      <h2 id="notion-account-title"></h2>
      <div class="account-row">
        <div class="account-summary"><strong class="account-name"></strong><p class="account-hint"></p></div>
        <div class="account-actions"><span data-action="authorize"></span><span data-action="resume"></span><span data-action="cancel"></span><span data-action="refresh"></span><span data-action="disconnect"></span></div>
      </div>
      <p class="account-status" role="status" aria-live="polite"></p>
      <div class="account-error" role="alert"><p></p><span data-action="retry"></span></div>
    </section>
    <section class="features"><h2></h2><ul>
      <li><h3></h3><p></p></li><li><h3></h3><p></p></li><li><h3></h3><p></p></li>
    </ul></section>
    <section class="usage"><h2></h2><p></p></section>`;
  container.replaceChildren(style, root);
  const query = (selector) => root.querySelector(selector);
  query("#notion-account-title").textContent = t.accountTitle;
  query(".features h2").textContent = t.featuresTitle;
  [...root.querySelectorAll(".features li")].forEach((item, i) => {
    item.querySelector("h3").textContent = [t.searchTitle, t.pageTitle, t.blocksTitle][i];
    item.querySelector("p").textContent = [t.searchDetail, t.pageDetail, t.blocksDetail][i];
  });
  query(".usage h2").textContent = t.usageTitle;
  query(".usage p").textContent = t.usage;
  let view, pending = false, polling = false, timer, disposed = false, error = "";
  const handles = /* @__PURE__ */ new Map();
  const alive = () => !disposed && !context.signal.aborted;
  const labels = {
    authorize: t.connect,
    resume: t.continue,
    cancel: t.cancel,
    refresh: t.refresh,
    disconnect: t.disconnect,
    retry: t.retry
  };
  for (const [action, label] of Object.entries(labels)) {
    const slot = query(`[data-action="${action}"]`);
    handles.set(
      action,
      context.controls.mount(slot, {
        type: "button",
        label,
        variant: action === "authorize" ? "default" : "outline",
        onPress: () => void perform(action)
      })
    );
  }
  function render() {
    if (!alive()) return;
    const c = view?.connection, f = view?.authorization;
    const authorizing = f && ["preparing", "authorizing"].includes(f.status);
    const connected = c?.status === "connected";
    query(".account-name").textContent = !view ? t.loading : authorizing ? t.authorizing : connected ? c.workspaceName : c?.status === "reauthorization_required" ? t.reauthorization : t.notConnected;
    query(".account-hint").textContent = authorizing ? t.authorizingHint : connected ? `${t.ready} \xB7 ${t.readOnly}` : t.readOnly;
    const shown = {
      authorize: Boolean(
        view && (!c || c.status === "disconnected") && !authorizing && f?.status !== "persisted"
      ),
      resume: Boolean(authorizing),
      cancel: Boolean(authorizing),
      refresh: Boolean(c && c.status !== "disconnected"),
      disconnect: Boolean(c && c.status !== "disconnected"),
      retry: Boolean(error)
    };
    for (const [action, handle] of handles) {
      query(`[data-action="${action}"]`).hidden = !shown[action];
      handle.update({
        type: "button",
        label: labels[action],
        variant: action === "authorize" ? "default" : "outline",
        disabled: pending || action === "refresh" && Boolean(view?.operation),
        onPress: () => void perform(action)
      });
    }
    let status = "";
    if (c?.status === "disconnected") status = t.revocation[c.remoteRevocation];
    else if (view?.operation)
      status = view.operation.kind === "refresh" ? t.refreshPending : t.revokePending;
    else if (f?.status === "persisted") status = t.savedAcknowledging;
    else if (f && ["failed", "expired", "unknown", "cancelled"].includes(f.status))
      status = t.auth[f.status];
    else if (c?.error || f?.error) status = t.recoveryHint;
    query(".account-status").textContent = status;
    query(".account-status").hidden = !status;
    query(".account-error").hidden = !error;
    query(".account-error p").textContent = error;
    query(".account").setAttribute("aria-busy", String(pending || !view));
  }
  function schedule() {
    clearTimeout(timer);
    if (alive() && (view?.operation || view?.authorization?.pending))
      timer = setTimeout(() => void load(), 2e3);
  }
  async function load() {
    if (!alive() || pending || polling) return;
    polling = true;
    try {
      const next = await context.connections.request({ action: "view" });
      if (alive() && (!view || next.revision >= view.revision)) {
        view = next;
        error = "";
      }
    } catch {
      if (alive()) error = t.loadFailed;
    } finally {
      polling = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  async function perform(action) {
    if (!alive() || pending) return;
    if (action === "retry") {
      await load();
      return;
    }
    pending = true;
    error = "";
    render();
    try {
      const next = await context.connections.request({ action });
      if (alive() && (!view || next.revision >= view.revision)) view = next;
    } catch (e) {
      if (alive())
        error = e?.code === "connection-vault-unavailable" ? t.vaultUnavailable : e?.code === "connection-refresh-unavailable" ? t.refreshUnavailable : t.actionFailed;
    } finally {
      pending = false;
      if (alive()) {
        render();
        schedule();
      }
    }
  }
  const unsubscribe = context.connections.subscribe((next) => {
    if (alive() && (!view || next.revision >= view.revision)) {
      view = next;
      render();
      schedule();
    }
  });
  const onFocus = () => void load();
  window.addEventListener("focus", onFocus);
  function cleanup() {
    disposed = true;
    clearTimeout(timer);
    unsubscribe();
    window.removeEventListener("focus", onFocus);
    for (const handle of handles.values()) handle.destroy();
    container.replaceChildren();
  }
  context.signal.addEventListener("abort", cleanup, { once: true });
  render();
  void load();
  return cleanup;
}
export {
  mount
};
