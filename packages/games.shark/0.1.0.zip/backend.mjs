// src/backend.mjs
import { DatabaseSync } from "node:sqlite";
import { randomInt, randomUUID } from "node:crypto";
import { join } from "node:path";
var TEETH = 12;
function scopeKey(payload) {
  if (!payload || payload.mode !== "chat" || payload.sessionId !== null && (typeof payload.sessionId !== "string" || payload.sessionId.length > 128))
    throw new Error("invalid-game-scope");
  return JSON.stringify([payload.mode, payload.sessionId]);
}
function publicRound(round) {
  return { id: round.id, pressed: round.pressed, status: round.status, teeth: TEETH };
}
function createGameStore(directory, draw = () => randomInt(1, TEETH + 1)) {
  const database = new DatabaseSync(join(directory, "rounds.sqlite"));
  database.exec(
    "PRAGMA journal_mode=WAL; CREATE TABLE IF NOT EXISTS rounds (scope TEXT PRIMARY KEY, state TEXT NOT NULL)"
  );
  const select = database.prepare("SELECT state FROM rounds WHERE scope = ?");
  const save = database.prepare(
    "INSERT INTO rounds(scope, state) VALUES (?, ?) ON CONFLICT(scope) DO UPDATE SET state=excluded.state"
  );
  const read = (key) => {
    const row = select.get(key);
    return row ? JSON.parse(row.state) : null;
  };
  const make = () => ({ id: randomUUID(), trap: draw(), pressed: [], status: "playing" });
  const write = (key, round) => {
    save.run(key, JSON.stringify(round));
    return publicRound(round);
  };
  return {
    load(payload) {
      const key = scopeKey(payload), round = read(key);
      return round ? publicRound(round) : write(key, make());
    },
    press(payload) {
      const key = scopeKey(payload), round = read(key);
      if (!Number.isInteger(payload.tooth) || payload.tooth < 1 || payload.tooth > TEETH)
        throw new Error("invalid-tooth");
      if (!round || round.id !== payload.roundId) throw new Error("stale-round");
      if (round.status === "bitten" || round.pressed.includes(payload.tooth))
        return publicRound(round);
      round.pressed.push(payload.tooth);
      if (payload.tooth === round.trap) round.status = "bitten";
      return write(key, round);
    },
    restart(payload) {
      const key = scopeKey(payload), round = read(key);
      if (round && round.id !== payload.roundId) throw new Error("stale-round");
      return write(key, make());
    },
    dispose() {
      database.close();
    }
  };
}
function apply(context) {
  const game = createGameStore(context.dataDirectory);
  context.onDispose(() => game.dispose());
  context.commands.register("load-round", (payload) => game.load(payload));
  context.commands.register("press-tooth", (payload) => game.press(payload));
  context.commands.register("new-round", (payload) => game.restart(payload));
}
export {
  apply,
  createGameStore
};
