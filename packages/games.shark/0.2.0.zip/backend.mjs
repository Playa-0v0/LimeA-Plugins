// src/backend.mjs
import { randomInt, randomUUID } from "node:crypto";
var TEETH = 12;
function scopeKey(payload) {
  if (!payload || payload.mode !== "chat" || payload.sessionId !== null && (typeof payload.sessionId !== "string" || payload.sessionId.length > 128))
    throw new Error("invalid-game-scope");
  return JSON.stringify([payload.mode, payload.sessionId]);
}
function publicRound(round) {
  return { id: round.id, pressed: round.pressed, status: round.status, teeth: TEETH };
}
var migrations = [
  {
    id: "1000_initial",
    sql: "CREATE TABLE IF NOT EXISTS rounds (scope TEXT PRIMARY KEY, state TEXT NOT NULL);"
  }
];
async function createGameStore(storage, draw = () => randomInt(1, TEETH + 1)) {
  const database = await storage.openDatabase({
    name: "rounds",
    migrations,
    legacyFile: "rounds.sqlite"
  });
  let queue = Promise.resolve();
  let disposed = false;
  const serial = (action) => {
    if (disposed) return Promise.reject(new Error("game-closed"));
    const result = queue.then(action);
    queue = result.catch(() => {
    });
    return result;
  };
  const read = async (key) => {
    const row = await database.get("SELECT state FROM rounds WHERE scope = ?", [key]);
    return row ? JSON.parse(row.state) : null;
  };
  const make = () => ({ id: randomUUID(), trap: draw(), pressed: [], status: "playing" });
  const write = async (key, round) => {
    await database.run(
      "INSERT INTO rounds(scope, state) VALUES (?, ?) ON CONFLICT(scope) DO UPDATE SET state=excluded.state",
      [key, JSON.stringify(round)]
    );
    return publicRound(round);
  };
  return {
    load: (payload) => serial(async () => {
      const key = scopeKey(payload), round = await read(key);
      return round ? publicRound(round) : write(key, make());
    }),
    press: (payload) => serial(async () => {
      const key = scopeKey(payload), round = await read(key);
      if (!Number.isInteger(payload.tooth) || payload.tooth < 1 || payload.tooth > TEETH)
        throw new Error("invalid-tooth");
      if (!round || round.id !== payload.roundId) throw new Error("stale-round");
      if (round.status === "bitten" || round.pressed.includes(payload.tooth))
        return publicRound(round);
      round.pressed.push(payload.tooth);
      if (round.trap === payload.tooth) round.status = "bitten";
      return write(key, round);
    }),
    restart: (payload) => serial(async () => {
      const key = scopeKey(payload), round = await read(key);
      if (round && round.id !== payload.roundId) throw new Error("stale-round");
      return write(key, make());
    }),
    async dispose() {
      disposed = true;
      await queue;
      await database.close();
    }
  };
}
async function apply(context) {
  const game = await createGameStore(context.storage);
  context.onDispose(() => game.dispose());
  context.commands.register("load-round", (payload) => game.load(payload));
  context.commands.register("press-tooth", (payload) => game.press(payload));
  context.commands.register("new-round", (payload) => game.restart(payload));
}
export {
  apply,
  createGameStore,
  migrations
};
